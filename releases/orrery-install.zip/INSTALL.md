# Orrery install bundle

Orrery runs locally on your machine. You need the **buddyide** source repo (this project).

## Prerequisites

- **Node.js** 20 or newer
- **pnpm** 10 (`npm install -g pnpm`)
- **Git**
- **Ollama** (optional, for local models) — [ollama.com](https://ollama.com)
- Or cloud API keys: OpenAI, Anthropic, Gemini, DeepSeek

## Quick start

### Windows

```powershell
.\start-orrery.ps1
```

### macOS / Linux

```bash
chmod +x start-orrery.sh
./start-orrery.sh
```

This starts:

1. **Sidecar** — WebSocket agent backend at `ws://127.0.0.1:4575`
2. **Web UI** — browser client (usually `http://localhost:5173`)

Open the printed URL in your browser. Point the sidecar at your project workspace (the folder you want the agent to edit).

## Environment

Set before starting (or edit the start script):

| Variable | Example | Purpose |
|----------|---------|---------|
| `ED_PROVIDER` | `ollama` | LLM provider |
| `ED_MODEL` | `qwen2.5-coder` | Model name |
| `OPENAI_API_KEY` | `sk-…` | When using OpenAI |
| `ANTHROPIC_API_KEY` | `…` | When using Anthropic |

Offline smoke test (no API key):

```powershell
pnpm harness
```

## First-time setup

If this is a fresh clone:

```powershell
cd path\to\buddyide
pnpm install
pnpm gate
```

## Troubleshooting

- **Port 4575 in use** — set `ED_SIDECAR_PORT` to another port; update web client config if needed.
- **Ollama connection** — ensure `ollama serve` is running and the model is pulled: `ollama pull qwen2.5-coder`
- **pnpm not found** — install pnpm globally or use `corepack enable`

## Privacy

Your code stays on your machine. Cloud providers only receive what you send when you configure API keys.
