#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"

if [[ ! -f package.json ]]; then
  echo "buddyide root not found. Run from a full buddyide clone." >&2
  exit 1
fi

if [[ ! -d node_modules ]]; then
  echo "Installing dependencies..."
  pnpm install
fi

export ED_PROVIDER="${ED_PROVIDER:-ollama}"
export ED_MODEL="${ED_MODEL:-qwen2.5-coder}"

echo "Orrery — ED_PROVIDER=$ED_PROVIDER ED_MODEL=$ED_MODEL"
echo "Starting sidecar on ws://127.0.0.1:4575 ..."

pnpm --filter @ed/sidecar start &
SIDECAR_PID=$!
trap 'kill $SIDECAR_PID 2>/dev/null || true' EXIT

sleep 3
echo "Starting web UI — open http://localhost:5173 when ready."
pnpm --filter @ed/web dev
