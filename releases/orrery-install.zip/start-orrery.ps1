# Start Orrery (sidecar + web UI)
$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
if (-not (Test-Path (Join-Path $Root "package.json"))) {
    Write-Error "buddyide root not found. Run from a full buddyide clone."
}

Set-Location $Root

if (-not (Test-Path "node_modules")) {
    Write-Host "Installing dependencies..."
    pnpm install
}

if (-not $env:ED_PROVIDER) {
    $env:ED_PROVIDER = "ollama"
}
if (-not $env:ED_MODEL) {
    $env:ED_MODEL = "qwen2.5-coder"
}

Write-Host "Orrery — ED_PROVIDER=$($env:ED_PROVIDER) ED_MODEL=$($env:ED_MODEL)"
Write-Host "Starting sidecar on ws://127.0.0.1:4575 ..."

$sidecar = Start-Process -FilePath "pnpm" -ArgumentList "--filter","@ed/sidecar","start" `
    -WorkingDirectory $Root -PassThru -NoNewWindow

Start-Sleep -Seconds 3

Write-Host "Starting web UI..."
Write-Host "Open http://localhost:5173 when Vite prints ready."
pnpm --filter @ed/web dev

if ($sidecar -and -not $sidecar.HasExited) {
    Stop-Process -Id $sidecar.Id -Force -ErrorAction SilentlyContinue
}
