Main file: main.tex
Compile with PDFLaTeX/latexmk.  Figures are in figures/ and the publication
upgrade section is in sections/.  The accompanying reproducibility artifact
contains code, exact result files, tests, and Lean sources.
