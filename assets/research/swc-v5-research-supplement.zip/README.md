# SWC v5 research supplement

This supplement contains exact checkers, certificates, and research notes.
It is not a universal Erdos-Straus proof or an accepted journal release.
The original v3 source archive is separate and still needs checksum/build
reconciliation. Code: Apache-2.0; accompanying text/data: CC BY 4.0.

Recommended lightweight commands from research/:
python3 -B -m unittest test_swc_certificate_kernel
python3 -B swc_certificate_kernel.py evidence/swc-combined-cases.json
python3 -B verify_character_induction.py evidence/swc-character-induction.json
python3 -B verify_swc_reachability.py evidence/swc-reachability-certificate.json

Historical large-prime search programs are included for provenance but are
not required for these checks. Do not run large sweeps on a memory-limited
machine. Read final-literature-audit-2026-09-05.md and the notes' scope limits.

PDF: https://ephemerent.com/assets/research/stochastic-witness-calculus-v5.pdf
Web: https://ephemerent.com/journal/preprint/stochastic-witness-calculus
