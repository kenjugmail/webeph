SWC version 6 source
Main file: main.tex. The source includes all referenced figures and TeX inputs.
Validated compiler: Tectonic 0.17.0, XeTeX engine and BibTeX backend.
Rebuild: SOURCE_DATE_EPOCH=1788566400 tectonic main.tex
Conventional route: xelatex main; bibtex main; xelatex main; xelatex main.
The conventional route and arXiv server processing have not been run here.
The .bbl is included. No external scripts or shell escape are required.
This is a research preprint, not an arXiv acceptance or journal review record.
Article, figures, and numerical records: CC BY 4.0.
Code in the separate research supplement: Apache-2.0.
