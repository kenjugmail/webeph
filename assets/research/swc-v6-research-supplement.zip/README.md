# SWC version 6 research supplement

Exact-output contracts, complete finite-domain certificates, and a recorded
fixed-horizon reliability evaluation. This package is a public research
preprint artifact, not an accepted journal deposit or a universal solution.
The evidence uses generated mathematical inputs, not physical measurements.

From research/, verify the existing experiment without sampling again:
python3 -B verify_swc_assurance_pilot.py evidence/swc-assurance-v1
python3 -B verify_swc_canonical_obstruction.py evidence/swc-canonical-obstructions.json
python3 -B -m unittest test_swc_assurance test_swc_canonical_pair test_swc_lonely_runner test_swc_certificate_kernel

The complete ledger, plan, and finite witnesses are included. Treat IID
provenance as a stated assumption, not something established by fingerprints.
Do not silently replace a failed run or pool fresh runs without a valid plan.
Historical large prime searches are not needed to verify this release.
Historical experiment sources, requirements, and raw outputs are included
under original-v3/ with an explicit provenance note; its old manifest has
known stale entries and is not silently repaired. Use the outer SHA256.json.

Paper: https://ephemerent.com/assets/research/stochastic-witness-calculus-arxiv-v6.pdf
HTML: https://ephemerent.com/journal/preprint/stochastic-witness-calculus
Code: Apache-2.0. Text and numerical records: CC BY 4.0.
