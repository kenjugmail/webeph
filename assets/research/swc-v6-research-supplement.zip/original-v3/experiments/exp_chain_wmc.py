#!/usr/bin/env python3
"""Exact weighted-mass certificates for path independent-set witnesses.

Witnesses are bit strings of length n that encode an independent set of exactly k
vertices in the path graph P_n. The accepted set has closed-form cardinality
C(n-k+1, k). We independently recompute the weighted accepted mass by a dynamic
program over position, selected-count, and previous bit. All arithmetic is exact.

This benchmark demonstrates a non-enumerative certificate backend: witness spaces
have size 2^n, while the checker runs in O(nk) arithmetic operations.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import time
from fractions import Fraction
from pathlib import Path


def exact_dp_weight(n: int, k: int, one_weight: int, denominator: int) -> int:
    """Return numerator of accepted mass over denominator**n."""
    if not (0 <= k <= (n + 1) // 2):
        return 0
    if not (0 < one_weight < denominator):
        raise ValueError("one_weight must lie in (0, denominator)")
    zero_weight = denominator - one_weight

    # dp0[j]: valid prefixes with j selected vertices and final bit 0.
    # dp1[j]: valid prefixes with j selected vertices and final bit 1.
    dp0 = [0] * (k + 1)
    dp1 = [0] * (k + 1)
    dp0[0] = 1
    for _ in range(n):
        new0 = [0] * (k + 1)
        new1 = [0] * (k + 1)
        for j in range(k + 1):
            new0[j] = (dp0[j] + dp1[j]) * zero_weight
            if j > 0:
                new1[j] = dp0[j - 1] * one_weight
        dp0, dp1 = new0, new1
    return dp0[k] + dp1[k]


def closed_form_weight(n: int, k: int, one_weight: int, denominator: int) -> int:
    count = math.comb(n - k + 1, k) if 0 <= k <= (n + 1) // 2 else 0
    return count * (one_weight ** k) * ((denominator - one_weight) ** (n - k))


def log10_fraction(num: int, den: int) -> float:
    if num <= 0:
        return float("-inf")
    # Use bit-length based scaling to avoid float overflow on large integers.
    def log10_int(x: int) -> float:
        bits = x.bit_length()
        shift = max(0, bits - 53)
        mant = x >> shift
        return math.log10(float(mant)) + shift * math.log10(2.0)
    return log10_int(num) - log10_int(den)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="results/chain_wmc_results.csv")
    parser.add_argument("--summary", default="results/chain_wmc_summary.json")
    parser.add_argument("--denominator", type=int, default=256)
    parser.add_argument("--learned-one-weight", type=int, default=64)
    parser.add_argument("--mixture-baseline-weight", type=int, default=5)
    parser.add_argument("--mixture-learned-weight", type=int, default=95)
    args = parser.parse_args()

    root = Path(__file__).resolve().parents[1]
    out = root / args.out
    summary_out = root / args.summary
    out.parent.mkdir(parents=True, exist_ok=True)

    sizes = [16, 32, 64, 128, 256, 512, 1024, 2048]
    q = args.denominator
    uniform_w = q // 2
    learned_w = args.learned_one_weight
    mix0 = args.mixture_baseline_weight
    mix1 = args.mixture_learned_weight
    mix_total = mix0 + mix1

    rows: list[dict[str, float | int | bool | str]] = []
    max_n_checked_by_enumeration = 24
    all_crosschecks = True

    for n in sizes:
        k = n // 4
        start = time.perf_counter()
        uniform_num = exact_dp_weight(n, k, uniform_w, q)
        uniform_time = time.perf_counter() - start

        start = time.perf_counter()
        learned_num = exact_dp_weight(n, k, learned_w, q)
        learned_time = time.perf_counter() - start

        uniform_closed = closed_form_weight(n, k, uniform_w, q)
        learned_closed = closed_form_weight(n, k, learned_w, q)
        crosscheck = uniform_num == uniform_closed and learned_num == learned_closed
        all_crosschecks = all_crosschecks and crosscheck

        den = q ** n
        # Exact trajectory-level mixture: choose baseline or learned generator first.
        mixed_num = mix0 * uniform_num + mix1 * learned_num
        mixed_den = mix_total * den

        uniform_mass = Fraction(uniform_num, den)
        learned_mass = Fraction(learned_num, den)
        mixed_mass = Fraction(mixed_num, mixed_den)
        speedup = float(mixed_mass / uniform_mass) if uniform_num else float("nan")
        support_floor_ratio = float(mixed_mass / uniform_mass)

        rows.append({
            "n": n,
            "k": k,
            "witness_space_log2": n,
            "valid_witness_count": math.comb(n - k + 1, k),
            "uniform_log10_mass": log10_fraction(uniform_num, den),
            "learned_log10_mass": log10_fraction(learned_num, den),
            "mixed_log10_mass": log10_fraction(mixed_num, mixed_den),
            "mixed_to_uniform_ratio": speedup,
            "uniform_dp_seconds": uniform_time,
            "learned_dp_seconds": learned_time,
            "closed_form_crosscheck": crosscheck,
            "uniform_numerator_digits": int(math.floor((uniform_num.bit_length()-1)*math.log10(2.0)))+1 if uniform_num else 1,
            "common_denominator_digits": int(math.floor((den.bit_length()-1)*math.log10(2.0)))+1,
        })

    with out.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    largest = rows[-1]
    summary = {
        "constraint": "independent sets of exactly floor(n/4) vertices in the path P_n",
        "sizes": sizes,
        "common_probability_denominator": q,
        "uniform_one_probability": uniform_w / q,
        "learned_one_probability": learned_w / q,
        "trajectory_mixture_weights": {"uniform": mix0, "learned": mix1},
        "all_dp_closed_form_crosschecks_passed": all_crosschecks,
        "largest_instance": largest,
        "asymptotic_checker_operations": "O(n k) exact integer updates; witness space has 2^n elements",
        "support_guarantee": f"mixed accepted mass is at least {mix0}/{mix_total} of uniform accepted mass",
    }
    with summary_out.open("w") as f:
        json.dump(summary, f, indent=2)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
