#include <algorithm>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <sstream>
#include <string>
#include <tuple>
#include <vector>

using i64 = long long;
using i128 = __int128_t;

static std::string i128_to_string(i128 x) {
    if (x == 0) return "0";
    bool neg = x < 0;
    if (neg) x = -x;
    std::string s;
    while (x > 0) {
        s.push_back(char('0' + x % 10));
        x /= 10;
    }
    if (neg) s.push_back('-');
    std::reverse(s.begin(), s.end());
    return s;
}

static std::vector<int> sieve_primes(int n) {
    std::vector<bool> is_prime(n + 1, true);
    is_prime[0] = is_prime[1] = false;
    for (int i = 2; (i64)i * i <= n; ++i)
        if (is_prime[i])
            for (i64 j = (i64)i * i; j <= n; j += i)
                is_prime[(int)j] = false;
    std::vector<int> primes;
    for (int i = 2; i <= n; ++i) if (is_prime[i]) primes.push_back(i);
    return primes;
}

static std::vector<int> smallest_prime_factor(int n) {
    std::vector<int> spf(n + 1);
    for (int i = 0; i <= n; ++i) spf[i] = i;
    if (n >= 1) spf[1] = 1;
    for (int i = 2; (i64)i * i <= n; ++i) {
        if (spf[i] == i) {
            for (i64 j = (i64)i * i; j <= n; j += i) {
                if (spf[(int)j] == j) spf[(int)j] = i;
            }
        }
    }
    return spf;
}

static std::vector<std::pair<int,int>> factorize(int x, const std::vector<int>& spf) {
    std::vector<std::pair<int,int>> f;
    while (x > 1) {
        int q = spf[x], e = 0;
        while (x % q == 0) { x /= q; ++e; }
        f.push_back({q,e});
    }
    return f;
}

static void gen_divisors_rec(const std::vector<std::pair<int,int>>& f, int idx, i64 cur, std::vector<i64>& out) {
    if (idx == (int)f.size()) { out.push_back(cur); return; }
    auto [q,e] = f[idx];
    i64 v = 1;
    for (int k = 0; k <= 2*e; ++k) {
        gen_divisors_rec(f, idx+1, cur*v, out);
        v *= q;
    }
}

struct ShiftInfo {
    int c;
    int weight;
    i64 a;
    i64 tau;
    i64 hits;
    i64 first_d;
    int branch; // 1: d=-a, 2: 4d=-1, 3: both
};

static ShiftInfo analyze_shift(int p, int c, const std::vector<int>& spf) {
    i64 a = ((i64)p + c) / 4;
    auto fac = factorize((int)a, spf);
    std::vector<i64> divisors;
    divisors.reserve(256);
    gen_divisors_rec(fac, 0, 1, divisors);
    i64 hits = 0, first_d = -1;
    int first_branch = 0;
    for (i64 d : divisors) {
        bool b1 = ((d + a) % c == 0);
        bool b2 = ((4*d + 1) % c == 0);
        if (b1 || b2) {
            ++hits;
            if (first_d < 0) {
                first_d = d;
                first_branch = b1 && b2 ? 3 : (b1 ? 1 : 2);
            }
        }
    }
    int weight = std::max(1, 128 / c); // support-preserving small-shift prior
    return ShiftInfo{c, weight, a, (i64)divisors.size(), hits, first_d, first_branch};
}

static bool verify_witness(int p, const ShiftInfo& s) {
    if (s.first_d < 0) return false;
    i128 a = s.a, c = s.c, d = s.first_d, P = p;
    i128 M = a * P;
    i128 e;
    if (s.branch == 1 || s.branch == 3) e = P * d;
    else e = P * P * d;
    i128 M2 = M * M;
    if (M2 % e != 0) return false;
    i128 ep = M2 / e;
    if ((M + e) % c != 0 || (M + ep) % c != 0) return false;
    i128 x = a;
    i128 y = (M + e) / c;
    i128 z = (M + ep) / c;
    if (x <= 0 || y <= 0 || z <= 0) return false;
    i128 lhs = 4 * x * y * z;
    i128 rhs = P * (x*y + x*z + y*z);
    return lhs == rhs;
}

static double percentile(std::vector<double> v, double q) {
    if (v.empty()) return std::numeric_limits<double>::quiet_NaN();
    std::sort(v.begin(), v.end());
    double pos = q * (v.size() - 1);
    size_t lo = (size_t)std::floor(pos), hi = (size_t)std::ceil(pos);
    if (lo == hi) return v[lo];
    double t = pos - lo;
    return v[lo]*(1-t) + v[hi]*t;
}

int main(int argc, char** argv) {
    int pmax = 2000000;
    int cmax = 127;
    std::string out_csv = "results/erdos_results.csv";
    std::string out_json = "results/erdos_summary.json";
    if (argc > 1) pmax = std::stoi(argv[1]);
    if (argc > 2) cmax = std::stoi(argv[2]);
    if (argc > 3) out_csv = argv[3];
    if (argc > 4) out_json = argv[4];

    auto primes = sieve_primes(pmax);
    int max_a = (pmax + cmax) / 4 + 2;
    auto spf = smallest_prime_factor(max_a);
    std::vector<int> cs;
    for (int c = 3; c <= cmax; c += 4) cs.push_back(c);
    i64 total_shift_weight = 0;
    for (int c : cs) total_shift_weight += std::max(1, 128/c);

    std::ofstream out(out_csv);
    out << "p,least_c,first_d,branch,successful_shifts,uniform_mass,weighted_mass,uniform_expected_trials,weighted_expected_trials\n";
    out << std::setprecision(17);

    int n = 0, covered = 0, witness_verified = 0;
    int max_least_c = 0, max_least_p = 0;
    double min_uniform = 1.0, min_weighted = 1.0;
    int min_uniform_p = 0, min_weighted_p = 0;
    std::vector<double> uniform_masses, weighted_masses;
    std::map<int,int> least_hist;

    for (int p : primes) {
        if (p % 24 != 1) continue;
        ++n;
        int least_c = -1, successful = 0, branch = 0;
        i64 first_d = -1;
        long double sum_uniform = 0.0L, sum_weighted = 0.0L;
        ShiftInfo first_info{};
        bool have_first = false;
        for (int c : cs) {
            ShiftInfo info = analyze_shift(p, c, spf);
            long double frac = (long double)info.hits / (long double)info.tau;
            sum_uniform += frac;
            sum_weighted += (long double)info.weight * frac;
            if (info.hits > 0) {
                ++successful;
                if (!have_first) {
                    have_first = true;
                    first_info = info;
                    least_c = c;
                    first_d = info.first_d;
                    branch = info.branch;
                }
            }
        }
        double uniform_mass = (double)(sum_uniform / cs.size());
        double weighted_mass = (double)(sum_weighted / total_shift_weight);
        if (have_first) {
            ++covered;
            if (verify_witness(p, first_info)) ++witness_verified;
            least_hist[least_c]++;
            if (least_c > max_least_c) { max_least_c = least_c; max_least_p = p; }
        }
        if (uniform_mass < min_uniform) { min_uniform = uniform_mass; min_uniform_p = p; }
        if (weighted_mass < min_weighted) { min_weighted = weighted_mass; min_weighted_p = p; }
        uniform_masses.push_back(uniform_mass);
        weighted_masses.push_back(weighted_mass);
        out << p << ',' << least_c << ',' << first_d << ',' << branch << ',' << successful << ','
            << uniform_mass << ',' << weighted_mass << ','
            << (uniform_mass > 0 ? 1.0/uniform_mass : std::numeric_limits<double>::infinity()) << ','
            << (weighted_mass > 0 ? 1.0/weighted_mass : std::numeric_limits<double>::infinity()) << '\n';
    }
    out.close();

    std::ofstream js(out_json);
    js << std::setprecision(17);
    js << "{\n";
    js << "  \"p_max\": " << pmax << ",\n";
    js << "  \"c_max\": " << cmax << ",\n";
    js << "  \"shift_count\": " << cs.size() << ",\n";
    js << "  \"primes_1_mod_24\": " << n << ",\n";
    js << "  \"covered\": " << covered << ",\n";
    js << "  \"all_first_witnesses_verified\": " << (witness_verified == covered ? "true" : "false") << ",\n";
    js << "  \"max_least_shift\": " << max_least_c << ",\n";
    js << "  \"max_least_shift_prime\": " << max_least_p << ",\n";
    js << "  \"min_uniform_mass\": " << min_uniform << ",\n";
    js << "  \"min_uniform_mass_prime\": " << min_uniform_p << ",\n";
    js << "  \"median_uniform_mass\": " << percentile(uniform_masses,0.5) << ",\n";
    js << "  \"p10_uniform_mass\": " << percentile(uniform_masses,0.1) << ",\n";
    js << "  \"p90_uniform_mass\": " << percentile(uniform_masses,0.9) << ",\n";
    js << "  \"min_weighted_mass\": " << min_weighted << ",\n";
    js << "  \"min_weighted_mass_prime\": " << min_weighted_p << ",\n";
    js << "  \"median_weighted_mass\": " << percentile(weighted_masses,0.5) << ",\n";
    js << "  \"median_uniform_expected_trials\": " << 1.0/percentile(uniform_masses,0.5) << ",\n";
    js << "  \"median_weighted_expected_trials\": " << 1.0/percentile(weighted_masses,0.5) << ",\n";
    js << "  \"least_shift_histogram\": {";
    bool first=true;
    for (auto [c,count] : least_hist) {
        if (!first) js << ',';
        js << "\n    \"" << c << "\": " << count;
        first=false;
    }
    if (!least_hist.empty()) js << '\n';
    js << "  }\n";
    js << "}\n";
    js.close();

    std::cerr << "processed=" << n << " covered=" << covered << " verified=" << witness_verified
              << " max_least_c=" << max_least_c << " at p=" << max_least_p << "\n";
    return covered == n && witness_verified == covered ? 0 : 2;
}
