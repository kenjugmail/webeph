#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

# Embed TrueType outlines rather than Type 3 bitmap-like PDF fonts.
plt.rcParams["pdf.fonttype"] = 42
plt.rcParams["ps.fonttype"] = 42

ROOT = Path(__file__).resolve().parents[1]
FIG = ROOT / "figures"
FIG.mkdir(exist_ok=True)

# SAT mass curves
sat_rows = []
with (ROOT / "results" / "sat_results.csv").open() as f:
    for row in csv.DictReader(f):
        if row["status"] == "SAT":
            sat_rows.append(row)
uniform = np.array([float(r["uniform_mass"]) for r in sat_rows])
learned = np.array([float(r["learned_mass"]) for r in sat_rows])
mixed = np.array([float(r["mixed_mass"]) for r in sat_rows])
order = np.argsort(uniform)
plt.figure(figsize=(6.4, 4.1))
plt.plot(np.arange(1, len(order)+1), np.log10(uniform[order]), label="Uniform")
plt.plot(np.arange(1, len(order)+1), np.log10(np.maximum(learned[order], 1e-300)), label="Learned product")
plt.plot(np.arange(1, len(order)+1), np.log10(mixed[order]), label="10% uniform + 90% learned")
plt.xlabel("SAT instances sorted by uniform witness mass")
plt.ylabel("log10 exact accepted mass")
plt.legend()
plt.tight_layout()
plt.savefig(FIG / "sat_mass_comparison.pdf")
plt.savefig(FIG / "sat_mass_comparison.png", dpi=200)
plt.close()

# SAT speedup CDF
speed = mixed / uniform
x = np.sort(speed)
y = np.arange(1, len(x)+1) / len(x)
plt.figure(figsize=(6.4, 4.1))
plt.semilogx(x, y)
plt.axvline(np.median(x), linestyle="--", label=f"median = {np.median(x):.1f}x")
plt.xlabel("Exact mass speedup of support-preserving learned generator")
plt.ylabel("Empirical cumulative fraction")
plt.legend()
plt.tight_layout()
plt.savefig(FIG / "sat_speedup_cdf.pdf")
plt.savefig(FIG / "sat_speedup_cdf.png", dpi=200)
plt.close()

# Erdős-Straus least-shift histogram
with (ROOT / "results" / "erdos_summary.json").open() as f:
    es_summary = json.load(f)
hist = {int(k): int(v) for k,v in es_summary["least_shift_histogram"].items()}
cs = np.array(sorted(hist))
counts = np.array([hist[c] for c in cs])
plt.figure(figsize=(6.4, 4.1))
plt.bar(cs.astype(str), counts)
plt.xlabel("Least successful shift c")
plt.ylabel("Number of primes p ≡ 1 (mod 24), p < 10^7")
plt.xticks(rotation=55)
plt.tight_layout()
plt.savefig(FIG / "erdos_least_shift.pdf")
plt.savefig(FIG / "erdos_least_shift.png", dpi=200)
plt.close()

# Erdős mass distributions
es_uniform = []
es_weighted = []
with (ROOT / "results" / "erdos_results.csv").open() as f:
    for row in csv.DictReader(f):
        es_uniform.append(float(row["uniform_mass"]))
        es_weighted.append(float(row["weighted_mass"]))
es_uniform = np.array(es_uniform)
es_weighted = np.array(es_weighted)
q = np.linspace(0, 1, 501)
plt.figure(figsize=(6.4, 4.1))
plt.plot(q, np.quantile(es_uniform, q), label="Uniform over shifts")
plt.plot(q, np.quantile(es_weighted, q), label="Small-shift prior")
plt.yscale("log")
plt.xlabel("Quantile over tested primes")
plt.ylabel("Exact accepted mass")
plt.legend()
plt.tight_layout()
plt.savefig(FIG / "erdos_mass_quantiles.pdf")
plt.savefig(FIG / "erdos_mass_quantiles.png", dpi=200)
plt.close()

# E-process null curves
curve = np.genfromtxt(ROOT / "results" / "eprocess_curves.csv", delimiter=",", names=True)
plt.figure(figsize=(6.4, 4.1))
plt.plot(curve["t"], curve["null_naive"], label="Repeated nominal 5% z-test")
plt.plot(curve["t"], curve["null_eprocess"], label="E-process threshold 1/alpha")
plt.axhline(0.05, linestyle="--", label="Nominal alpha = 0.05")
plt.xlabel("Monitoring time")
plt.ylabel("Cumulative false-certification rate under null")
plt.legend()
plt.tight_layout()
plt.savefig(FIG / "eprocess_null.pdf")
plt.savefig(FIG / "eprocess_null.png", dpi=200)
plt.close()

# E-process alternative power curves
plt.figure(figsize=(6.4, 4.1))
plt.plot(curve["t"], curve["alt_naive"], label="Repeated nominal z-test")
plt.plot(curve["t"], curve["alt_eprocess"], label="E-process")
plt.xlabel("Monitoring time")
plt.ylabel("Cumulative detection probability at p=0.60")
plt.legend()
plt.tight_layout()
plt.savefig(FIG / "eprocess_power.pdf")
plt.savefig(FIG / "eprocess_power.png", dpi=200)
plt.close()

print("wrote figures to", FIG)

# Quantifier-audit: probability a random benchmark misses one exceptional instance
qa = np.genfromtxt(ROOT / "results" / "quantifier_audit.csv", delimiter=",", names=True)
plt.figure(figsize=(6.4, 4.1))
for n in sorted(set(qa["n_instances"].astype(int))):
    mask = qa["n_instances"].astype(int) == n
    plt.semilogx(qa["draws"][mask], qa["exact_miss_probability"][mask], marker="o", label=f"N={n:,}")
plt.xlabel("Randomly benchmarked instances (with replacement)")
plt.ylabel("Probability of missing the unique exception")
plt.ylim(0, 1.02)
plt.legend()
plt.tight_layout()
plt.savefig(FIG / "quantifier_miss_probability.pdf")
plt.savefig(FIG / "quantifier_miss_probability.png", dpi=200)
plt.close()

# Rare positive mass: zero observed successes is not evidence of zero mass
rare = np.genfromtxt(ROOT / "results" / "rare_mass_sampling.csv", delimiter=",", names=True)
plt.figure(figsize=(6.4, 4.1))
for delta in sorted(set(rare["true_positive_mass"])):
    mask = rare["true_positive_mass"] == delta
    plt.loglog(rare["draws"][mask], rare["probability_observe_zero_successes"][mask], marker="o", label=f"delta={delta:g}")
plt.xlabel("Independent samples")
plt.ylabel("Probability of observing zero accepted witnesses")
plt.ylim(1e-6, 1.05)
plt.legend()
plt.tight_layout()
plt.savefig(FIG / "rare_mass_zero_hits.pdf")
plt.savefig(FIG / "rare_mass_zero_hits.png", dpi=200)
plt.close()

# Non-enumerative dynamic-programming mass backend
chain = np.genfromtxt(ROOT / "results" / "chain_wmc_results.csv", delimiter=",", names=True)
plt.figure(figsize=(6.4, 4.1))
plt.plot(chain["n"], chain["uniform_log10_mass"], marker="o", label="Uniform generator")
plt.plot(chain["n"], chain["learned_log10_mass"], marker="o", label="Biased product generator")
plt.plot(chain["n"], chain["mixed_log10_mass"], marker="o", label="5% uniform + 95% biased")
plt.xlabel("Path size n (witness space size = 2^n)")
plt.ylabel("log10 exact accepted mass")
plt.legend()
plt.tight_layout()
plt.savefig(FIG / "chain_wmc_mass.pdf")
plt.savefig(FIG / "chain_wmc_mass.png", dpi=200)
plt.close()

plt.figure(figsize=(6.4, 4.1))
plt.loglog(chain["n"], chain["uniform_dp_seconds"], marker="o", label="Uniform weights")
plt.loglog(chain["n"], chain["learned_dp_seconds"], marker="o", label="Biased weights")
plt.xlabel("Path size n")
plt.ylabel("Exact checker runtime (seconds)")
plt.legend()
plt.tight_layout()
plt.savefig(FIG / "chain_wmc_runtime.pdf")
plt.savefig(FIG / "chain_wmc_runtime.png", dpi=200)
plt.close()
