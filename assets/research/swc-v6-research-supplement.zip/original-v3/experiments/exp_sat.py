#!/usr/bin/env python3
"""Finite SWC experiment on small SAT instances.

We compare the exact witness mass under a uniform generator with a learned
product-Bernoulli generator. Learning is outside the trusted kernel; the final
accepted mass is recomputed exactly by exhaustive enumeration.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from fractions import Fraction
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def all_assignments(n: int) -> np.ndarray:
    vals = np.arange(1 << n, dtype=np.uint32)[:, None]
    shifts = np.arange(n, dtype=np.uint32)[None, :]
    return ((vals >> shifts) & 1).astype(np.uint8)


def generate_planted_formula(rng: np.random.Generator, n: int, m: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    planted = rng.integers(0, 2, size=n, dtype=np.uint8)
    vars_ = np.empty((m, 3), dtype=np.int16)
    desired = np.empty((m, 3), dtype=np.uint8)
    for j in range(m):
        v = rng.choice(n, size=3, replace=False)
        s = rng.integers(0, 2, size=3, dtype=np.uint8)
        if not np.any(planted[v] == s):
            k = int(rng.integers(0, 3))
            s[k] = planted[v[k]]
        vars_[j] = v
        desired[j] = s
    return vars_, desired, planted


def formula_scores(assignments: np.ndarray, vars_: np.ndarray, desired: np.ndarray) -> np.ndarray:
    # assignments: B x n, vars_: m x 3
    lit = assignments[:, vars_] == desired[None, :, :]
    return np.any(lit, axis=2).sum(axis=1)


def satisfying_mask(assignments: np.ndarray, vars_: np.ndarray, desired: np.ndarray) -> np.ndarray:
    return formula_scores(assignments, vars_, desired) == vars_.shape[0]


def cem_learn(
    rng: np.random.Generator,
    vars_: np.ndarray,
    desired: np.ndarray,
    n: int,
    sample_size: int = 4096,
    iterations: int = 18,
    elite_frac: float = 0.05,
    update_rate: float = 0.75,
) -> np.ndarray:
    probs = np.full(n, 0.5, dtype=np.float64)
    elite_n = max(8, int(sample_size * elite_frac))
    for _ in range(iterations):
        samples = (rng.random((sample_size, n)) < probs[None, :]).astype(np.uint8)
        scores = formula_scores(samples, vars_, desired)
        # Stable top-k; ties are harmless.
        elite_idx = np.argpartition(scores, -elite_n)[-elite_n:]
        elite_mean = samples[elite_idx].mean(axis=0)
        probs = (1.0 - update_rate) * probs + update_rate * elite_mean
        probs = np.clip(probs, 1.0 / 256.0, 255.0 / 256.0)
    numerators = np.clip(np.rint(probs * 256.0), 1, 255).astype(np.int64)
    return numerators


def exact_product_mass(sat_assignments: np.ndarray, numerators: np.ndarray, denominator: int = 256) -> tuple[int, int]:
    accepted_weight = 0
    for bits in sat_assignments:
        weight = 1
        for bit, k in zip(bits.tolist(), numerators.tolist()):
            weight *= int(k if bit else denominator - k)
        accepted_weight += weight
    total_weight = denominator ** sat_assignments.shape[1]
    return accepted_weight, total_weight


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", type=Path, default=ROOT / "results" / "sat_results.csv")
    ap.add_argument("--summary", type=Path, default=ROOT / "results" / "sat_summary.json")
    ap.add_argument("--seed", type=int, default=20260904)
    ap.add_argument("--n", type=int, default=16)
    ap.add_argument("--m", type=int, default=112)
    ap.add_argument("--sat", type=int, default=60)
    ap.add_argument("--unsat", type=int, default=20)
    args = ap.parse_args()

    rng = np.random.default_rng(args.seed)
    assignments = all_assignments(args.n)
    rows: list[dict[str, object]] = []

    formulas: list[tuple[str, np.ndarray, np.ndarray, np.ndarray | None]] = []
    for i in range(args.sat):
        vars_, desired, planted = generate_planted_formula(rng, args.n, args.m)
        formulas.append((f"sat_{i:03d}", vars_, desired, planted))
    for i in range(args.unsat):
        vars_, desired, planted = generate_planted_formula(rng, args.n, args.m - 2)
        # Add contradictory unit clauses encoded by repeating the same literal.
        v = int(rng.integers(0, args.n))
        vars_ = np.vstack([vars_, np.array([[v, v, v], [v, v, v]], dtype=np.int16)])
        desired = np.vstack([desired, np.array([[0, 0, 0], [1, 1, 1]], dtype=np.uint8)])
        formulas.append((f"unsat_{i:03d}", vars_, desired, None))

    for idx, (fid, vars_, desired, planted) in enumerate(formulas):
        mask = satisfying_mask(assignments, vars_, desired)
        sat_asgn = assignments[mask]
        count = int(mask.sum())
        uniform_mass_exact = Fraction(count, 1 << args.n)

        learned_nums = cem_learn(rng, vars_, desired, args.n)
        acc_w, total_w = exact_product_mass(sat_asgn, learned_nums)
        learned_mass_exact = Fraction(acc_w, total_w)
        mixed_mass_exact = Fraction(1, 10) * uniform_mass_exact + Fraction(9, 10) * learned_mass_exact

        # Support-collapse ablation: harden the learned product distribution to its
        # coordinate-wise mode.  This produces a point mass, which may assign
        # exactly zero probability to every satisfying assignment.  A 10%
        # uniform mixture restores a certified positive floor whenever the
        # instance is satisfiable.
        mode_assignment = (learned_nums >= (256 // 2)).astype(np.uint8)
        mode_accepts = bool(satisfying_mask(mode_assignment[None, :], vars_, desired)[0])
        hard_mass_exact = Fraction(1 if mode_accepts else 0, 1)
        hard_mixed_mass_exact = Fraction(1, 10) * uniform_mass_exact + Fraction(9, 10) * hard_mass_exact

        uniform_mass = float(uniform_mass_exact)
        learned_mass = float(learned_mass_exact)
        mixed_mass = float(mixed_mass_exact)
        hard_mass = float(hard_mass_exact)
        hard_mixed_mass = float(hard_mixed_mass_exact)
        speedup = (learned_mass / uniform_mass) if uniform_mass > 0 else math.nan
        mixed_speedup = (mixed_mass / uniform_mass) if uniform_mass > 0 else math.nan

        rows.append(
            {
                "formula_id": fid,
                "status": "SAT" if count > 0 else "UNSAT",
                "n_vars": args.n,
                "n_clauses": int(vars_.shape[0]),
                "n_solutions": count,
                "uniform_mass": uniform_mass,
                "learned_mass": learned_mass,
                "mass_speedup": speedup,
                "mixed_mass": mixed_mass,
                "mixed_mass_speedup": mixed_speedup,
                "mode_assignment_satisfies": mode_accepts,
                "hard_point_mass": hard_mass,
                "hard_uniform_mixture_mass": hard_mixed_mass,
                "hard_uniform_mixture_numerator": str(hard_mixed_mass_exact.numerator),
                "hard_uniform_mixture_denominator": str(hard_mixed_mass_exact.denominator),
                "uniform_mass_numerator": str(uniform_mass_exact.numerator),
                "uniform_mass_denominator": str(uniform_mass_exact.denominator),
                "learned_weight_numerator": str(learned_mass_exact.numerator),
                "learned_weight_denominator": str(learned_mass_exact.denominator),
                "mixed_mass_numerator": str(mixed_mass_exact.numerator),
                "mixed_mass_denominator": str(mixed_mass_exact.denominator),
                "learned_prob_numerators": " ".join(map(str, learned_nums.tolist())),
                "planted_found": bool(planted is not None and np.any(np.all(sat_asgn == planted[None, :], axis=1))),
            }
        )

    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    sat_rows = [r for r in rows if r["status"] == "SAT"]
    unsat_rows = [r for r in rows if r["status"] == "UNSAT"]
    speedups = np.array([float(r["mass_speedup"]) for r in sat_rows], dtype=float)
    unif = np.array([float(r["uniform_mass"]) for r in sat_rows], dtype=float)
    learned = np.array([float(r["learned_mass"]) for r in sat_rows], dtype=float)
    mixed = np.array([float(r["mixed_mass"]) for r in sat_rows], dtype=float)
    mixed_speedups = np.array([float(r["mixed_mass_speedup"]) for r in sat_rows], dtype=float)
    mode_successes = sum(bool(r["mode_assignment_satisfies"]) for r in sat_rows)
    hard_mixed = np.array([float(r["hard_uniform_mixture_mass"]) for r in sat_rows], dtype=float)
    summary = {
        "seed": args.seed,
        "n_vars": args.n,
        "clauses": args.m,
        "sat_instances": len(sat_rows),
        "unsat_instances": len(unsat_rows),
        "all_planted_instances_certified_positive": all(int(r["n_solutions"]) > 0 for r in sat_rows),
        "all_unsat_instances_certified_zero": all(int(r["n_solutions"]) == 0 for r in unsat_rows),
        "median_uniform_mass": float(np.median(unif)),
        "median_learned_mass": float(np.median(learned)),
        "median_mass_speedup": float(np.median(speedups)),
        "median_mixed_mass": float(np.median(mixed)),
        "median_mixed_mass_speedup": float(np.median(mixed_speedups)),
        "geometric_mean_mixed_mass_speedup": float(np.exp(np.mean(np.log(mixed_speedups)))),
        "min_mixed_mass_speedup": float(np.min(mixed_speedups)),
        "geometric_mean_mass_speedup": float(np.exp(np.mean(np.log(speedups)))),
        "min_mass_speedup": float(np.min(speedups)),
        "max_mass_speedup": float(np.max(speedups)),
        "hardened_mode_satisfying_instances": int(mode_successes),
        "hardened_mode_zero_mass_instances": int(len(sat_rows) - mode_successes),
        "all_hard_mixtures_certified_positive": bool(np.all(hard_mixed > 0.0)),
        "min_hard_mixture_mass": float(np.min(hard_mixed)),
        "median_uniform_expected_trials": float(np.median(1.0 / unif)),
        "median_learned_expected_trials": float(np.median(1.0 / learned)),
        "median_mixed_expected_trials": float(np.median(1.0 / mixed)),
    }
    args.summary.write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
