#!/usr/bin/env python3
"""Quantifier-audit stress tests for Stochastic Witness Calculus.

The experiment illustrates two logically distinct failure modes:
  1. A high average/empirical success rate can hide a single zero-mass instance.
  2. Observing no successes in finite sampling does not prove that true mass is zero.

All theoretical probabilities are computed analytically. Seeded simulations are used only
as a sanity check and are reported separately from the exact formulas.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import time
from pathlib import Path

import numpy as np


def miss_unique_exception_probability(n_instances: int, draws: int) -> float:
    if n_instances <= 0 or draws < 0:
        raise ValueError("invalid n_instances/draws")
    if draws == 0:
        return 1.0
    return math.exp(draws * math.log1p(-1.0 / n_instances))


def no_success_probability(delta: float, draws: int) -> float:
    if not (0.0 < delta < 1.0) or draws < 0:
        raise ValueError("invalid delta/draws")
    if draws == 0:
        return 1.0
    return math.exp(draws * math.log1p(-delta))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="results/quantifier_audit.csv")
    parser.add_argument("--rare-out", default="results/rare_mass_sampling.csv")
    parser.add_argument("--summary", default="results/quantifier_audit_summary.json")
    parser.add_argument("--seed", type=int, default=20260904)
    parser.add_argument("--repetitions", type=int, default=20000)
    args = parser.parse_args()

    root = Path(__file__).resolve().parents[1]
    out = root / args.out
    rare_out = root / args.rare_out
    summary_out = root / args.summary
    out.parent.mkdir(parents=True, exist_ok=True)

    rng = np.random.default_rng(args.seed)
    n_values = [10**3, 10**4, 10**5, 10**6]
    draw_values = [10, 100, 1000, 10000, 100000]

    rows: list[dict[str, float | int]] = []
    max_abs_err = 0.0
    for n in n_values:
        for k in draw_values:
            exact_miss = miss_unique_exception_probability(n, k)
            # Simulation of whether a benchmark hits the exceptional instance at least once.
            # We simulate the Bernoulli event using its exact probability to avoid allocating
            # repetitions x draws random integers for the largest cells.
            simulated_miss = float(np.mean(rng.random(args.repetitions) < exact_miss))
            err = abs(simulated_miss - exact_miss)
            max_abs_err = max(max_abs_err, err)
            rows.append({
                "n_instances": n,
                "draws": k,
                "exact_miss_probability": exact_miss,
                "simulated_miss_rate": simulated_miss,
                "absolute_error": err,
            })

    with out.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    deltas = [1e-2, 1e-4, 1e-6, 1e-8]
    rare_draws = [10**2, 10**3, 10**4, 10**5, 10**6, 10**7, 10**8]
    rare_rows: list[dict[str, float | int]] = []
    for delta in deltas:
        for k in rare_draws:
            rare_rows.append({
                "true_positive_mass": delta,
                "draws": k,
                "probability_observe_zero_successes": no_success_probability(delta, k),
                "expected_successes": delta * k,
            })
    with rare_out.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rare_rows[0].keys()))
        writer.writeheader()
        writer.writerows(rare_rows)

    # A direct pointwise scan catches a hidden zero exactly. This is a runtime illustration,
    # not a claim that universal theorem checking is generally linear-time.
    audit_sizes = [10**3, 10**4, 10**5, 10**6, 5 * 10**6]
    audit_timings: list[dict[str, float | int | bool]] = []
    for n in audit_sizes:
        masses = np.ones(n, dtype=np.uint8)
        hidden = int(rng.integers(0, n))
        masses[hidden] = 0
        start = time.perf_counter()
        minimum = int(masses.min())
        zero_positions = np.flatnonzero(masses == 0)
        elapsed = time.perf_counter() - start
        audit_timings.append({
            "n_instances": n,
            "hidden_exception_index": hidden,
            "found_exception_index": int(zero_positions[0]),
            "minimum_mass_indicator": minimum,
            "elapsed_seconds": elapsed,
            "correct": bool(len(zero_positions) == 1 and int(zero_positions[0]) == hidden),
        })

    summary = {
        "seed": args.seed,
        "simulation_repetitions_per_cell": args.repetitions,
        "max_simulation_absolute_error": max_abs_err,
        "unique_exception_examples": {
            "N_1e6_k_1e4_miss_probability": miss_unique_exception_probability(10**6, 10**4),
            "N_1e6_k_1e5_miss_probability": miss_unique_exception_probability(10**6, 10**5),
        },
        "rare_mass_examples": {
            "delta_1e-6_k_1e5_zero_hit_probability": no_success_probability(1e-6, 10**5),
            "delta_1e-8_k_1e6_zero_hit_probability": no_success_probability(1e-8, 10**6),
        },
        "pointwise_audit_timings": audit_timings,
        "interpretation": [
            "Random benchmarking can miss a single universal counterexample with high probability.",
            "Zero observed successes is compatible with strictly positive but rare witness mass.",
            "Neither phenomenon is a proof; exact pointwise or symbolic certificates are required.",
        ],
    }
    with summary_out.open("w") as f:
        json.dump(summary, f, indent=2)

    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
