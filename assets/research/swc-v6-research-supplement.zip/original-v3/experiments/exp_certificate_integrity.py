#!/usr/bin/env python3
"""Stress-test the proof-carrying path-mass certificate boundary.

Valid certificates are produced by an untrusted producer and independently
recomputed by the small checker. Each valid certificate is then subjected to
six deterministic mutations. The experiment records whether the checker rejects
all altered claims and all floating-point-only pseudo-certificates.
"""
from __future__ import annotations

import argparse
import copy
import csv
import json
import random
import time
import statistics
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.path_certificate import (
    CertificateError,
    make_path_mass_certificate,
    verify_path_mass_certificate,
)


def mutate(cert: dict, attack: str) -> dict:
    out = copy.deepcopy(cert)
    if attack == "accepted_numerator_plus_one":
        x = int(out["mass_certificate"]["accepted_numerator"])
        out["mass_certificate"]["accepted_numerator"] = str(x + 1)
    elif attack == "common_denominator_plus_one":
        x = int(out["mass_certificate"]["common_denominator"])
        out["mass_certificate"]["common_denominator"] = str(x + 1)
    elif attack == "semantic_instance_tamper":
        out["claim"]["instance"]["k"] += 1
    elif attack == "distribution_tamper":
        d = out["claim"]["distribution"]["denominator"]
        w = out["claim"]["distribution"]["one_weight"]
        out["claim"]["distribution"]["one_weight"] = w + 1 if w + 1 < d else w - 1
    elif attack == "unsupported_schema":
        out["schema_version"] = "swc.path-mass.v999"
    elif attack == "float_only_mass":
        out["mass_certificate"].pop("accepted_numerator", None)
        out["mass_certificate"].pop("common_denominator", None)
        out["mass_certificate"].pop("reduced_numerator", None)
        out["mass_certificate"].pop("reduced_denominator", None)
        out["mass_certificate"]["estimated_mass"] = 0.123456789
    else:
        raise ValueError(attack)
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="results/certificate_integrity.csv")
    parser.add_argument("--summary", default="results/certificate_integrity_summary.json")
    parser.add_argument("--seed", type=int, default=20260904)
    parser.add_argument("--certificates", type=int, default=300)
    args = parser.parse_args()

    root = ROOT
    out_path = root / args.out
    summary_path = root / args.summary
    out_path.parent.mkdir(parents=True, exist_ok=True)

    rng = random.Random(args.seed)
    sizes = [16, 24, 32, 48, 64, 96, 128, 160, 192, 224, 256]
    weights = [32, 48, 64, 80, 96, 112, 128, 144, 160, 176, 192, 208, 224]
    attacks = [
        "accepted_numerator_plus_one",
        "common_denominator_plus_one",
        "semantic_instance_tamper",
        "distribution_tamper",
        "unsupported_schema",
        "float_only_mass",
    ]

    rows: list[dict[str, object]] = []
    valid_accepts = 0
    tampered_rejections = 0
    tampered_total = 0
    max_check_seconds = 0.0
    total_check_seconds = 0.0
    valid_check_seconds: list[float] = []
    all_check_seconds: list[float] = []

    for cert_id in range(args.certificates):
        n = rng.choice(sizes)
        max_k = (n + 1) // 2
        # Keep both rare and common events in the suite while guaranteeing k is valid.
        k = rng.randint(max(0, n // 8), min(max_k, max(1, 3 * n // 8)))
        one_weight = rng.choice(weights)
        cert = make_path_mass_certificate(n, k, one_weight, 256)

        start = time.perf_counter()
        verified = verify_path_mass_certificate(cert)
        elapsed = time.perf_counter() - start
        max_check_seconds = max(max_check_seconds, elapsed)
        total_check_seconds += elapsed
        valid_check_seconds.append(elapsed)
        all_check_seconds.append(elapsed)
        accepted = verified.proves_existence
        valid_accepts += int(accepted)
        rows.append({
            "certificate_id": cert_id,
            "kind": "valid",
            "attack": "none",
            "n": n,
            "k": k,
            "one_weight": one_weight,
            "checker_accepted": True,
            "checker_seconds": elapsed,
            "reason": "exact recomputation matched",
        })

        for attack in attacks:
            tampered_total += 1
            bad = mutate(cert, attack)
            start = time.perf_counter()
            try:
                verify_path_mass_certificate(bad)
                rejected = False
                reason = "NOT REJECTED"
            except CertificateError as exc:
                rejected = True
                reason = str(exc)
            elapsed_bad = time.perf_counter() - start
            max_check_seconds = max(max_check_seconds, elapsed_bad)
            total_check_seconds += elapsed_bad
            all_check_seconds.append(elapsed_bad)
            tampered_rejections += int(rejected)
            rows.append({
                "certificate_id": cert_id,
                "kind": "tampered",
                "attack": attack,
                "n": n,
                "k": k,
                "one_weight": one_weight,
                "checker_accepted": not rejected,
                "checker_seconds": elapsed_bad,
                "reason": reason,
            })

    with out_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    ordered_times = sorted(all_check_seconds)
    p99_index = min(len(ordered_times) - 1, max(0, int(0.99 * len(ordered_times)) - 1))
    summary = {
        "seed": args.seed,
        "valid_certificates": args.certificates,
        "valid_certificates_accepted": valid_accepts,
        "tampered_certificates": tampered_total,
        "tampered_certificates_rejected": tampered_rejections,
        "attacks_per_valid_certificate": attacks,
        "all_valid_accepted": valid_accepts == args.certificates,
        "all_tampered_rejected": tampered_rejections == tampered_total,
        "mean_checker_seconds_per_object": total_check_seconds / len(rows),
        "median_valid_checker_seconds": statistics.median(valid_check_seconds),
        "p99_checker_seconds_all_objects": ordered_times[p99_index],
        "max_checker_seconds_per_object": max_check_seconds,
        "trusted_features": [
            "canonical SHA-256 claim binding",
            "exact dynamic-programming recomputation",
            "exact integer normalization",
            "exact reduced-fraction check",
            "strict rejection of floating-point-only positivity",
        ],
    }
    with summary_path.open("w") as f:
        json.dump(summary, f, indent=2)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
