#!/usr/bin/env python3
"""Sequential inference experiment for the physical-certification mode.

Compares:
  1. repeatedly applying a nominal 5% one-sided z-test without correction;
  2. a likelihood-ratio e-process with threshold 1/alpha.

The e-process is a nonnegative martingale under Bernoulli(0.5), so Ville's
inequality gives a time-uniform type-I error bound.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def wilson_halfwidth(p: float, n: int, z: float = 1.96) -> float:
    if n <= 0:
        return float("nan")
    denom = 1.0 + z*z/n
    return z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/denom


def run_paths(rng: np.random.Generator, prob: float, paths: int, horizon: int, alpha: float, q_alt: float):
    x = rng.random((paths, horizon)) < prob
    s = np.cumsum(x, axis=1)
    t = np.arange(1, horizon + 1, dtype=np.float64)[None, :]

    # Naive repeated one-sided z tests, started after t=20.
    zstat = (s - 0.5*t) / np.sqrt(0.25*t)
    naive_cross_matrix = (zstat >= 1.6448536269514722)
    naive_cross_matrix[:, :19] = False
    naive_cross = np.any(naive_cross_matrix, axis=1)
    naive_first = np.where(naive_cross, np.argmax(naive_cross_matrix, axis=1) + 1, horizon + 1)

    # Fixed-alternative likelihood-ratio e-process for H0: p=0.5 vs q_alt.
    log_e = s*np.log(q_alt/0.5) + (t-s)*np.log((1.0-q_alt)/0.5)
    threshold = np.log(1.0/alpha)
    e_cross_matrix = log_e >= threshold
    e_cross = np.any(e_cross_matrix, axis=1)
    e_first = np.where(e_cross, np.argmax(e_cross_matrix, axis=1) + 1, horizon + 1)

    cumulative_naive = np.mean(np.maximum.accumulate(naive_cross_matrix, axis=1), axis=0)
    cumulative_e = np.mean(np.maximum.accumulate(e_cross_matrix, axis=1), axis=0)
    return {
        "naive_cross": naive_cross,
        "naive_first": naive_first,
        "e_cross": e_cross,
        "e_first": e_first,
        "cumulative_naive": cumulative_naive,
        "cumulative_e": cumulative_e,
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", type=Path, default=ROOT / "results" / "eprocess_summary.json")
    ap.add_argument("--curves", type=Path, default=ROOT / "results" / "eprocess_curves.csv")
    ap.add_argument("--seed", type=int, default=20260904)
    ap.add_argument("--paths", type=int, default=50000)
    ap.add_argument("--horizon", type=int, default=500)
    ap.add_argument("--alpha", type=float, default=0.05)
    ap.add_argument("--alternative", type=float, default=0.60)
    args = ap.parse_args()

    rng = np.random.default_rng(args.seed)
    null = run_paths(rng, 0.5, args.paths, args.horizon, args.alpha, args.alternative)
    alt = run_paths(rng, args.alternative, args.paths, args.horizon, args.alpha, args.alternative)

    null_naive_rate = float(np.mean(null["naive_cross"]))
    null_e_rate = float(np.mean(null["e_cross"]))
    alt_naive_power = float(np.mean(alt["naive_cross"]))
    alt_e_power = float(np.mean(alt["e_cross"]))

    alt_e_stops = alt["e_first"][alt["e_cross"]]
    alt_naive_stops = alt["naive_first"][alt["naive_cross"]]
    summary = {
        "seed": args.seed,
        "paths_per_condition": args.paths,
        "horizon": args.horizon,
        "alpha": args.alpha,
        "null_probability": 0.5,
        "alternative_probability": args.alternative,
        "naive_repeated_test_null_crossing_rate": null_naive_rate,
        "naive_repeated_test_null_95pct_halfwidth": wilson_halfwidth(null_naive_rate, args.paths),
        "eprocess_null_crossing_rate": null_e_rate,
        "eprocess_null_95pct_halfwidth": wilson_halfwidth(null_e_rate, args.paths),
        "naive_power_at_alternative": alt_naive_power,
        "eprocess_power_at_alternative": alt_e_power,
        "naive_median_stop_given_crossing": float(np.median(alt_naive_stops)) if alt_naive_stops.size else None,
        "eprocess_median_stop_given_crossing": float(np.median(alt_e_stops)) if alt_e_stops.size else None,
        "ville_bound": args.alpha,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(summary, indent=2))

    with args.curves.open("w") as f:
        f.write("t,null_naive,null_eprocess,alt_naive,alt_eprocess\n")
        for i in range(args.horizon):
            f.write(f"{i+1},{null['cumulative_naive'][i]:.12g},{null['cumulative_e'][i]:.12g},{alt['cumulative_naive'][i]:.12g},{alt['cumulative_e'][i]:.12g}\n")

    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
