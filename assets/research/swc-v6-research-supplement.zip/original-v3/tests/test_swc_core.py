from fractions import Fraction
import unittest

from src.swc_core import (
    FiniteMassCertificate,
    exact_product_mass,
    exact_weighted_mixture,
    sequential_mass_lower_bound,
    change_of_measure_lower_bound,
    paley_zygmund_positive_mass_lower_bound,
    exact_conditioned_mass,
    universal_pointwise_check,
)


class TestFiniteKernel(unittest.TestCase):
    def test_positive_certificate_extracts_witness(self) -> None:
        cert = FiniteMassCertificate(
            instance=6,
            witnesses=[0, 1, 2, 3, 4, 5, 6],
            weights=[1] * 7,
            verifier=lambda n, w: w * w == n,
        )
        result = cert.check()
        self.assertFalse(result.proves_existence)
        self.assertEqual(result.accepted_mass, Fraction(0, 1))

        cert2 = FiniteMassCertificate(
            instance=9,
            witnesses=[0, 1, 2, 3],
            weights=[1, 2, 3, 4],
            verifier=lambda n, w: w * w == n,
        )
        result2 = cert2.check()
        self.assertTrue(result2.proves_existence)
        self.assertEqual(result2.first_positive_mass_witness, 3)
        self.assertEqual(result2.accepted_mass, Fraction(4, 10))
        self.assertEqual(result2.expected_trials, Fraction(5, 2))

    def test_exact_mixture_floor(self) -> None:
        baseline = Fraction(1, 100)
        learned = Fraction(0, 1)
        mixed = exact_weighted_mixture([baseline, learned], [1, 9])
        self.assertEqual(mixed, Fraction(1, 1000))
        self.assertGreater(mixed, 0)

    def test_product_and_sequential_rules(self) -> None:
        self.assertEqual(exact_product_mass([Fraction(1, 2), Fraction(2, 3)]), Fraction(1, 3))
        self.assertEqual(sequential_mass_lower_bound(Fraction(1, 4), Fraction(3, 5)), Fraction(3, 20))

    def test_invalid_weights_rejected(self) -> None:
        with self.assertRaises(ValueError):
            exact_weighted_mixture([Fraction(1, 2)], [0])
        with self.assertRaises(ValueError):
            exact_product_mass([Fraction(3, 2)])


class ExtendedCalculusTests(unittest.TestCase):
    def test_change_of_measure(self):
        self.assertEqual(
            change_of_measure_lower_bound(Fraction(1, 8), Fraction(4, 1)),
            Fraction(1, 32),
        )

    def test_paley_zygmund(self):
        self.assertEqual(
            paley_zygmund_positive_mass_lower_bound(Fraction(1, 2), Fraction(3, 4)),
            Fraction(1, 3),
        )

    def test_conditioning(self):
        self.assertEqual(
            exact_conditioned_mass(Fraction(1, 8), Fraction(1, 2)),
            Fraction(1, 4),
        )

    def test_pointwise_quantifier_guard(self):
        ok, bad = universal_pointwise_check([
            Fraction(1, 2), Fraction(1, 100), Fraction(0, 1), Fraction(1, 7)
        ])
        self.assertFalse(ok)
        self.assertEqual(bad, 2)


class ProofCarryingPathCertificateTests(unittest.TestCase):
    def test_round_trip_and_exact_mass(self):
        from src.path_certificate import make_path_mass_certificate, verify_path_mass_certificate

        cert = make_path_mass_certificate(n=32, k=8, one_weight=64, denominator=256)
        result = verify_path_mass_certificate(cert)
        self.assertTrue(result.proves_existence)
        self.assertGreater(result.mass, 0)

    def test_tampered_mass_rejected(self):
        import copy
        from src.path_certificate import CertificateError, make_path_mass_certificate, verify_path_mass_certificate

        cert = make_path_mass_certificate(n=24, k=6, one_weight=96, denominator=256)
        bad = copy.deepcopy(cert)
        bad["mass_certificate"]["accepted_numerator"] = str(
            int(bad["mass_certificate"]["accepted_numerator"]) + 1
        )
        with self.assertRaises(CertificateError):
            verify_path_mass_certificate(bad)

    def test_float_only_mass_rejected(self):
        import copy
        from src.path_certificate import CertificateError, make_path_mass_certificate, verify_path_mass_certificate

        cert = make_path_mass_certificate(n=16, k=4, one_weight=128, denominator=256)
        bad = copy.deepcopy(cert)
        for key in ("accepted_numerator", "common_denominator", "reduced_numerator", "reduced_denominator"):
            bad["mass_certificate"].pop(key)
        bad["mass_certificate"]["estimated_mass"] = 0.5
        with self.assertRaises(CertificateError):
            verify_path_mass_certificate(bad)


if __name__ == "__main__":
    unittest.main()
