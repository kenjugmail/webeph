from fractions import Fraction
import json, hashlib, unittest

class TestSWCInvariants(unittest.TestCase):
    def test_positive_mass_implies_nonempty_finite(self):
        weights=[1,2,3]; accept=[False,True,False]
        mass=Fraction(sum(w for w,a in zip(weights,accept) if a),sum(weights))
        self.assertGreater(mass,0)
        self.assertTrue(any(accept))

    def test_average_not_pointwise(self):
        masses=[Fraction(1,3),Fraction(1,3),Fraction(0)]
        self.assertGreater(sum(masses,Fraction(0))/len(masses),0)
        self.assertFalse(all(m>0 for m in masses))

    def test_support_preserving_mixture(self):
        baseline=Fraction(1,1000); learned=Fraction(0); eps=Fraction(1,10)
        mixed=eps*baseline+(1-eps)*learned
        self.assertGreater(mixed,0)
        self.assertEqual(mixed,Fraction(1,10000))

    def test_product_rule(self):
        a=Fraction(2,7); b=Fraction(3,11)
        self.assertEqual(a*b,Fraction(6,77))
        self.assertGreater(a*b,0)

    def test_float_underflow_is_not_zero_mass(self):
        exact=Fraction(1,2**2000)
        self.assertGreater(exact,0)
        self.assertEqual(float(exact),0.0)

if __name__=='__main__': unittest.main()
