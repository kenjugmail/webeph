"""Proof-carrying exact mass certificates for a structured path-graph witness family.

The certificate producer is untrusted. The checker binds the claim to a canonical
instance/distribution digest, recomputes the exact weighted count by dynamic
programming, checks normalization, and only then accepts a positivity claim.

This module is intentionally small and uses only Python integers, fractions, JSON,
and SHA-256 from the standard library.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
import hashlib
import json
from typing import Any, Mapping

SCHEMA_VERSION = "swc.path-mass.v1"


class CertificateError(ValueError):
    """Raised when a proof-carrying mass certificate fails validation."""


def _require_int(value: Any, field: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise CertificateError(f"{field} must be an integer")
    return value


def canonical_claim_payload(n: int, k: int, one_weight: int, denominator: int) -> dict[str, int]:
    return {
        "n": int(n),
        "k": int(k),
        "one_weight": int(one_weight),
        "denominator": int(denominator),
    }


def claim_digest(n: int, k: int, one_weight: int, denominator: int) -> str:
    payload = canonical_claim_payload(n, k, one_weight, denominator)
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def exact_path_independent_set_weight(n: int, k: int, one_weight: int, denominator: int) -> int:
    """Exact numerator for independent sets of size k in P_n.

    Each bit string receives product Bernoulli numerator weight
    one_weight^ones * (denominator-one_weight)^zeros. The common denominator
    is denominator**n. The recurrence runs in O(nk) exact integer operations.
    """
    if n < 0:
        raise CertificateError("n must be nonnegative")
    if k < 0:
        raise CertificateError("k must be nonnegative")
    if denominator <= 1:
        raise CertificateError("denominator must exceed one")
    if not (0 < one_weight < denominator):
        raise CertificateError("one_weight must lie strictly between zero and denominator")
    if k > (n + 1) // 2:
        return 0

    zero_weight = denominator - one_weight
    dp0 = [0] * (k + 1)
    dp1 = [0] * (k + 1)
    dp0[0] = 1
    for _ in range(n):
        next0 = [0] * (k + 1)
        next1 = [0] * (k + 1)
        for j in range(k + 1):
            next0[j] = (dp0[j] + dp1[j]) * zero_weight
            if j:
                next1[j] = dp0[j - 1] * one_weight
        dp0, dp1 = next0, next1
    return dp0[k] + dp1[k]


@dataclass(frozen=True)
class VerifiedPathMass:
    n: int
    k: int
    one_weight: int
    denominator: int
    accepted_numerator: int
    total_denominator: int

    @property
    def mass(self) -> Fraction:
        return Fraction(self.accepted_numerator, self.total_denominator)

    @property
    def proves_existence(self) -> bool:
        return self.accepted_numerator > 0


def make_path_mass_certificate(n: int, k: int, one_weight: int, denominator: int = 256) -> dict[str, Any]:
    numerator = exact_path_independent_set_weight(n, k, one_weight, denominator)
    total = denominator ** n
    reduced = Fraction(numerator, total)
    return {
        "schema_version": SCHEMA_VERSION,
        "claim": {
            "kind": "path_independent_set_exact_size",
            "instance": {"n": n, "k": k},
            "distribution": {
                "kind": "product_bernoulli_integer_weights",
                "one_weight": one_weight,
                "denominator": denominator,
            },
            "digest_sha256": claim_digest(n, k, one_weight, denominator),
        },
        "mass_certificate": {
            "backend": "exact_dynamic_programming",
            "accepted_numerator": str(numerator),
            "common_denominator": str(total),
            "reduced_numerator": str(reduced.numerator),
            "reduced_denominator": str(reduced.denominator),
            "strictly_positive": numerator > 0,
        },
    }


def _parse_decimal_int(value: Any, field: str) -> int:
    if not isinstance(value, str) or not value or any(ch not in "0123456789" for ch in value):
        raise CertificateError(f"{field} must be a nonnegative base-10 integer string")
    return int(value)


def verify_path_mass_certificate(cert: Mapping[str, Any]) -> VerifiedPathMass:
    if not isinstance(cert, Mapping):
        raise CertificateError("certificate must be a mapping")
    if cert.get("schema_version") != SCHEMA_VERSION:
        raise CertificateError("unsupported schema version")

    claim = cert.get("claim")
    mass_claim = cert.get("mass_certificate")
    if not isinstance(claim, Mapping) or not isinstance(mass_claim, Mapping):
        raise CertificateError("missing claim or mass_certificate object")
    if claim.get("kind") != "path_independent_set_exact_size":
        raise CertificateError("unsupported claim kind")
    if mass_claim.get("backend") != "exact_dynamic_programming":
        raise CertificateError("untrusted or unsupported mass backend")

    instance = claim.get("instance")
    distribution = claim.get("distribution")
    if not isinstance(instance, Mapping) or not isinstance(distribution, Mapping):
        raise CertificateError("missing instance or distribution")
    if distribution.get("kind") != "product_bernoulli_integer_weights":
        raise CertificateError("unsupported distribution kind")

    n = _require_int(instance.get("n"), "claim.instance.n")
    k = _require_int(instance.get("k"), "claim.instance.k")
    one_weight = _require_int(distribution.get("one_weight"), "claim.distribution.one_weight")
    denominator = _require_int(distribution.get("denominator"), "claim.distribution.denominator")

    expected_digest = claim_digest(n, k, one_weight, denominator)
    if claim.get("digest_sha256") != expected_digest:
        raise CertificateError("claim digest mismatch")

    claimed_num = _parse_decimal_int(mass_claim.get("accepted_numerator"), "accepted_numerator")
    claimed_den = _parse_decimal_int(mass_claim.get("common_denominator"), "common_denominator")
    reduced_num = _parse_decimal_int(mass_claim.get("reduced_numerator"), "reduced_numerator")
    reduced_den = _parse_decimal_int(mass_claim.get("reduced_denominator"), "reduced_denominator")
    positive_flag = mass_claim.get("strictly_positive")
    if not isinstance(positive_flag, bool):
        raise CertificateError("strictly_positive must be Boolean")

    exact_num = exact_path_independent_set_weight(n, k, one_weight, denominator)
    exact_den = denominator ** n
    exact_reduced = Fraction(exact_num, exact_den)

    if claimed_num != exact_num:
        raise CertificateError("accepted numerator mismatch")
    if claimed_den != exact_den:
        raise CertificateError("common denominator mismatch")
    if (reduced_num, reduced_den) != (exact_reduced.numerator, exact_reduced.denominator):
        raise CertificateError("reduced fraction mismatch")
    if positive_flag != (exact_num > 0):
        raise CertificateError("positivity flag mismatch")

    return VerifiedPathMass(
        n=n,
        k=k,
        one_weight=one_weight,
        denominator=denominator,
        accepted_numerator=exact_num,
        total_denominator=exact_den,
    )
