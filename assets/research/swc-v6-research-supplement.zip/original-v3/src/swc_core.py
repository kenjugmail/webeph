"""Core utilities for finite Stochastic Witness Calculus (SWC) certificates.

The prototype intentionally keeps the trusted kernel small:
  * a finite witness list,
  * exact nonnegative integer weights,
  * a deterministic verifier,
  * exact accepted/total mass arithmetic.

A positive accepted mass is a certificate that at least one accepted witness exists.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Callable, Generic, Iterable, Sequence, TypeVar

W = TypeVar("W")
I = TypeVar("I")


@dataclass(frozen=True)
class FiniteMassCertificate(Generic[I, W]):
    instance: I
    witnesses: Sequence[W]
    weights: Sequence[int]
    verifier: Callable[[I, W], bool]

    def check(self) -> "CertificateResult[W]":
        if len(self.witnesses) != len(self.weights):
            raise ValueError("witness and weight arrays must have the same length")
        if not self.witnesses:
            raise ValueError("witness space must be nonempty")
        if any((not isinstance(w, int)) or w < 0 for w in self.weights):
            raise ValueError("weights must be nonnegative integers")
        total = sum(self.weights)
        if total <= 0:
            raise ValueError("total mass must be positive")

        accepted_weight = 0
        accepted: list[W] = []
        for witness, weight in zip(self.witnesses, self.weights):
            if self.verifier(self.instance, witness):
                accepted_weight += weight
                if weight > 0:
                    accepted.append(witness)

        return CertificateResult(
            total_weight=total,
            accepted_weight=accepted_weight,
            accepted_mass=Fraction(accepted_weight, total),
            first_positive_mass_witness=accepted[0] if accepted else None,
        )


@dataclass(frozen=True)
class CertificateResult(Generic[W]):
    total_weight: int
    accepted_weight: int
    accepted_mass: Fraction
    first_positive_mass_witness: W | None

    @property
    def proves_existence(self) -> bool:
        return self.accepted_weight > 0

    @property
    def expected_trials(self) -> Fraction | None:
        if self.accepted_weight == 0:
            return None
        return Fraction(self.total_weight, self.accepted_weight)


def product_bernoulli_integer_weights(bit_vectors: Iterable[tuple[int, ...]], numerators: Sequence[int], denominator: int) -> list[int]:
    """Return integer weights under a product Bernoulli distribution.

    If P[X_i=1]=numerators[i]/denominator, every vector has a common
    denominator denominator**n, so the returned numerator weights are exact.
    """
    if denominator <= 1:
        raise ValueError("denominator must exceed 1")
    if any(k <= 0 or k >= denominator for k in numerators):
        raise ValueError("Bernoulli numerators must lie strictly between 0 and denominator")

    weights: list[int] = []
    for bits in bit_vectors:
        if len(bits) != len(numerators):
            raise ValueError("bit-vector length mismatch")
        weight = 1
        for bit, k in zip(bits, numerators):
            weight *= k if bit else denominator - k
        weights.append(weight)
    return weights


def exact_weighted_mixture(masses: Sequence[Fraction], mixture_weights: Sequence[int]) -> Fraction:
    """Combine exact masses under a finite mixture with integer component weights.

    The component weights are normalized internally. This is useful for certificate
    combinators because it avoids introducing floating-point arithmetic into the
    trusted mass calculation.
    """
    if len(masses) != len(mixture_weights):
        raise ValueError("mass and mixture-weight arrays must have the same length")
    if not masses:
        raise ValueError("at least one component is required")
    if any((not isinstance(weight, int)) or weight < 0 for weight in mixture_weights):
        raise ValueError("mixture weights must be nonnegative integers")
    total = sum(mixture_weights)
    if total <= 0:
        raise ValueError("mixture weights must have positive total")
    return sum((Fraction(weight, total) * mass for weight, mass in zip(mixture_weights, masses)), Fraction(0, 1))


def exact_product_mass(masses: Sequence[Fraction]) -> Fraction:
    """Return the accepted mass of an explicit product certificate."""
    result = Fraction(1, 1)
    for mass in masses:
        if mass < 0 or mass > 1:
            raise ValueError("probability masses must lie in [0, 1]")
        result *= mass
    return result


def sequential_mass_lower_bound(first_stage: Fraction, conditional_stage: Fraction) -> Fraction:
    """Lower bound from the SWC sequential-composition rule."""
    if not (Fraction(0, 1) <= first_stage <= Fraction(1, 1)):
        raise ValueError("first-stage mass must lie in [0, 1]")
    if not (Fraction(0, 1) <= conditional_stage <= Fraction(1, 1)):
        raise ValueError("conditional mass must lie in [0, 1]")
    return first_stage * conditional_stage


def change_of_measure_lower_bound(source_mass: Fraction, density_upper_bound: Fraction) -> Fraction:
    """Transfer positive mass from a source measure to a dominating target measure.

    If d(source)/d(target) <= C on the accepted set, then target(A) >= source(A)/C.
    The caller is responsible for supplying a formally justified density bound C.
    """
    if not (Fraction(0, 1) <= source_mass <= Fraction(1, 1)):
        raise ValueError("source mass must lie in [0, 1]")
    if density_upper_bound < 1:
        raise ValueError("density upper bound must be at least 1")
    return source_mass / density_upper_bound


def paley_zygmund_positive_mass_lower_bound(mean: Fraction, second_moment: Fraction) -> Fraction:
    """Paley-Zygmund lower bound P[X>0] >= E[X]^2/E[X^2] for X >= 0."""
    if mean < 0:
        raise ValueError("mean must be nonnegative")
    if second_moment < 0:
        raise ValueError("second moment must be nonnegative")
    if second_moment == 0:
        if mean != 0:
            raise ValueError("nonzero mean is incompatible with zero second moment")
        return Fraction(0, 1)
    bound = mean * mean / second_moment
    if bound > 1:
        raise ValueError("invalid moments: Paley-Zygmund bound exceeds one")
    return bound


def exact_conditioned_mass(event_mass: Fraction, conditioning_mass: Fraction) -> Fraction:
    """Return P(A|B) from exact masses when A is understood to be a subset of B."""
    if not (Fraction(0, 1) <= event_mass <= Fraction(1, 1)):
        raise ValueError("event mass must lie in [0, 1]")
    if not (Fraction(0, 1) < conditioning_mass <= Fraction(1, 1)):
        raise ValueError("conditioning mass must lie in (0, 1]")
    if event_mass > conditioning_mass:
        raise ValueError("event mass cannot exceed conditioning mass for A subset B")
    return event_mass / conditioning_mass


def universal_pointwise_check(masses: Sequence[Fraction]) -> tuple[bool, int | None]:
    """Check the pointwise positivity obligation for a finite instance family."""
    for index, mass in enumerate(masses):
        if mass < 0 or mass > 1:
            raise ValueError("probability masses must lie in [0, 1]")
        if mass == 0:
            return False, index
    return True, None
