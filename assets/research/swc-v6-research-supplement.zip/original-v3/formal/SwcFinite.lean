/-!
Concrete finite-support kernel for Stochastic Witness Calculus.
Each list entry stores an exact natural-number weight and an acceptance bit.
-/

def acceptedMass : List (Nat × Bool) → Nat
  | [] => 0
  | (w, a) :: xs => (if a then w else 0) + acceptedMass xs

/-- Strictly positive accepted weight implies the support contains an accepted
entry of strictly positive weight. -/
theorem acceptedMass_pos_implies_witness
    (xs : List (Nat × Bool))
    (h : 0 < acceptedMass xs) :
    ∃ w : Nat, (w, true) ∈ xs ∧ 0 < w := by
  induction xs with
  | nil =>
      simp [acceptedMass] at h
  | cons hd tl ih =>
      rcases hd with ⟨w, a⟩
      cases a with
      | false =>
          simp [acceptedMass] at h ⊢
          exact ih h
      | true =>
          by_cases hw : 0 < w
          · exact ⟨w, by simp, hw⟩
          · have wz : w = 0 := Nat.eq_zero_of_not_pos hw
            simp [acceptedMass, wz] at h
            rcases ih h with ⟨u, hu, hup⟩
            exact ⟨u, by simp [hu], hup⟩

/-- A positive rational lower-bound numerator below the exact accepted numerator
is enough for existence; the denominator is irrelevant to nonemptiness once it
is known to be positive. -/
theorem certifiedLowerBound_implies_witness
    (xs : List (Nat × Bool))
    (claimNum claimDen : Nat)
    (hDen : 0 < claimDen)
    (hClaim : 0 < claimNum)
    (hBound : claimNum ≤ acceptedMass xs) :
    ∃ w : Nat, (w, true) ∈ xs ∧ 0 < w := by
  have hMass : 0 < acceptedMass xs := lt_of_lt_of_le hClaim hBound
  exact acceptedMass_pos_implies_witness xs hMass
