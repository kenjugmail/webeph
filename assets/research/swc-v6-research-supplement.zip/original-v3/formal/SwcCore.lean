/-!
Stochastic Witness Calculus: minimal trusted logical core.
This file deliberately avoids probability libraries.  A mass backend supplies a
natural-valued exact mass numerator and proves the two interface laws used here:
extensionality and zero mass of the empty event.
-/

universe u v

abbrev Event (α : Type u) := α → Prop

/-- Any event with nonzero exact mass is nonempty. -/
theorem swc_nonempty_of_nonzero_mass
    {α : Type u}
    (mass : Event α → Nat)
    (mass_ext : ∀ A B : Event α, (∀ x, A x ↔ B x) → mass A = mass B)
    (mass_empty : mass (fun _ => False) = 0)
    (A : Event α)
    (h_nonzero : mass A ≠ 0) :
    ∃ x, A x := by
  classical
  by_contra h_exists
  apply h_nonzero
  have h_pointwise : ∀ x, A x ↔ False := by
    intro x
    constructor
    · intro hx
      exact False.elim (h_exists ⟨x, hx⟩)
    · intro hfalse
      exact False.elim hfalse
  exact (mass_ext A (fun _ => False) h_pointwise).trans mass_empty

/-- Pointwise stochastic witness soundness for a universally quantified family. -/
theorem swc_family_sound
    {I : Type u} {W : Type v}
    (R : I → W → Prop)
    (Accept : I → W → Prop)
    (mass : I → Event W → Nat)
    (mass_ext : ∀ i A B, (∀ w, A w ↔ B w) → mass i A = mass i B)
    (mass_empty : ∀ i, mass i (fun _ => False) = 0)
    (verifier_sound : ∀ i w, Accept i w → R i w)
    (accepted_mass_nonzero : ∀ i, mass i (Accept i) ≠ 0) :
    ∀ i, ∃ w, R i w := by
  intro i
  have hacc : ∃ w, Accept i w :=
    swc_nonempty_of_nonzero_mass
      (mass i)
      (mass_ext i)
      (mass_empty i)
      (Accept i)
      (accepted_mass_nonzero i)
  rcases hacc with ⟨w, hw⟩
  exact ⟨w, verifier_sound i w hw⟩

/-- A support-preserving mixture inherits a nonzero accepted mass from a
baseline component whenever that component has nonzero coefficient.  This
logical form isolates the only arithmetic fact the exact mass backend must
certify. -/
theorem support_preserving_mixture_sound
    {I : Type u} {W : Type v}
    (R : I → W → Prop)
    (Accept : I → W → Prop)
    (mixedMass : I → Event W → Nat)
    (mass_ext : ∀ i A B, (∀ w, A w ↔ B w) → mixedMass i A = mixedMass i B)
    (mass_empty : ∀ i, mixedMass i (fun _ => False) = 0)
    (verifier_sound : ∀ i w, Accept i w → R i w)
    (mixture_nonzero : ∀ i, mixedMass i (Accept i) ≠ 0) :
    ∀ i, ∃ w, R i w :=
  swc_family_sound R Accept mixedMass mass_ext mass_empty verifier_sound mixture_nonzero
