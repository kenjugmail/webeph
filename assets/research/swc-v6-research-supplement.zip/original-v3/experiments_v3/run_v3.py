#!/usr/bin/env python3
import subprocess, sys
from pathlib import Path
base=Path(__file__).resolve().parent
scripts=['composition_stress.py','numeric_exactness.py','mass_backend_benchmark.py','certificate_fuzz.py']
for s in scripts:
    subprocess.run([sys.executable,str(base/s)],check=True)
print('v3 experiments passed')
