#!/usr/bin/env python3
from __future__ import annotations
from fractions import Fraction
import hashlib, json, random
from pathlib import Path

SEED=20260904
RNG=random.Random(SEED)

def canonical(obj)->bytes:
    return json.dumps(obj,sort_keys=True,separators=(',',':')).encode()

def make_cert(n:int):
    weights=[RNG.randint(1,10_000) for _ in range(n)]
    accept=[RNG.random()<.25 for _ in range(n)]
    if not any(accept): accept[RNG.randrange(n)]=True
    mass=Fraction(sum(w for w,a in zip(weights,accept) if a),sum(weights))
    core={'schema':'swc-finite-v1','weights':weights,'accept':accept}
    return {'core':core,'core_sha256':hashlib.sha256(canonical(core)).hexdigest(),
            'claim_num':mass.numerator,'claim_den':mass.denominator}

def check(cert)->bool:
    try:
        core=cert['core']
        if core.get('schema')!='swc-finite-v1': return False
        if hashlib.sha256(canonical(core)).hexdigest()!=cert['core_sha256']: return False
        ws=core['weights']; ac=core['accept']
        if len(ws)!=len(ac) or not ws or any(type(w) is not int or w<0 for w in ws): return False
        if any(type(a) is not bool for a in ac) or sum(ws)<=0: return False
        exact=Fraction(sum(w for w,a in zip(ws,ac) if a),sum(ws))
        claim=Fraction(cert['claim_num'],cert['claim_den'])
        return claim>0 and claim<=exact
    except Exception:
        return False

def mutate(cert,kind):
    c=json.loads(json.dumps(cert))
    if kind==0: c['claim_num']+=c['claim_den']
    elif kind==1: c['core']['accept'][0]=not c['core']['accept'][0]
    elif kind==2: c['core_sha256']='0'*64
    elif kind==3: c['core']['schema']='unsupported-v9'
    elif kind==4: c['claim_den']=0
    elif kind==5: c['core']['weights'][0]=-1
    elif kind==6: c['core']['weights'].append(1)
    elif kind==7: c['claim_num']=0
    return c

def main():
    valid=2000; kinds=8
    accepted=0; rejected=0
    for _ in range(valid):
        c=make_cert(RNG.randint(2,80))
        accepted+=check(c)
        for k in range(kinds): rejected+=not check(mutate(c,k))
    out={'seed':SEED,'valid_certificates':valid,'valid_accepted':accepted,
         'mutations_per_certificate':kinds,'mutations_tested':valid*kinds,
         'mutations_rejected':rejected}
    path=Path(__file__).resolve().parents[1]/'results_v3'/'certificate_fuzz.json'
    path.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    assert accepted==valid and rejected==valid*kinds
if __name__=='__main__': main()
