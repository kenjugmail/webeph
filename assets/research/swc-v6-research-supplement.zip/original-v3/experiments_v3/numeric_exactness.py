#!/usr/bin/env python3
from __future__ import annotations
from fractions import Fraction
import json, math, random
from pathlib import Path
import matplotlib.pyplot as plt

SEED=20260904
RNG=random.Random(SEED)

def main()->None:
    ks=list(range(1,5001))
    exact_positive=len(ks)
    floats=[float(Fraction(1,2**k)) for k in ks]
    under=[k for k,v in zip(ks,floats) if v==0.0]

    # Exact-zero arithmetic expressions whose floating evaluation is spuriously positive.
    false_positive=0; false_negative_residual=0; residuals=[]
    for _ in range(50_000):
        b=RNG.randint(3,10**6)
        d=RNG.randint(3,10**6)
        a=RNG.randint(1,b-1)
        c=RNG.randint(1,d-1)
        exact=Fraction(a,b)+Fraction(c,d)
        # Algebraically zero: a/b+c/d-exact.
        residual=float(Fraction(a,b))+float(Fraction(c,d))-float(exact)
        residuals.append(residual)
        if residual>0: false_positive+=1
        elif residual<0: false_negative_residual+=1

    fig=Path(__file__).resolve().parents[1]/'figures_v3'/'floating_point_mass_failure.png'
    y=[math.log10(float(Fraction(1,2**k))) if float(Fraction(1,2**k))>0 else -330 for k in ks]
    plt.figure(figsize=(7.2,4.3))
    plt.plot(ks,y)
    plt.axvline(min(under),linestyle='--')
    plt.xlabel('Exponent k in exact mass 2⁻ᵏ')
    plt.ylabel('log₁₀ of floating representation')
    plt.title('Floating-point positivity fails for exact tiny masses')
    plt.tight_layout(); plt.savefig(fig,dpi=220); plt.close()

    out={
      'seed':SEED,
      'exact_positive_masses_tested':exact_positive,
      'first_binary64_underflow_exponent':min(under),
      'binary64_underflow_count_through_5000':len(under),
      'exact_zero_expressions_tested':len(residuals),
      'spurious_positive_float_residuals':false_positive,
      'spurious_negative_float_residuals':false_negative_residual,
      'exact_zero_residuals':len(residuals)-false_positive-false_negative_residual,
      'max_abs_float_residual':max(abs(x) for x in residuals),
    }
    path=Path(__file__).resolve().parents[1]/'results_v3'/'numeric_exactness.json'
    path.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    assert min(under)==1075
    assert false_positive>0

if __name__=='__main__': main()
