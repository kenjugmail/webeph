#!/usr/bin/env python3
from __future__ import annotations
from fractions import Fraction
import json, random, statistics
from pathlib import Path
import matplotlib.pyplot as plt

SEED=20260904
RNG=random.Random(SEED)

def main()->None:
    systems=2000
    pz_ratios=[]; bonf_ratios=[]; valid_pz=valid_bonf=0
    positive_systems=0
    for _ in range(systems):
        n_states=RNG.randint(16,128)
        n_events=RNG.randint(2,12)
        weights=[RNG.randint(1,50) for _ in range(n_states)]
        total=sum(weights)
        events=[]
        for _j in range(n_events):
            prob=RNG.uniform(.03,.45)
            events.append([RNG.random()<prob for _ in range(n_states)])
        union=[any(events[j][s] for j in range(n_events)) for s in range(n_states)]
        exact=Fraction(sum(w for w,a in zip(weights,union) if a),total)
        if exact==0: continue
        positive_systems+=1
        # X = number of events holding. P(X>0) >= E[X]^2/E[X^2].
        xs=[sum(events[j][s] for j in range(n_events)) for s in range(n_states)]
        EX=Fraction(sum(w*x for w,x in zip(weights,xs)),total)
        EX2=Fraction(sum(w*x*x for w,x in zip(weights,xs)),total)
        pz=EX*EX/EX2 if EX2 else Fraction(0)
        # Second-order Bonferroni lower bound.
        s1=sum(Fraction(sum(weights[s] for s in range(n_states) if events[j][s]),total)
               for j in range(n_events))
        s2=Fraction(0)
        for j in range(n_events):
            for k in range(j+1,n_events):
                s2 += Fraction(sum(weights[s] for s in range(n_states) if events[j][s] and events[k][s]),total)
        bonf=max(Fraction(0),s1-s2)
        if pz<=exact: valid_pz+=1
        if bonf<=exact: valid_bonf+=1
        pz_ratios.append(float(pz/exact))
        bonf_ratios.append(float(bonf/exact))

    fig=Path(__file__).resolve().parents[1]/'figures_v3'/'mass_backend_tightness.png'
    plt.figure(figsize=(7.2,4.3))
    plt.hist(pz_ratios,bins=40,alpha=.65,label='Paley–Zygmund')
    plt.hist(bonf_ratios,bins=40,alpha=.65,label='Second-order Bonferroni')
    plt.xlabel('Certified lower bound / exact accepted mass')
    plt.ylabel('Finite systems')
    plt.title('Tightness of exact mass lower-bound back ends')
    plt.legend(); plt.tight_layout(); plt.savefig(fig,dpi=220); plt.close()

    out={
      'seed':SEED,'systems_generated':systems,'positive_systems':positive_systems,
      'paley_zygmund_valid':valid_pz,
      'bonferroni_valid':valid_bonf,
      'paley_zygmund_median_tightness':statistics.median(pz_ratios),
      'bonferroni_median_tightness':statistics.median(bonf_ratios),
      'paley_zygmund_mean_tightness':statistics.mean(pz_ratios),
      'bonferroni_mean_tightness':statistics.mean(bonf_ratios),
    }
    path=Path(__file__).resolve().parents[1]/'results_v3'/'mass_backend_benchmark.json'
    path.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    assert valid_pz==positive_systems and valid_bonf==positive_systems

if __name__=='__main__': main()
