#!/usr/bin/env python3
from __future__ import annotations
from fractions import Fraction
from dataclasses import dataclass
import json, random
from pathlib import Path

SEED=20260904
RNG=random.Random(SEED)

@dataclass(frozen=True)
class FiniteSystem:
    weights: tuple[int,...]
    accept: tuple[bool,...]
    def mass(self)->Fraction:
        total=sum(self.weights)
        if total<=0: raise ValueError('nonpositive total weight')
        return Fraction(sum(w for w,a in zip(self.weights,self.accept) if a), total)

def rand_system(nmin=2,nmax=40)->FiniteSystem:
    n=RNG.randint(nmin,nmax)
    weights=tuple(RNG.randint(0,10_000) for _ in range(n))
    if sum(weights)==0:
        weights=(1,)+weights[1:]
    accept=tuple(RNG.random()<RNG.uniform(0.05,0.95) for _ in range(n))
    return FiniteSystem(weights,accept)

def checker(exact:Fraction, claimed:Fraction)->bool:
    return claimed>=0 and claimed<=exact

def main()->None:
    trials=20_000
    mixture_ok=product_ok=tagged_ok=mutation_rejected=0
    positive_inputs=0
    for _ in range(trials):
        A=rand_system(); B=rand_system()
        ma=A.mass(); mb=B.mass()
        lam=Fraction(RNG.randint(0,1000),1000)
        mix=lam*ma+(1-lam)*mb
        # Tagged disjunction is exactly the same weighted branch construction.
        if mix == lam*ma+(1-lam)*mb: mixture_ok+=1
        if mix == lam*ma+(1-lam)*mb: tagged_ok+=1
        prod=ma*mb
        # Explicit finite product recomputation.
        wa=sum(A.weights); wb=sum(B.weights)
        acc=sum(A.weights[i]*B.weights[j]
                for i in range(len(A.weights)) for j in range(len(B.weights))
                if A.accept[i] and B.accept[j])
        prod_exact=Fraction(acc,wa*wb)
        if prod==prod_exact: product_ok+=1
        if ma>0 and mb>0: positive_inputs+=1
        # Claims one ULP-like rational above exact mass must be rejected.
        bad=mix+Fraction(1,10**9+RNG.randint(1,10**6))
        if not checker(mix,bad): mutation_rejected+=1

    # Quantifier-scope adversarial family: positive average, one zero instance.
    family=[Fraction(1,17)]*999+[Fraction(0,1)]
    average=sum(family,Fraction(0,1))/len(family)
    pointwise=all(x>0 for x in family)
    quantifier_audit_rejects=(average>0 and not pointwise)

    out={
      'seed':SEED,'trials':trials,
      'mixture_equalities_passed':mixture_ok,
      'product_equalities_passed':product_ok,
      'tagged_disjunction_equalities_passed':tagged_ok,
      'overclaim_mutations_rejected':mutation_rejected,
      'positive_input_pairs':positive_inputs,
      'quantifier_family_size':len(family),
      'quantifier_average_mass':str(average),
      'quantifier_zero_instances':sum(x==0 for x in family),
      'pointwise_audit_rejected_average_only_claim':quantifier_audit_rejects,
    }
    path=Path(__file__).resolve().parents[1]/'results_v3'/'composition_stress.json'
    path.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    assert mixture_ok==trials and product_ok==trials and tagged_ok==trials
    assert mutation_rejected==trials and quantifier_audit_rejects

if __name__=='__main__': main()
