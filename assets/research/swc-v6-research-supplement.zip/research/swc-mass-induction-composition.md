# SWC mass propagation through nested induction

Date: 2026-09-05. Status: composition theorem proved on paper and exact
prototype checked. The universal Erdős–Straus conclusion is not proved.

## State and direct distribution

A state s=(n,x) has n>=2, x>=1, and h=4x-n>0. Its desired output is a pair
of positive integers (b,e) certifying

    4/n = 1/x + 1/(nb) + 1/(ne).

The direct candidate space consists of divisors d of x^2. For every residue
r modulo h, let N_r count the divisors in that residue, and let K be the
number of represented residues. Assign each divisor the probability

    w(d) = 1/(K N_{d mod h}).

This balances represented residues and normalizes before checking validity:
sum_d w(d)=sum_r N_r/(K N_r)=1. All candidate divisors retain positive weight.

Accept a divisor only if both h|(x+d) and h|(x+x^2/d). Output

    b=(x+d)/h, e=(x+x^2/d)/h.

Otherwise output a rejection symbol. The exact direct success mass is D(s),
the sum of the weights of accepted divisors. Including rejection is essential:
the generator does not condition on success or assume positive mass.

## Recursive distribution

The eligible recursive branches are divisors L>=2 of x with

    x_L=x/L, q_L=4x_L-h>=2.

For each branch, q_L<n/2 and x_L<=x/2. A successful parent output (b_L,e_L)
maps to (L b_L,L e_L), which certifies the desired identity at (n,x).
Rejection maps to rejection.

If B(s) is the set of eligible branches, define one generator run as follows:

* If B(s) is empty, use the direct distribution.
* Otherwise, with probability 1/2 use the direct distribution; with
  probability 1/2 choose L uniformly from B(s) and recursively run its
  smaller state, then transform the result.

The exact success mass satisfies

    M(s) = D(s)                                      if B(s) is empty;
    M(s) = D(s)/2 + sum_{L in B(s)} M(s_L)/(2|B(s)|)  otherwise.

The implementation computes this recurrence with rational arithmetic and
memoizes identical states. This is a mixture of alternatives, so masses are
added with their branch weights. Multiplying the masses of alternative
branches would be incorrect. Successive choices along one path do multiply.

## Composition theorem

Every run terminates: each recursive call at least halves the positive integer
x, so a path has at most floor(log_2 x) recursive edges. Each direct candidate
space and each branch set is finite.

By well-founded induction on x:

1. Every state distribution has total mass one, including rejection.
2. Every accepted output passes the integer equation
   4xyz=n(xy+xz+yz), where y=nb and z=ne.
3. Its accepted mass equals M(s) in the displayed recurrence.

For the base/direct case, normalization follows from the divisor weights;
soundness follows from (hb-x)(he-x)=x^2; the mass is D(s). For the inductive
case, each parent distribution is normalized and sound by the induction
hypothesis. The verified scaling map preserves accepted outputs. Taking the
convex mixture gives normalization, soundness, and the displayed mass formula.

Thus M(s)>0 is an exact SWC existence proof for that state. With externally
proved direct lower bounds d(s)<=D(s), the same recurrence produces a lower
bound on M(s). A symbolic positive lower bound is sufficient; explicit
enumeration is one implementation, not a mathematical requirement.

Unrolling the recurrence expresses M(s) as a finite sum over paths of
their branch-choice probabilities multiplied by the terminal direct success
mass. This supplies an explicit interpretation of nested probabilistic
induction. Zero-mass endpoints contribute zero.

## What this does not prove: positivity needs a premise

For the exhaustive direct proposal above, a useful exact fact is

    M(n,x)>0 if and only if D(n,x)>0.

The reverse implication is immediate because the direct branch has positive
weight. For the forward implication, soundness gives positive b,e at the
target state. Set d=hb-x and d'=he-x. Both are positive, dd'=x^2, and
h divides x+d and x+d'. Therefore the exhaustive direct distribution already
contains an accepted divisor with positive weight.

Consequently this combination reorganizes certificate construction and changes
success probabilities, but does not enlarge the fixed-state solution set.
There is no monotonic guarantee that M>=D: spending probability on failed
recursive branches can decrease success mass, as the examples below show.

To conclude a universal prime theorem, an additional proof must supply, for
every target prime p, an initial anchor x whose combined mass is positive.
Neither termination of all recursive calls nor the mass recurrence proves
this premise. The current branch set returns witnesses of the n-multiple
denominator shape; it does not cover arbitrary Type-I solutions.

## Exact prototype checks

The implementation compares its scalar recurrence against separately expanded
output distributions for 600 small states. The expansion retains rejection,
combines probabilities when paths return the same output, verifies total mass
one, and checks every accepted output by the original integer equation.

Selected exact results:

| n | x | Direct mass D | Combined mass M |
|--:|--:|--:|--:|
| 73 | 19 | 0 | 0 |
| 73 | 20 | 1/6 | 7/72 |
| 73 | 25 | 0 | 0 |
| 241 | 63 | 1/10 | 29/480 |
| 1249 | 315 | 1/10 | 259/4320 |
| 118801 | 29715 | 1/54 | 5387/345600 |
| 8803369 | 2200869 | 1/96 | 320527/58466496 |

The output artifact records 59 states and all eligible edges for these roots.
It is an exact arithmetic prototype, not a Lean formalization or an
independent mathematical peer review.

Reproduce:

    python3 -B research/swc_mass_recursion.py --out research/evidence/swc-mass-recursion.json

The individual ingredients are recorded in swc-recursive-induction.md and
swc-universal-support-attempt.md. This note combines them without adding an
unproved universal positivity premise.
