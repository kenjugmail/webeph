# SWC family induction and the remaining coverage problem

2026-09-05. This is a complete elementary proof for a parameterized infinite
family, together with an obstruction to closing the full conjecture by a finite
table of these families. It is not a proof for all primes or a claim that these
classical identities are new.

## Family theorem

Fix positive integers A,B,h such that h divides A+B. Put Q=(A+B)/h.
For every integer S>=1 define

    n_S = 4ABS-h,
    X_S = ABS,
    Y_S = n_S AQS,
    Z_S = n_S BQS.

Then n_S>=2, all three denominators are positive integers, and

    4/n_S = 1/X_S + 1/Y_S + 1/Z_S.

In particular, if h==3 mod4, every n_S is 1 mod4.

Proof of positivity: h<=A+B, and for positive A,B,

    4AB-A-B = 2AB + (A-1)B + (B-1)A >= 2.

Thus n_S>=4AB-h>=2. Integrality follows from h|(A+B).

## The actual induction step

The strengthened induction invariant keeps A,B,h,Q fixed and records both
the identity and the displayed denominator formulas. The base S=1 satisfies

    1/(AB) + 1/(n_1 AQ) + 1/(n_1 BQ)
      = [n_1 Q + A+B]/(n_1 ABQ)
      = [Q(n_1+h)]/(n_1 ABQ)
      = 4/n_1.

Suppose the invariant holds at S. The next state is

    n_{S+1} = n_S+4AB,
    X_{S+1} = X_S+AB,
    Y_{S+1} = (n_S+4AB) AQ(S+1),
    Z_{S+1} = (n_S+4AB) BQ(S+1).

All are positive integers, and substitution gives

    1/X_{S+1} + 1/Y_{S+1} + 1/Z_{S+1}
      = [n_{S+1}Q+A+B]/[n_{S+1}ABQ(S+1)]
      = 4/n_{S+1}.

This proves the strengthened invariant by induction on S. The arithmetic
formula also proves it directly; induction is a valid packaging of that
identity, not an additional coverage theorem. The reverse step S+1 to S
strictly lowers n by 4AB and terminates at S=1.

## SWC compilation

For each family member, put point mass 1 on its constructed witness triple.
The exact verifier checks 4XYZ=n(XY+XZ+YZ). The proved identity says its
accepted mass is exactly 1. The successor map above pushes this point mass
to the next witness, retaining accepted mass 1. Therefore SWC certifies

    for every S>=1, there exists a witness for n_S=4ABS-h.

The probability space is indexed by S. This does not assert a probability
distribution of mass 1 on every integer simultaneously, and does not assume
that a probability-one event covers instances outside this family.

## Explicit infinite hard-class progression

Take A=5, B=1, h=3, Q=2, and S=5+6t. For every integer t>=0, let

    n=97+120t,
    X=25+30t,
    Y=10(5+6t)n,
    Z=2(5+6t)n.

Then 4/n=1/X+1/Y+1/Z and n==1 mod24. This is an exact theorem for every
t, including all primes in that progression. Since gcd(97,120)=1, the
progression contains infinitely many primes by Dirichlet's theorem.

## Finite-family obstruction

Consider any finite collection of parameter triples (A_i,B_i,h_i) with
h_i|(A_i+B_i), and their families

    n=4A_i B_i S-h_i, S>=1.

Let M=lcm(24,4A_1B_1,...,4A_rB_r). Every integer n==1 modM lies outside
all these families.

Proof: if such n belonged to family i, then 4A_iB_i would divide n+h_i,
so it would divide 1+h_i. But

    0 < 1+h_i <= 1+A_i+B_i < 4A_iB_i.

The strict upper bound follows from 4AB-A-B>=2. This is impossible.
Dirichlet's theorem supplies infinitely many primes n==1 modM, and all of
them are 1 mod24 because 24|M. Therefore this finite family collection misses
infinitely many primes in the target class. Adding finitely many individually
checked base cases cannot remove that infinite set.

This is a specific obstruction to fixed parameter families. It does not rule
out a symbolic construction in which A,B,h vary with the target prime, or
induction that changes the family parameters using a further proved rule.
It also does not refute the previously observed bounds h<=179 and L<=13:
those computations allowed A and B to grow with p.

## Why the universal step is still open

Our family theorem proves the implication

    [h|(A+B) and p=4ABS-h] => existence of a certificate for p.

To cover every target prime we still need to establish

    for every prime p==1 mod24,
    there exist A,B,h,S>=1 with h|(A+B), p=4ABS-h.

This is an arithmetic existence assertion. The family induction does not
provide those parameters for a prescribed p. They cannot simply be included
in an induction hypothesis and then assumed at the new prime.

The earlier strict-parent route additionally asks for S>=2 after suitable
normalization. Its finite success remains evidence, not a proof of universal
parameter existence. No parameter-changing rule that establishes this
coverage has been found in this attempt.

Source for the arithmetic-progression prime theorem:
[NIST DLMF 27.11](https://dlmf.nist.gov/27.11).
The family parametrization is the same classical Type-II construction
already recorded in type-ii-scaling-descent.md.
