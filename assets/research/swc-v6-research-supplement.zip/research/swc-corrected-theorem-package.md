# Corrected shift and multiplicative-box results for SWC

2026-09-05. Research draft with elementary proofs and reproducible arithmetic
checks. The Erdős–Straus conjecture remains open in this work. No priority
claim is made for these identities or their consequences.

## Standing hypotheses

Unless explicitly relaxed, p is a prime with p congruent to 1 modulo 4,
0<c<=2p, c congruent to 3 modulo 4, a=(p+c)/4, and M=ap.
All divisors and denominators are positive integers.

These hypotheses imply a<p and gcd(c,M)=1. Indeed a<=3p/4<p, and any common
prime divisor of c and a divides 4a-c=p. If p divided c in the stated range,
c would be p or 2p, both excluded by c congruent to 3 modulo 4.

This range assumption was missing from the unrestricted versions of D and E.
The counterexample p=17,c=51,a=17,e=17 gives denominators (17,6,102), although
c divides neither a+1 nor 4a+1. It lies outside the repaired range.

Call p c-representable if some e|M^2 satisfies both c|(M+e) and
c|(M+M^2/e).

## Lemma 1: witness identity

For a c-representable p, put x=a, y=(M+e)/c, z=(M+M^2/e)/c.
These are positive integers. Since (cy-M)(cz-M)=M^2, expansion gives
c yz=M(y+z). Dividing by Myz yields 1/y+1/z=c/M.
Adding 1/a gives (p+c)/(ap)=4/p.

This lemma itself only needs positive c and the displayed integrality
conditions; its algebra does not require the upper shift bound.

## Theorem A: exact bounded reformulation

A positive three-unit-fraction representation of 4/p exists if and only if
p is c-representable at some shift in the standing range.

Proof: the reverse direction is Lemma 1. For the forward direction order the
denominators x<=y<=z. Then p/4<x<=3p/4. Set c=4x-p and M=px.
The residual equation c/M=1/y+1/z gives
(cy-M)(cz-M)=M^2. Both factors are positive integers, since each reciprocal
is strictly less than their sum. Set e=cy-M. This proves divisibility,
the two congruences, and 0<c<=2p.

The least-denominator bound is also explicit in Dahan, Proposition 2.5.
It should not be advertised as a first discovery on the present evidence.

## Theorem B: exact signed-box criterion

Write M=product q_i^k_i. Define

    B(M,c) = {product q_i^g_i modulo c : -k_i<=g_i<=k_i}.

Then p is c-representable if and only if -1 belongs to B(M,c).

Proof: a divisor e=product q_i^j_i of M^2 has 0<=j_i<=2k_i. Thus e/M
modulo c is represented by g_i=j_i-k_i. The congruence e=-M modulo c is
equivalent to e/M=-1. Since M is a unit and e e'=M^2, the first congruence
implies e'=-M modulo c, so the complementary congruence follows.

The box here is built from M=ap. A box built only from a is different:
its complete two-target formulation asks for -1 or -p^{-1}.

## Proposition C: empty endpoint branches

Neither e=1 nor e=M^2 is a witness.

For either endpoint, a complementary condition requires c|(M+1). Since
4M=p(p+c), this implies c|(p^2+4). A positive integer c congruent to 3
modulo 4 has a prime factor r congruent to 3 modulo 4. Such an r cannot
divide p^2+4: division by 2 modulo r would make -1 a square. The same
argument excludes c|(t^2+4) for every integer t under the same condition on c.

## Lemma D: monomial witness classification

Among the nine divisors

    1, a, p, ap, a^2, p^2, a^2p, ap^2, a^2p^2,

a witness exists if and only if c|(p+1) or c|(p+4).
Consequently, if c|(p+k), a monomial witness exists if and only if
k is congruent to 1 or 4 modulo c.

Proof: multiplication by a,p,2,4 is invertible modulo c. Substituting
p=4a-c into the first congruence gives the following exhaustive table;
the second congruence follows by Theorem B.

| Candidate(s) | Necessary and sufficient congruence | Status |
|---|---|---|
| 1 and a^2p^2 | c divides p^2+4 | impossible by C |
| a and ap^2 | c divides p+1 | valid |
| p and a^2p | c divides p+4 | valid |
| ap | c divides 2 | impossible |
| a^2 and p^2 | c divides 5 | impossible for c congruent to 3 mod4 |

This table needs the standing coprimality hypothesis.

## Theorem F: two constructive sufficient filters

If p+1 or p+4 has a prime divisor c congruent to 3 modulo 4, then 4/p
has a representation. For c|(p+1), take e=a; for c|(p+4), take e=p.
The congruences follow from D and the witnesses from Lemma 1.
Such c lies within the standing range for p>=5.

For the six Mordell-hard residue classes modulo 840, the checked count below
10^6 is 1507 of 2370 primes, approximately 63.6%.
No asymptotic claim that the exception fraction equals or behaves like
4.6/log(p) is made. That would require an independently justified theorem or
a clearly specified empirical model with uncertainty and validation.

## Proposition E: prime-anchor rigidity

If a is prime, p is c-representable if and only if c|(a+1) or c|(4a+1).

Proof: a and p are distinct primes in the standing range, so the nine
monomials in D exhaust all divisors of M^2. Apply D, using
p+4 congruent to 4(a+1) and p+1 congruent to 4a+1 modulo c.
Thus these prime-anchor solutions are already supplied by the F filters.

## Proposition G: symmetry and the restricted experiment

The map e -> M^2/e is an involution on accepted divisors and swaps y,z.
This follows directly from the two congruences.

The restricted subfamily e|M solves 272 of the 273 Mordell-hard primes
below 10^5 when shifts c<=59 are allowed. The missed prime is 2521.
At c=23, a=636, M=1603356, e=848 is an accepted divisor of M^2 but
does not divide M. No accepted divisor at that shift divides M.
The restriction e|M is an exponent sub-box, not literally half the candidates.

## Proposition H: the near-prime shift is impossible

For prime p congruent to 1 modulo 4 with p>5, c=p-2 is impossible.
For p=5, c=3 does work.

Proof: set a=(p-1)/2, so a is even and a>2, c=2a-1, p=2a+1.
If the residual c/(ap) decomposes into two unit fractions, writing their
denominators as g u,g v with gcd(u,v)=1 gives

    c g u v = ap(u+v).

Since gcd(uv,u+v)=1, uv divides ap; and since gcd(c,ap)=1, c divides u+v.
Because p is prime and p does not divide a, the pair is of one of these forms:

* u=d1,v=d2, with d1,d2 divisors of a;
* u=p d1,v=d2, or the swapped pair, with d1,d2 divisors of a.

In the first case 0<d1+d2<=2a<2c, so d1+d2=c=2a-1. One divisor must be
a-1 and the other a. But a-1 cannot divide a when a>2.

In the second case p=2 modulo c, so 2d1+d2 is divisible by c.
It lies between 1 and 3a<2c, hence 2d1+d2=2a-1.
The choice d1=a is too large; otherwise d1<=a/2, giving a-1<=d2<=a.
If d2=a-1, divisibility again forces a<=2. If d2=a, then
2d1=a-1 is impossible because a is even. Both cases contradict the premises.

This proof upgrades the former finite observation to a range-free obstruction
under its exact hypotheses. No originality claim is made.

## Corollary: a tighter complete shift range

For p congruent to 1 modulo 4, p>5, existence is equivalent to
c-representability for some 0<c<=p-6, c congruent to 3 modulo 4.

First prove the least denominator x is less than p/2. At least one denominator
is divisible by p, by reducing the integer equation modulo p, and not all
three can be (their reciprocal sum would be at most 3/p).

If two are divisible by p, write them pb,pe. The remaining denominator x
satisfies 4=p/x+1/b+1/e<=p/x+2, so x<=p/2, strictly for odd p.

If exactly one is divisible by p, write it pt and the others u,v.
Clearing denominators shows p|(4t-1), since u,v are coprime to p.
Write 4t-1=kp with k>0. Modulo 4 this gives k congruent to 3, so k>=3
and t>=(3p+1)/4. If the least denominator exceeded p/2, then
u,v>=(p+1)/2, giving

    1/u+1/v+1/(pt) <= 4/(p+1)+4/[p(3p+1)] < 4/p,

a contradiction. Thus the least denominator is at most (p-1)/2.
Its shift is at most p-2, and H excludes that endpoint. The next eligible
shift is p-6. Lemma 1 proves the reverse implication.

This is a derived tightening of the original search range; priority remains
unchecked. It is not an all-prime existence theorem.

## SWC application: discard provably zero ordered mass

Consider a generator that chooses a shift uniformly from 3,7,...,2p, chooses
a divisor e of M^2 uniformly at that shift, and accepts only when the
rectangle checks pass and a<=min(y,z). This ordering requirement makes a
the least denominator.

For p>5, every shift above p-6 has zero accepted mass by the preceding
corollary. Restricting the shift draw to 3,7,...,p-6 therefore gives

    new accepted mass = [2(p-1)/(p-5)] * old accepted mass.

There are (p-1)/2 old shifts and (p-5)/4 new shifts. The accepted-mass
numerator is unchanged, which proves the ratio exactly. This remains an
identity when both masses are zero; it does not prove that either is positive.
The ordering condition is essential: this claim is not made for the previous
unordered two-target sampler.

This provides a legitimate SWC optimization based on a proved obstruction,
but leaves the universal positive-mass premise unresolved.

## Experimental wording and provenance

The supplied artifact reproduces maximum least shifts 31,59,107 below
10^5,10^6,10^7. No growth law is inferred from those three maxima.
The independence and conditional-correlation claims have not been verified
from a per-prime, per-shift joint table in this audit and are excluded from
the result statements. A finite search certifies its declared range, not
the unrestricted theorem.

The checker tests 4960 prime/shift states for p<=500, compares the full box
criterion to exact reconstruction, tests D/E and involution, and reproduces
F/G and the maxima from the hashed v3 artifact. These are regression checks;
the general statements rely on the displayed mathematical arguments.

The original v3 artifact is retained as supplied; this is a separate corrected
research draft. No immutable publication or public proof status is changed.

## Sources and reproduction

* [Dahan, Proposition 2.5 and Section 2](https://arxiv.org/pdf/2608.24035):
  least-denominator bound and divisor criteria.
* [Bello-Hernández, Benito, Fernández](https://arxiv.org/abs/2606.10922):
  related complete divisor parametrization.
* [Elsholtz–Tao](https://arxiv.org/pdf/1107.1010): classical Type-I/Type-II
  structure. These results require a priority comparison before novelty claims.

    python3 -B research/verify_corrected_box_results.py /Users/kt/Downloads/stochastic_witness_calculus_artifact_v3.zip --out research/evidence/corrected-box-audit.json
