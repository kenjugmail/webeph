"""Exact regression checks and reproduction for corrected SWC box statements."""
import argparse
import csv
import hashlib
import io
import json
from pathlib import Path
import zipfile
from math import gcd
from fractions import Fraction
from swc_residue_mass import factors
from swc_recursive_anchor import divisors
from type_ii_descent_search import sieve


def factored_divisors(fs):
    ds=[1]
    for r,e in fs:ds=[d*r**j for d in ds for j in range(e+1)]
    return ds


def accepts(p,c,e):
    a=(p+c)//4;M=p*a
    if M*M%e or (M+e)%c or (M+M*M//e)%c:return False
    x,y,z=a,(M+e)//c,(M+M*M//e)//c
    if min(x,y,z)<=0 or 4*x*y*z!=p*(x*y+x*z+y*z):
        raise AssertionError('invalid rectangle witness')
    return True


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('artifact',type=Path)
    parser.add_argument('--out',type=Path)
    args=parser.parse_args()
    digest=hashlib.sha256(args.artifact.read_bytes()).hexdigest()
    if digest!='e22bc0f376244744e6b506b9562465ffc5174239f0fb9f0f7e8e1368f7121899':
        raise ValueError('unexpected source artifact')
    with zipfile.ZipFile(args.artifact) as archive:
        rows=list(csv.DictReader(io.StringIO(archive.read('results/erdos_results.csv').decode())))
    ps,_=sieve(500)
    shifts_checked=0
    ordered_mass_examples=[]
    for p in ps:
        if p%4!=1:continue
        full_mass=Fraction();tight_mass=Fraction()
        for c in range(3,2*p+1,4):
            a=(p+c)//4;M=p*a
            assert gcd(M,c)==1 and a<p
            fs=factors(M)
            ds=factored_divisors([(r,2*e) for r,e in fs])
            accepted=[e for e in ds if accepts(p,c,e)]
            ordered=[e for e in accepted if a<=min((M+e)//c,(M+M*M//e)//c)]
            full_mass+=Fraction(len(ordered),len(ds))
            if p>5:
                if c>p-6:assert not ordered
                else:tight_mass+=Fraction(len(ordered),len(ds))
            box={d*pow(M,-1,c)%c for d in ds}
            assert bool(accepted)==(-1%c in box)
            monomials={1,a,p,a*p,a*a,p*p,a*a*p,a*p*p,a*a*p*p}
            simple=any(accepts(p,c,e) for e in monomials)
            assert simple==((p+1)%c==0 or (p+4)%c==0)
            if a>=2 and len(factors(a))==1 and factors(a)[0][1]==1:
                assert bool(accepted)==((a+1)%c==0 or (4*a+1)%c==0)
            for e in accepted:assert accepts(p,c,M*M//e)
            if c==p-2:assert bool(accepted)==(p==5)
            shifts_checked+=1
        if p>5:
            old=full_mass/((p-1)//2);new=tight_mass/((p-5)//4)
            assert old>0 and new==old*Fraction(2*(p-1),p-5)
            if p in [13,73,97,193]:
                ordered_mass_examples.append(dict(p=p,old_mass=str(old),new_mass=str(new),
                                                  ratio=str(new/old)))
    H={1,121,169,289,361,529}
    hard=[int(r['p']) for r in rows if int(r['p'])<10**6 and int(r['p'])%840 in H]
    f_hits=sum(any(r%4==3 for r,e in factors(p+1)+factors(p+4)) for p in hard)
    restricted_misses=[]
    for p in hard:
        if p>=10**5:continue
        if not any(any(accepts(p,c,e) for e in factored_divisors(factors(p*((p+c)//4))))
                   for c in range(3,60,4)):
            restricted_misses.append(p)
    assert f_hits==1507 and len(hard)==2370 and restricted_misses==[2521]
    a=(2521+23)//4;M=2521*a
    assert accepts(2521,23,848) and M%848!=0
    maxima={str(bound):max(int(r['least_c']) for r in rows if int(r['p'])<bound)
            for bound in (10**5,10**6,10**7)}
    assert maxima=={'100000':31,'1000000':59,'10000000':107}
    # Exact failure of D/E without the global range/coprimality hypotheses.
    assert accepts(17,51,17) and 18%51 and 69%51
    result=dict(status='finite_regressions_and_reproduced_counts',artifact_sha256=digest,
                shift_states_checked=shifts_checked,theorem_F=dict(hits=f_hits,total=len(hard)),
                restricted_divisor_misses=restricted_misses,
                least_shift_maxima=maxima,
                ordered_mass_examples=ordered_mass_examples,
                missing_hypothesis_counterexample=dict(p=17,c=51,a=17,e=17,witness=[17,6,102]),
                correlation_claim='not_verified_no_joint_failure_table_in_this_audit',
                asymptotic_claims='not_established',universal_ES='unproved')
    if args.out:args.out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
