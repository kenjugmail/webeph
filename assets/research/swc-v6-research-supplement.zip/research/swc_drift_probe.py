"""Small exact drift experiment. Never launches a large prime sweep.

The goal is E(p), with a search position x; moving x does not prove E(p,x).
Terminal anchors require explicit checked integer witnesses.
"""
import argparse
from fractions import Fraction
import json
from pathlib import Path
from swc_prime_induction import direct_mass


def neighbors(i,size):return (max(0,i-1),min(size-1,i+1))


def potential(i,size,good):
    if not good:raise ValueError('no accepting state: cannot construct hitting-time potential')
    if i in good:return 0
    left=max((g for g in good if g<i),default=None)
    right=min((g for g in good if g>i),default=None)
    if left is None:return right*(right+1)-i*(i+1)
    if right is None:
        end=size-1-left;j=size-1-i
        return end*(end+1)-j*(j+1)
    return (i-left)*(right-i)


def verify(data):
    p=data['p'];anchors=data['anchors'];size=len(anchors)
    assert anchors==list(range(p//4+1,3*p//4+1))
    good=set()
    for item in data['terminals']:
        i=item['index'];x,y,z=item['witness']
        assert x==anchors[i] and min(x,y,z)>0
        assert 4*x*y*z==p*(x*y+x*z+y*z)
        good.add(i)
    values=data['potential']
    assert len(values)==size and all(v>=0 for v in values)
    for i in range(size):
        if i in good:assert values[i]==0
        else:
            a,b=neighbors(i,size)
            assert 2*values[i]-values[a]-values[b]>=2
    start=data['start_index'];steps=data['horizon']
    assert steps>=2*values[start] and steps>0
    # Full exact enumeration of path probability counts by dynamic programming.
    counts=[0]*size;counts[start]=1
    for _ in range(steps):
        new=[0]*size
        for i,count in enumerate(counts):
            if i in good:new[i]+=2*count
            else:
                a,b=neighbors(i,size);new[a]+=count;new[b]+=count
        counts=new
    assert sum(counts)==2**steps
    probability=Fraction(sum(counts[i] for i in good),2**steps)
    assert probability>=Fraction(1,2)
    return probability


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path)
    args=parser.parse_args()
    p=73;anchors=list(range(p//4+1,3*p//4+1));terminals=[]
    for i,x in enumerate(anchors):
        delta,witness=direct_mass(p,x)
        if delta:terminals.append(dict(index=i,witness=witness))
    good={v['index'] for v in terminals}
    values=[potential(i,len(anchors),good) for i in range(len(anchors))]
    start=anchors.index(25)
    data=dict(status='finite_drift_certificate_universal_terminal_existence_open',
              p=p,anchors=anchors,terminals=terminals,potential=values,
              start_index=start,horizon=2*values[start],drift_lower_bound='1')
    probability=verify(data)
    data['exact_success_probability']=str(probability)
    try:potential(0,len(anchors),set())
    except ValueError:pass
    else:raise AssertionError('empty terminal set falsely certified')
    if args.out:args.out.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(states=len(anchors),accepting_anchors=[anchors[i] for i in sorted(good)],
                         start_anchor=25,start_potential=values[start],horizon=data['horizon'],
                         success_probability_decimal=float(probability),verified_lower_bound='1/2',
                         empty_terminal_set_rejected=True)))


if __name__=='__main__':main()
