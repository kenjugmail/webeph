"""Independently enumerate all pair multipliers. No search-module imports."""
from fractions import Fraction
from itertools import combinations
from math import gcd
from pathlib import Path
import json
import sys


def inspect(values):
    if not isinstance(values,list) or not 2<=len(values)<=16:
        raise ValueError('speed list')
    if any(type(v) is not int or not 1<=v<=10000 for v in values) or len(set(values))!=len(values):
        raise ValueError('positive distinct bounded integers')
    if sum(a+b for a,b in combinations(values,2))*len(values)>2000000:
        raise ValueError('work budget')
    N=len(values)+1;tables=[];best=Fraction();best_time=Fraction()
    for a,b in combinations(values,2):
        q=a+b
        floor=lambda x:x.numerator//x.denominator
        ceil=lambda x:-((-x.numerator)//x.denominator)
        first={floor(Fraction(q,N)),ceil(Fraction(q,N)),floor(Fraction(q,N))+1,
               floor(Fraction(q,2)),ceil(Fraction(q,2))}
        second={ceil(Fraction(q,N)),ceil(Fraction(q,N))+1,floor(Fraction(q,2))}
        for d in range(2,7):
            for k in range(1,d):first.update((floor(Fraction(k*q,d)),ceil(Fraction(k*q,d))))
            for k in range(1,d//2+1):second.update((floor(Fraction(k*q,d)),ceil(Fraction(k*q,d))))
        second={c for c in second if ceil(Fraction(q,N))<=c<=floor(Fraction(q,2))}
        full=unit=orig=fold=origunit=foldunit=0
        for m in range(q):
            t=Fraction(m,q);distances=[]
            for v in values:
                part=t*v;part-=floor(part);distances.append(min(part,1-part))
            score=min(distances)
            if score>best:best=score;best_time=t
            if score<Fraction(1,N):continue
            residue=(a*m)%q;distance=min(residue,q-residue);u=gcd(m,q)==1
            full+=1;unit+=u;orig+=residue in first;fold+=distance in second
            origunit+=u and residue in first;foldunit+=u and distance in second
        tables.append({'pair':[a,b],'q':q,'full_witnesses':full,'unit_witnesses':unit,
                       'original_all_m':orig,'original_unit_m':origunit,
                       'folded_all_m':fold,'folded_unit_m':foldunit})
    return {'speeds':values,'gcd':gcd(*values),
            'open':all(any(v%d==0 for v in values) for d in range(2,N+1)),
            'threshold':str(Fraction(1,N)),'table':tables,'maximum_loneliness':str(best),
            'maximizing_time':str(best_time),
            'original_disproved':all(r['original_all_m']==0 for r in tables),
            'folded_disproved':all(r['folded_all_m']==0 for r in tables),
            'original_unit_disproved':all(r['original_unit_m']==0 for r in tables),
            'folded_unit_disproved':all(r['folded_unit_m']==0 for r in tables)}


if __name__=='__main__':
    record=json.loads(Path(sys.argv[1]).read_text())
    if record.get('schema')!='swc-canonical-obstructions-v1':raise ValueError('schema')
    for entry in record['obstructions']:
        actual=inspect(entry['speeds'])
        if actual!=entry:raise ValueError('obstruction certificate mismatch')
    print(json.dumps({'verified_obstructions':len(record['obstructions']),
                      'general_lonely_runner_disproved':False},indent=2))
