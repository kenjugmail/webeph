"""Experimental exact SWC backend for the stationary lonely-runner problem.

n positive distinct integer speeds, threshold 1/(n+1), common initial point.
Search proposals are untrusted; only rational/integer certificate checks matter.
No claim of a universal lonely-runner proof or proof-assistant formalization.
"""
from fractions import Fraction
from itertools import combinations
from math import gcd

MAX_SPEED = 10000
MAX_WORK = 2000000


def speeds_checked(values):
    if not isinstance(values, (list, tuple)) or not 2 <= len(values) <= 16:
        raise ValueError('expected 2..16 speeds')
    if any(type(v) is not int or not 1 <= v <= MAX_SPEED for v in values):
        raise ValueError('positive bounded integer speeds required')
    if len(set(values)) != len(values):
        raise ValueError('distinct speeds required')
    return tuple(values)


def lonely(values, m, q):
    """Integer-only witness check, including equality at the boundary."""
    values = speeds_checked(values)
    if type(q) is not int or type(m) is not int or not 1 <= q <= 2*MAX_SPEED:
        raise ValueError('invalid rational time')
    if not 0 <= m < q:
        raise ValueError('time must lie in [0,1)')
    return all((len(values)+1)*min((m*v) % q, q-(m*v) % q) >= q for v in values)


def congruence_roots(v, q, target):
    """All m mod q solving v*m=target mod q, including non-unit v."""
    if any(type(x) is not int for x in (v, q, target)) or v <= 0 or q <= 0:
        raise ValueError('invalid congruence')
    if q > 2*MAX_SPEED:
        raise ValueError('modulus budget exceeded')
    target %= q
    g = gcd(v, q)
    if target % g:
        return ()
    reduced = q//g
    root = (target//g)*pow(v//g, -1, reduced) % reduced if reduced > 1 else 0
    return tuple(root+k*reduced for k in range(g))


def canonical_times(values, denominators=(2,3,4)):
    """Explicit rounding convention: floor AND ceil on the reachable target grid.

    For a pair with gcd g, quantize rational targets on Z/(q/g)Z, then
    multiply by g and enumerate every lift. This is a new reproducible
    protocol, not an assertion about the user's unspecified experiment.
    """
    values = speeds_checked(values)
    times = set()
    for i,j in combinations(range(len(values)),2):
        q = values[i]+values[j]
        g = gcd(values[i],q)
        reduced = q//g
        for denominator in denominators:
            if type(denominator) is not int or not 2 <= denominator <= 32:
                raise ValueError('canonical denominator budget exceeded')
            for numerator in range(1,denominator):
                a = numerator*reduced
                for target in {a//denominator, (a+denominator-1)//denominator}:
                    for m in congruence_roots(values[i],q,g*target):
                        times.add(Fraction(m,q))
    return sorted(times)


def exact_grid_record(values):
    """Uniform distinct-pair-sum choice, then uniform m in that grid.

    Grid aliases are separate generator seeds, so times on multiple grids
    need not have equal total weight. Positivity is complete by Kravitz's
    pair-sum local-maximum theorem; enumerating a grid is not a universal proof.
    """
    values = speeds_checked(values)
    moduli = sorted({a+b for a,b in combinations(values,2)})
    if sum(moduli)*len(values) > MAX_WORK:
        raise ValueError('grid work budget exceeded')
    best = Fraction(0)
    best_time = Fraction(0)
    records = []
    for q in moduli:
        count = 0
        for m in range(q):
            score = min(min((m*v)%q,q-(m*v)%q) for v in values)
            count += (len(values)+1)*score >= q
            if score*best.denominator > best.numerator*q:
                best, best_time = Fraction(score,q), Fraction(m,q)
        records.append({'q':q,'accepted':count})
    mass = sum((Fraction(r['accepted'],r['q']) for r in records),Fraction())/len(moduli)
    return {'schema':'swc-lonely-grid-v1','speeds':list(values),
            'threshold':str(Fraction(1,len(values)+1)),
            'generator':'uniform_distinct_pair_sum_then_uniform_multiplier',
            'grids':records,'accepted_mass':str(mass),'maximum_loneliness':str(best),
            'maximizing_time':str(best_time),'scope':'single_speed_tuple'}


def pair_bonferroni(values,i,j):
    """First and third order Bonferroni bounds after accepting the anchor pair."""
    values = speeds_checked(values)
    if not 0 <= i < j < len(values):
        raise ValueError('invalid pair')
    q = values[i]+values[j]
    if q*len(values)**3 > MAX_WORK*10:
        raise ValueError('intersection work budget exceeded')
    k = len(values)+1
    base = {m for m in range(q) if k*min((m*values[i])%q,q-(m*values[i])%q) >= q}
    others = [a for a in range(len(values)) if a not in (i,j)]
    bad = [{m for m in base if k*min((m*values[a])%q,q-(m*values[a])%q) < q} for a in others]
    intersection_sums = []
    for order in (1,2,3):
        intersection_sums.append(sum(len(set.intersection(*group)) for group in combinations(bad,order)))
    first = max(0,len(base)-intersection_sums[0])
    third = max(0,len(base)-intersection_sums[0]+intersection_sums[1]-intersection_sums[2])
    exact = len(base-set().union(*bad))
    return {'pair':[i,j],'q':q,'anchor_count':len(base),
            'intersection_sums_1_2_3':intersection_sums,
            'first_order_lower_count':first,'third_order_lower_count':third,
            'exact_count':exact}


def continuous_good_set(values):
    """Independent rational interval intersection, retaining isolated points."""
    values = speeds_checked(values)
    k = len(values)+1
    intervals = [(Fraction(0),Fraction(1))]
    for v in values:
        allowed = [(Fraction(k*j+1,k*v),Fraction(k*(j+1)-1,k*v)) for j in range(v)]
        merged = []
        a=b=0
        while a<len(intervals) and b<len(allowed):
            lo=max(intervals[a][0],allowed[b][0]); hi=min(intervals[a][1],allowed[b][1])
            if lo<=hi:
                if merged and lo<=merged[-1][1]:
                    merged[-1]=(merged[-1][0],max(merged[-1][1],hi))
                else:
                    merged.append((lo,hi))
            if intervals[a][1] < allowed[b][1]: a+=1
            else: b+=1
        intervals=merged
    return {'measure':str(sum((b-a for a,b in intervals),Fraction())),
            'components':[[str(a),str(b)] for a,b in intervals]}


def residue_family(values,m,q):
    """A verified witness extends to v_i+q*k_i, independently for all k_i>=0.

    Duplicates in that enlarged family do not invalidate the displayed
    n+1 threshold, but standard distinct-speed tuples form a subdomain.
    """
    if not lonely(values,m,q):
        raise ValueError('cannot lift a failed witness')
    return {'schema':'swc-lonely-residue-family-v1','base_speeds':list(values),
            'time':[m,q],'increments':[q]*len(values),
            'parameter_domain':'all nonnegative integer k_i independently',
            'threshold':str(Fraction(1,len(values)+1)),
            'scope':'specified_residue_family','accepted_point_mass':'1'}
