"""Exhaustively falsify a proposed universal collision certificate.

This checks a limitation of the proof strategy, not of Erdős–Straus.
The original uniform-exponent distribution fails at every canonical shift.
Separately identify shifts where reweighting the residue support could help.
"""
import argparse
import json
from pathlib import Path
from swc_residue_mass import distribution
from type_ii_descent_search import sieve


def arithmetic_data(n, spf, totient=False):
    result = n if totient else 1
    while n > 1:
        r, e = spf[n], 0
        while n % r == 0:
            n //= r
            e += 1
        if totient:
            result -= result // r
        else:
            result *= 2*e + 1
    return result


def direct_support(c, h):
    residues = set()
    inv = pow(c, -1, h)
    for d in range(1, c+1):
        if c*c % d == 0:
            residues.add(d*inv % h)
            residues.add((c*c//d)*inv % h)
    return residues


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    p = 806521
    primes, spf = sieve(2*p)
    assert p in primes and p % 24 == 1
    small_support = 0
    evaluated = []
    reweightable = []
    for h in range(3, 2*p+1, 4):
        c = (p+h)//4
        m = arithmetic_data(h, spf, True)
        n = arithmetic_data(c, spf)
        targets = {-1 % h, -pow(p, -1, h) % h, -p % h}
        k = len(targets)
        if n <= m-k:
            small_support += 1
            continue
        counts = distribution(c, h)
        support = set(counts)
        # Different algorithm: enumerate divisors as integers instead of
        # convolving their prime-factor residues.
        assert support == direct_support(c, h)
        collision = sum(v*v for v in counts.values())
        assert (m-k)*collision >= n*n
        if len(support) > m-k:
            reweightable.append(h)
        evaluated.append(dict(shift=h, group_size=m, targets=k,
                              exponent_vectors=n, support_size=len(support)))
    x, y, z = 201645, 4119983485140, 2758301820
    assert 4*x*y*z == p*(x*y+x*z+y*z)
    result = dict(p=p, status='counterexample_to_uniform_exponent_collision_strategy',
                  conjecture_status='not_disproved_and_not_proved',
                  admissible_shifts=small_support+len(evaluated),
                  max_shift=2*p-3, rejected_by_vector_count=small_support,
                  independently_enumerated=len(evaluated),
                  uniform_exponent_collision_fails_at_every_shift=True,
                  potentially_repairable_by_reweighting=reweightable,
                  verified_es_witness=[x,y,z], evaluated=evaluated)
    if args.out:
        args.out.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='evaluated'}, indent=2))


if __name__ == '__main__':
    main()
