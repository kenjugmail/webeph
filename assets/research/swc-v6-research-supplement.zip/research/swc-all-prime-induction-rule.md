# SWC induction over all primes: explicit positivity obligation

2026-09-05. Status: conditional induction theorem and executable finite-prefix
checker. Its universal positivity premise is not established.

## Induction statement

Let V(p,w) verify positive integer denominators satisfying the Erdős–Straus
identity. Write E(p) for the existence of a witness accepted by V.

Base: E(2), witnessed by (1,2,2), with accepted point mass one.

Required step: for each prime p>2, assuming E(q) for every prime q<p,
construct a normalized distribution nu_p, prove that its accepting outcomes
are sound for V, and establish a checked lower bound

    Pr_{w~nu_p}[V(p,w)] >= delta_p > 0.

If that step is proved uniformly for every prime p, strong induction over
the primes establishes E(p) for all primes. For a composite n, choose a prime
divisor p, write n=kp, and multiply all denominators in its witness by k.
This establishes E(n) for every n>=2.

The delta_p may depend on p and may tend to zero. No uniform positive constant
is necessary. But the universally quantified step needs a proof; writing
delta_p>0 as a requirement does not establish it.

## How nested mass propagation supplies a step

Suppose a target generator chooses a direct branch with weight a and lower
success mass d_p, or a smaller-prime branch q_j<p with weight b_j. All
weights are nonnegative and a+sum b_j=1. Suppose the parent generator has
accepted mass at least delta_{q_j}, and a separately verified transformation
accepts with conditional probability at least t_j on accepted parent outputs.
All transformed successes must pass V(p,...). Then

    delta_p = a*d_p + sum_j b_j*t_j*delta_{q_j}

is a sound lower bound. It is positive if a*d_p>0 or some product in the sum
is positive. This is where positive mass belongs in the induction step.

Compatibility cannot be omitted. A smaller prime's existence theorem alone
does not guarantee t_j>0 for the target's required first denominator. Likewise,
composite parent states in the existing anchor recursion are handled by their
own checked certificates; they are not automatically covered by a prime-only
induction hypothesis.

## Complete root distribution used by the prototype

For odd prime p, let X_p be the integers floor(p/4)+1 through floor(3p/4).
Choose x uniformly from X_p. With probability one half use a full direct
rectangle generator; with probability one half use the existing nested
fixed-anchor generator.

For the direct branch put h=4x-p and M=px. Choose e uniformly among divisors
of M^2. If both M+e and M+M^2/e are divisible by h, emit

    (x, (M+e)/h, (M+M^2/e)/h).

Otherwise reject. The completion-of-the-rectangle identity proves soundness.
Every ordered three-denominator solution has a least denominator in X_p and
is represented by this direct branch. Thus this branch includes Type-I as
well as Type-II prime solutions.

Let D(p,x) be its exact acceptance probability and R(p,x) the exact success
mass from swc_mass_recursion.py. The root mass is

    mu_p(accepted) = sum_{x in X_p} [D(p,x)+R(p,x)]/(2|X_p|).

All summands are nonnegative, so one verified positive contribution gives a
positive root lower bound without evaluating every other anchor. The code
records that contribution and an independently checked output witness.

This is a universally defined, finite procedure for any fixed prime. It can
return no certificate if no accepting state exists. Proving that this never
happens for all primes remains the missing universal positivity theorem.

## Finite loop and checks

The prototype processes primes in increasing order. It appends a prime to the
verified prefix only after recomputing its positive mass contribution and
checking an integer witness. A missing certificate stops the prefix rather
than being supplied as an assumption. A forged mass value is rejected.

The recorded run verifies all 62 primes through 300. This is a test of the new
combined root interface, not a replacement for the earlier larger finite
experiments and not a proof of the universal step.

    python3 -B research/swc_prime_induction.py --limit 300 --out research/evidence/swc-prime-prefix.json

No publication or universal-solution status is changed by this addition.
