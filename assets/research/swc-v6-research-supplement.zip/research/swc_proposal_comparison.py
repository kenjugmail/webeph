"""Compare exact positive-mass SWC proposals on a fixed difficult-prime panel.

All proposals use the same two targets, candidate bounds and sound decoder.
They differ only in weights. These are finite experiments, not universal claims.
"""
import argparse
from collections import Counter
from fractions import Fraction
from itertools import product
import json
from math import comb,gcd,prod
from pathlib import Path
from swc_residue_mass import factors


MODES=('uniform','central_triangular','edge_weighted','binomial')
PANEL=(1009,118801,496609,532249,806521,2458369,8803369,22605361)


def weights(e,mode):
    if mode=='uniform':return [1]*(2*e+1)
    if mode=='central_triangular':return [e+1-abs(j) for j in range(-e,e+1)]
    if mode=='edge_weighted':return [1+abs(j) for j in range(-e,e+1)]
    if mode=='binomial':return [comb(2*e,e+j) for j in range(-e,e+1)]
    raise ValueError('unknown proposal')


def residue_counts(fs,h,mode):
    counts=Counter({1:1});normalizer=1
    for r,e in fs:
        ws=weights(e,mode)
        normalizer*=sum(ws)
        updated=Counter()
        for a,v in counts.items():
            for j,w in zip(range(-e,e+1),ws):
                updated[a*pow(r,j,h)%h]+=v*w
        counts=updated
    if sum(counts.values())!=normalizer:raise ValueError('normalization failure')
    return counts,normalizer


def decode(p,h,c,d):
    if (d+c)%h==0:e=p*d
    elif (4*d+1)%h==0:e=p*p*d
    else:raise ValueError('seed fails both targets')
    M=p*c
    if M*M%e:raise ValueError('not a rectangle divisor')
    other=M*M//e
    if (M+e)%h or (M+other)%h:raise ValueError('inexact denominator')
    x,y,z=c,(M+e)//h,(M+other)//h
    if min(x,y,z)<=0 or 4*x*y*z!=p*(x*y+x*z+y*z):raise ValueError('invalid witness')


def check_seed_enumeration(p,h):
    c=(p+h)//4;fs=factors(c);targets={-1%h,-pow(p,-1,h)%h}
    count_checked=0
    for mode in MODES:
        explicit=Counter()
        for js in product(*(range(-e,e+1) for _,e in fs)):
            d=prod(r**(e+j) for (r,e),j in zip(fs,js))
            residue=d*pow(c,-1,h)%h
            w=prod(weights(e,mode)[j+e] for (_,e),j in zip(fs,js))
            explicit[residue]+=w
            if residue in targets:decode(p,h,c,d);count_checked+=1
        computed,_=residue_counts(fs,h,mode)
        if explicit!=computed:raise ValueError('independent seed enumeration mismatch')
    return count_checked


def evaluate(p):
    shifts=list(range(3,min(179,2*p)+1,4));rows=[]
    for h in shifts:
        c=(p+h)//4;fs=factors(c);targets={-1%h,-pow(p,-1,h)%h}
        masses={};support=None
        for mode in MODES:
            counts,n=residue_counts(fs,h,mode)
            if support is not None and support!=set(counts):raise ValueError('support changed')
            support=set(counts)
            masses[mode]=Fraction(sum(counts[t] for t in targets),n)
        masses['residue_balanced']=Fraction(len(support & targets),len(support))
        masses['half_uniform_half_balanced']=(masses['uniform']+masses['residue_balanced'])/2
        if masses['half_uniform_half_balanced']<masses['uniform']/2:raise ValueError('support floor broken')
        rows.append((h,masses))
    totals={mode:sum((ms[mode] for _,ms in rows),Fraction())/len(shifts) for mode in rows[0][1]}
    # Fixed prior, chosen without inspecting acceptance: weight each shift by 1/h.
    inverse_normalizer=sum((Fraction(1,h) for h,_ in rows),Fraction())
    totals['inverse_shift_uniform_exponents']=sum((ms['uniform']/h for h,ms in rows),Fraction())/inverse_normalizer
    inverse_balanced=sum((ms['residue_balanced']/h for h,ms in rows),Fraction())/inverse_normalizer
    totals['half_baseline_half_inverse_balanced']=(totals['uniform']+inverse_balanced)/2
    linear=sum((h*ms['uniform'] for h,ms in rows),Fraction())/sum(shifts)
    totals['linear_shift_uniform_exponents']=linear
    baseline_mass=totals['uniform']
    totals['half_baseline_half_linear_shift']=baseline_mass/2+linear/2
    if totals['half_baseline_half_linear_shift']<baseline_mass/2:raise ValueError('linear mixture floor broken')
    checked=sum(check_seed_enumeration(p,h) for h,_ in rows)
    baseline=totals['uniform']
    return dict(p=p,shift_count=len(shifts),verified_accepted_seed_checks=checked,
                proposals={m:dict(mass=str(v),probability=float(v),
                                  ratio_to_baseline=str(v/baseline) if baseline else None)
                           for m,v in totals.items()})


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path)
    args=parser.parse_args()
    records=[evaluate(p) for p in PANEL]
    summary={}
    for mode in records[0]['proposals']:
        ratios=[Fraction(r['proposals'][mode]['ratio_to_baseline']) for r in records]
        summary[mode]=dict(wins=sum(r>1 for r in ratios),ties=sum(r==1 for r in ratios),
                           losses=sum(r<1 for r in ratios),
                           minimum_ratio=str(min(ratios)),maximum_ratio=str(max(ratios)))
    out=dict(status='finite_proposal_comparison_universal_positivity_unproved',
             panel=list(PANEL),max_shift=179,targets='-1 and -p^-1 modulo h',
             tuning='fixed weight rules; retrospective difficult-case panel; no holdout claim',
             summary=summary,records=records)
    if args.out:args.out.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
