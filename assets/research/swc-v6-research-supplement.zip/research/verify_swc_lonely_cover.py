"""Independent modular-cover checker. Does not import the producer."""
from fractions import Fraction
from itertools import combinations_with_replacement
from math import comb, gcd, isqrt, prod
from pathlib import Path
import json
import sys


def check(ok,msg):
    if not ok:raise ValueError(msg)


def verify_cover(record):
    check(record.get('schema')=='swc-lonely-modular-cover-v1','schema')
    k,p,l=(record.get(x) for x in ('k','prime','lift'))
    check(all(type(x) is int for x in (k,p,l)),'integer parameters')
    check(3<=k<=13 and 2<=p<=101 and 1<=l<=24,'parameter bounds')
    check(all(p%d for d in range(2,isqrt(p)+1)),'prime')
    q=p*l
    residues=tuple(r for r in range(q) if r%p!=0)
    count=comb(len(residues)+k-1,k)
    check(count*q*k<=5000000,'work budget')
    check(record.get('scope')=='all_residue_tuples_modulo_p_times_l','scope')
    check(record.get('induction_dependency')==f'LRC({k-1})','induction dependency')
    check(record.get('order')=='lexicographic combinations with replacement of residues not divisible by p','order')
    rows=record.get('actions')
    check(isinstance(rows,list) and len(rows)==count,'missing residue classes')
    check(record.get('uncovered')==[],'uncovered classes block cover')
    gcd_count=0
    for speeds,action in zip(combinations_with_replacement(residues,k),rows):
        check(type(action) is int,'unproved class')
        if action<0:
            i=-action-1
            check(0<=i<k,'omitted speed')
            common=l
            for j,v in enumerate(speeds):
                if i!=j:common=gcd(common,v)
            check(common>1,'gcd reduction invalid')
            gcd_count+=1
        else:
            check(0<=action<q,'time range')
            for v in speeds:
                t=Fraction(action*v,q)
                part=t-t.__floor__()
                check(min(part,1-part)>=Fraction(1,k+1),'witness invalid')
    return {'k':k,'prime':p,'lift':l,'orbits':count,'ordered_tuples':len(residues)**k,
            'gcd_reductions':gcd_count,'direct_witnesses':count-gcd_count,
            'conclusion':f'I({k},{p},{l}) is empty',
            'prime_elimination_conditional_on':f'LRC({k-1}) and cited Lemma 2.2'}


def verify_bundle(record):
    check(record.get('schema')=='swc-lonely-modular-pilot-v1','bundle schema')
    covers=record.get('covers')
    check(isinstance(covers,list) and 1<=len(covers)<=30,'bundle size')
    results=[verify_cover(c) for c in covers]
    k=record.get('k')
    check(all(r['k']==k for r in results),'dimension mismatch')
    primes=[r['prime'] for r in results]
    check(len(set(primes))==len(primes),'repeated primes cannot amplify budget')
    bound=Fraction(comb(k+1,2)**(k-1),k)**k
    product=prod(primes)
    check(record.get('prime_product')==product,'prime product')
    check(record.get('product_bound')==str(bound),'bound')
    check(product>=bound,'insufficient prime coverage')
    return {'covers':results,'product':product,'bound':str(bound),
            'conclusion':f'LRC({k}) conditional on LRC({k-1}) and cited finite-reduction theorems',
            'all_dimensions_proved':False}


if __name__=='__main__':
    print(json.dumps(verify_bundle(json.loads(Path(sys.argv[1]).read_text())),indent=2))
