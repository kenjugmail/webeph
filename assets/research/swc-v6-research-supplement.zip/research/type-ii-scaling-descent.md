# Type-II scaling descent

**Status:** exact witness transformer proved; universal parent coverage open  
**Date:** 2026-09-04  
**Claim boundary:** the lemma below is a genuine strict lower-rank witness
transformation.  The finite search does not prove that every prime has a parent
of this form.

## 1. Exact transformer

Assume positive integers `q,x,b,e` satisfy the Type-II identity

\[
\frac4q=\frac1x+\frac1{qb}+\frac1{qe}.
\]

For an integer `L >= 1`, put

\[
p=q+4(L-1)x.
\]

Then

\[
\boxed{
\frac4p=\frac1{Lx}+\frac1{Lpb}+\frac1{Lpe}.}
\]

### Proof

Multiplying the premise by `q` gives

\[
\frac1b+\frac1e=4-\frac qx.
\]

Consequently

\[
\begin{aligned}
\frac1{Lx}+\frac1{Lpb}+\frac1{Lpe}
&=\frac1{Lx}+\frac1{Lp}\left(4-\frac qx\right)\\
&=\frac{p+4x-q}{Lpx}\\
&=\frac{4Lx}{Lpx}\\
&=\frac4p.
\end{aligned}
\]

For `L >= 2`, positivity of the remainder in the parent identity forces
`x > q/4`, so

\[
p=q+4(L-1)x>Lq\ge2q.
\]

Thus `q < p/2`: the transformer is strict under the ordinary integer rank.

### General denominator-aligned form

The Type-II divisibility is sufficient but not necessary for transport.  Start
from any ordered witness

\[
\frac4q=\frac1x+\frac1y+\frac1z.
\]

Choose `L >= 1` such that `q | Ly` and `q | Lz`, and again set
`p=q+4(L-1)x`.  Then the integer denominators

\[
X=Lx,
\qquad Y=\frac{Lpy}{q},
\qquad Z=\frac{Lpz}{q}
\]

satisfy `4/p=1/X+1/Y+1/Z`.  Indeed,

\[
\frac1X+\frac1Y+\frac1Z
=\frac1{Lx}+\frac q{Lp}\left(\frac1y+\frac1z\right)
=\frac{p+4x-q}{Lpx}=\frac4p.
\]

Taking `L=q` always clears the divisibility conditions.  Therefore **every
ordered lower witness has an infinite exact family of children**.  The
remaining coverage problem is arithmetic: a prescribed target `p` must equal
one of those children.  This corollary removes witness-type restrictions from
the transformer itself, but does not establish that every target has a parent.

### Composition law

For Type-II witnesses the transformations form a multiplicative semigroup.
Applying scale `L` and then scale `M` changes the first denominator from `x`
to `LMx`, and the final target is

\[
q+4(LM-1)x.
\]

Thus

\[
\boxed{\mathcal T_M\circ\mathcal T_L=\mathcal T_{LM}.}
\]

Every composite scale therefore carries a canonical chain of strict inverse
steps along its factors.  The finite search records the smallest tested first
factor `L`; it does not infer universality from this semigroup law.

## 2. Normalized certificate interpretation

A normalized Type-II certificate can be written

\[
A+B=hQ,\qquad q+h=4ABT,
\]

with witness

\[
\frac4q=
\frac1{ABT}+
\frac1{qAQT}+
\frac1{qBQT}.
\]

Replacing `T` by `LT` preserves `A+B=hQ` and gives

\[
p+h=4AB(LT),
\qquad
p=q+4(L-1)ABT.
\]

The transformer is therefore the exact operation "multiply the unused
Type-II factor `T` by `L`."  Conversely, a Type-II certificate with composite
unused factor descends by dividing that factor.

## 3. Divisor form used by the search

Let

\[
h\equiv3\pmod4,
\qquad q=4x-h\ge2,
\qquad \gcd(x,h)=1.
\]

If a divisor `d | x^2` satisfies

\[
d\equiv-x\pmod h,
\]

then the complementary divisor `d'=x^2/d` also satisfies
`d' == -x (mod h)`.  Set

\[
b=\frac{x+d}{h},
\qquad
e=\frac{x+d'}{h}.
\]

Completion of the rectangle gives

\[
hbe=x(b+e),
\]

and hence the required parent Type-II identity.  For every `L >= 2`, the
child

\[
p=4Lx-h
\]

is then certified by the scaling lemma.

Equivalently, with the child anchor `C_h=(p+h)/4=Lx`, this is an **interior
signed-divisor hit**: a proper divisor `x | C_h` already has `-1` in its signed
divisor-ratio box modulo `h`, leaving the nontrivial factor `L` unused.

### Canonical primitive parent

The divisor certificate can be normalized all the way to a primitive seed.
Let

\[
g=\gcd(x,d),
\qquad A=\frac{x}{g},
\qquad B=\frac{d}{g},
\qquad T=\frac{g^2}{d}.
\]

The condition `d | x^2` implies that `T` is a positive integer, and

\[
x=ABT,
\qquad d=B^2T,
\qquad \gcd(A,B)=1.
\]

Because `gcd(x,h)=1`, the congruence `h | x+d` reduces to

\[
A+B=hQ
\]

for a positive integer `Q`.  Define

\[
q_0=4AB-h.
\]

Since `h <= A+B` and `4AB-(A+B) >= 2` for positive `A,B`, one has
`q_0 >= 2`.  It has the primitive Type-II witness

\[
\frac4{q_0}
=\frac1{AB}
+\frac1{q_0BQ}
+\frac1{q_0AQ}.
\]

The searched target is obtained from this seed at total scale `S=LT`:

\[
p=4AB(LT)-h=q_0+4(S-1)AB.
\]

Thus each finite record contains not merely a smaller certified intermediate
`q=4x-h`, but a canonical primitive certified seed `q_0` and a composable
witness path from `q_0` to `p`.

## 4. Exact finite search

Two independent implementations agree through `10^7`:

- `research/type_ii_descent_search.py` uses Python arbitrary-precision integer
  arithmetic;
- `research/type_ii_descent_search.cpp` independently enumerates and checks
  the divisor relation and both parent/child identities.

The optimized C++ search was then run over every prime

\[
p\equiv1\pmod{24},\qquad p<10^8.
\]

Using only

\[
3\le h\le179,\quad h\equiv3\pmod4,
\qquad 2\le L\le13,
\]

it found and exactly checked a strict parent for all `719,781` targets.  The
largest first shift was `h=179`, at

\[
p=22,605,361,
\quad q=7,535,001,
\quad L=3,
\quad x=1,883,795,
\quad d=1.
\]

This is a stronger finite pattern than merely finding an arbitrary solution:
every tested target lies on a certified Type-II progression whose seed is less
than half the target.  It remains finite evidence.

A separate deterministic 64-bit falsification probe tested the first `100,000`
Mordell-hard primes at or above `10^15`, and another `5,000` at or above
`9*10^17`.  Neither sample produced a miss under the same `h <= 179`,
`L <= 13` corridor.  These are sparse high-height samples, not exhaustive
intervals and not evidence that the finite ceiling is universal.

Machine-readable records are in:

- `research/evidence/type-ii-descent-100m.json`;
- `research/evidence/type-ii-descent-probe-mordell-1e15.json`;
- `research/evidence/type-ii-descent-probe-mordell-9e17.json`.

## 5. Why ordinary strong induction is not yet enough

The transformer consumes a Type-II witness with the particular first
denominator `x` satisfying

\[
p-q=4(L-1)x.
\]

An induction hypothesis asserting only that `q` has *some* Erdős--Straus
witness does not supply this alignment.

There is also a useful primitivity check.  If the child `p` is prime, then

\[
\gcd(q,x)=1,
\]

because every common divisor of `q` and `x` divides
`p=q+4(L-1)x`.  Therefore a composite parent's witness cannot be a trivial
common scaling of a witness for a proper divisor: such a scaling would give
`gcd(q,x)>1` and would make the child composite.  The lower-rank premise must
be a genuinely primitive Type-II certificate, not merely the usual
divisor-to-multiple solution.

## 6. Exact missing theorem

The observed route would become a universal proof if one established:

> For every prime `p == 1 (mod 24)`, there are positive integers
> `h,L,x,d` with `h == 3 (mod 4)`, `L >= 2`, `q=4x-h >= 2`,
> `p=4Lx-h`, `gcd(x,h)=1`, `d | x^2`, and `h | x+d`.

The finite search does not establish this quantifier.  In signed-box language,
the unproved assertion is

\[
\forall p\equiv1\pmod{24}\text{ prime},\quad
\exists h\equiv3\pmod4,\ \exists x\mid\frac{p+h}{4},\quad
1<x<\frac{p+h}{4},\quad -1\in\mathcal R_h(x),
\]

with the displayed positivity conditions.  Proving this "interior hit"
statement, or finding a different total parent selector, is the remaining
universal obligation.

## 7. Relation to current literature

- [Bello-Hernández, Benito, and Fernández](https://arxiv.org/abs/2606.10922)
  prove certificate-preserving
  translation for their `fab` parameters.  It moves known certificates through
  arithmetic progressions but does not prove total coverage.
- [Dahan](https://arxiv.org/abs/2608.24035)'s two-parameter criterion is
  complete for Type-II solutions and proves
  very thin exceptional-set bounds.  It explicitly leaves emptiness of the
  all-depth exceptional intersection open.
- The [Lean offset formalization](https://github.com/carlok/erdos-straus-offset-lean)
  proves a fixed-divisor transport theorem and
  its least period, while explicitly retaining the conjecture as open.
- [Dyachenko](https://arxiv.org/abs/2511.07465)'s claimed all-prime
  affine-lattice route cannot be used as a proof:
  its rectangle-hitting step chooses two coordinate representatives
  independently but then has only one diagonal translation parameter.  The
  stated lattice lemma has elementary counterexamples.
- [Bradford](https://arxiv.org/abs/2602.11774)'s claimed covering argument lists
  families but does not prove that
  they cover the remaining prime classes.

The useful addition here is therefore narrow but real: a simple strict
witness transformer and a sharply stated interior-divisor theorem target.
