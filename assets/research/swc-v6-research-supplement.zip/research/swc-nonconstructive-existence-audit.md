# Nonconstructive SWC existence attempt: counting and local-to-global arguments

2026-09-05. Outcome: a bounded modular reformulation is proved below, but its
universal solvability is not established. No Erdős–Straus solution is claimed.

## First-moment attempt

For a fixed n, a nonnegative random count Z_n of valid witness configurations
would prove existence if E[Z_n]>0. A second-moment argument could turn a
proved first moment into a positive success bound. However, available average
counts across primes do not imply that E[Z_p]>0 at each prime individually.

Elsholtz–Planitzer prove, among other results, that every reduced arithmetic
progression contains infinitely many primes with many three-unit-fraction
representations. The quantifiers remain “infinitely many” in each progression,
not “every prime.” This does not cover each remaining prime for SWC.

Source: https://arxiv.org/abs/1805.02945.

## Local-to-global attempt

Bright–Loughran, Theorem 1.1, show no Brauer–Manin obstruction to positive
integer solutions for n>=2. Their Section 1.2 formulates the original
conjecture as a particular strong-approximation assertion. The absence of
this obstruction does not establish that assertion. Invoking it as a
sufficient theorem for existence would leave a gap.

Source: https://arxiv.org/html/1908.02526.

## A complete finite witness bound

If a solution exists, order its denominators x<=y<=z. Positivity gives
n/4<x<=3n/4. Set h=4x-n>=1 and M=nx. Then

    h/M = 1/y + 1/z,
    M/h < y <= 2M/h,
    z=My/(hy-M).

The denominator hy-M is a positive integer, so z<=My<=2M^2/h<=2M^2.
Since M<=3n^2/4, z<=9n^4/8. Thus all ordered denominators are bounded by

    B(n)=2n^4.

This loose bound is sufficient here; it is not claimed optimal. It is a
necessary bound on witnesses if they exist, not a proof that they exist.

## Exact bounded-congruence criterion

Put F_n(x,y,z)=4xyz-n(xy+xz+yz), B=2n^4, and

    Q=4B^3+3nB^2+1.

For 1<=x,y,z<=B, one has |F_n(x,y,z)|<Q. Therefore

    F_n(x,y,z)==0 modQ if and only if F_n(x,y,z)=0.

Together with the witness bound, this proves:

    a positive integer Erdős–Straus solution exists for n
    if and only if the single congruence F_n=0 modQ
    has a representative in the fixed box {1,...,B}^3.

Uniform sampling in this box gives a valid SWC distribution. Its exact
accepted mass is the number of solutions in the box divided by B^3.
Showing it is positive for every n would solve the original conjecture.
No proof of that positive count was obtained here.

## Why unrestricted modular feasibility or compactness is insufficient

For any modulus m, the positive representatives x=y=z=m automatically
satisfy F_n(x,y,z)==0 modm. But

    F_n(m,m,m)=m^2(4m-3n)

is generally nonzero. Such witnesses escape every fixed box as m grows.
Thus positivity of modular representatives for every modulus does not imply
a positive integer solution to the exact equation.

A finite-set compactness argument would work if a common finite witness bound
were respected by solutions to every modulus: one can also directly choose
the Q above. The local results inspected do not supply that bounded global
feasibility. Compactness therefore does not fill the missing SWC positivity
premise.

This attempt isolates a possible theorem target involving bounded modular
counts. It does not convert the known local or average statements into a
universal existence result.
