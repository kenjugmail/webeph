#include <algorithm>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <numeric>
#include <string>
#include <utility>
#include <vector>

using i64 = std::int64_t;
using i128 = __int128_t;

static std::vector<int> primes_through(int limit) {
    std::vector<bool> prime(limit + 1, true);
    prime[0] = prime[1] = false;
    for (int n = 2; (i64)n * n <= limit; ++n) {
        if (!prime[n]) continue;
        for (i64 multiple = (i64)n * n; multiple <= limit; multiple += n)
            prime[(int)multiple] = false;
    }
    std::vector<int> result;
    for (int n = 2; n <= limit; ++n)
        if (prime[n]) result.push_back(n);
    return result;
}

static std::vector<int> smallest_prime_factor(int limit) {
    std::vector<int> spf(limit + 1);
    for (int n = 0; n <= limit; ++n) spf[n] = n;
    if (limit >= 1) spf[1] = 1;
    for (int n = 2; (i64)n * n <= limit; ++n) {
        if (spf[n] != n) continue;
        for (i64 multiple = (i64)n * n; multiple <= limit; multiple += n)
            if (spf[(int)multiple] == multiple) spf[(int)multiple] = n;
    }
    return spf;
}

static void divisor_rec(
    const std::vector<std::pair<int, int>>& factors,
    int index,
    i64 current,
    std::vector<i64>& output
) {
    if (index == (int)factors.size()) {
        output.push_back(current);
        return;
    }
    auto [prime, exponent] = factors[index];
    i64 power = 1;
    for (int e = 0; e <= 2 * exponent; ++e) {
        divisor_rec(factors, index + 1, current * power, output);
        power *= prime;
    }
}

static std::vector<i64> square_divisors(int value, const std::vector<int>& spf) {
    std::vector<std::pair<int, int>> factors;
    while (value > 1) {
        int prime = spf[value], exponent = 0;
        while (value % prime == 0) {
            value /= prime;
            ++exponent;
        }
        factors.push_back({prime, exponent});
    }
    std::vector<i64> divisors;
    divisor_rec(factors, 0, 1, divisors);
    std::sort(divisors.begin(), divisors.end());
    return divisors;
}

static bool verifies_type_ii(i64 n, i64 x, i64 b, i64 e, i64 shift) {
    if (std::min({n, x, b, e, shift}) <= 0) return false;
    if ((i128)4 * x != (i128)n + shift) return false;
    return (i128)shift * b * e == (i128)x * (b + e);
}

struct Parent {
    int p = 0;
    int q = 0;
    int scale = 0;
    int shift = 0;
    int x = 0;
    i64 divisor = 0;
    i64 b = 0;
    i64 e = 0;
    i64 primitive_a = 0;
    i64 primitive_b = 0;
    i64 primitive_unused = 0;
    i64 primitive_q = 0;
    i64 total_scale = 0;
};

static bool find_parent(
    int p,
    int max_shift,
    int max_scale,
    const std::vector<int>& spf,
    Parent& result
) {
    for (int shift = 3; shift <= max_shift && shift < p; shift += 4) {
        for (int scale = 2; scale <= max_scale; ++scale) {
            i64 numerator = (i64)p + shift;
            if (numerator % (4 * scale) != 0) continue;
            int x = (int)(numerator / (4 * scale));
            int q = 4 * x - shift;
            if (q < 2 || q >= p) continue;
            for (i64 divisor : square_divisors(x, spf)) {
                if ((divisor + x) % shift != 0) continue;
                i64 complement = (i64)x * x / divisor;
                if ((complement + x) % shift != 0)
                    throw std::runtime_error("complementary congruence failed");
                i64 b = (x + divisor) / shift;
                i64 e = (x + complement) / shift;
                if (!verifies_type_ii(q, x, b, e, shift))
                    throw std::runtime_error("parent witness failed");
                if (!verifies_type_ii(p, (i64)scale * x, (i64)scale * b, (i64)scale * e, shift))
                    throw std::runtime_error("transported witness failed");
                i64 common = std::gcd((i64)x, divisor);
                i64 primitive_a = x / common;
                i64 primitive_b = divisor / common;
                i64 primitive_unused = common * common / divisor;
                i64 primitive_q = 4 * primitive_a * primitive_b - shift;
                i64 total_scale = (i64)scale * primitive_unused;
                result = Parent{
                    p, q, scale, shift, x, divisor, b, e,
                    primitive_a, primitive_b, primitive_unused,
                    primitive_q, total_scale
                };
                return true;
            }
        }
    }
    return false;
}

int main(int argc, char** argv) {
    int limit = argc > 1 ? std::stoi(argv[1]) : 10'000'000;
    int max_shift = argc > 2 ? std::stoi(argv[2]) : 511;
    int max_scale = argc > 3 ? std::stoi(argv[3]) : 16;
    std::string output = argc > 4 ? argv[4] : "research/evidence/type-ii-descent-cpp.json";

    auto primes = primes_through(limit);
    int max_x = (limit + max_shift) / 8 + 2;
    auto spf = smallest_prime_factor(max_x);
    i64 targets = 0, covered = 0;
    std::vector<int> misses;
    std::map<int, i64> scale_histogram, shift_histogram, parent_mod24_histogram;
    Parent largest_shift;
    double largest_parent_ratio = 0.0;

    for (int p : primes) {
        if (p % 24 != 1) continue;
        ++targets;
        Parent parent;
        if (!find_parent(p, max_shift, max_scale, spf, parent)) {
            if (misses.size() < 100) misses.push_back(p);
            continue;
        }
        ++covered;
        ++scale_histogram[parent.scale];
        ++shift_histogram[parent.shift];
        ++parent_mod24_histogram[parent.q % 24];
        largest_parent_ratio = std::max(largest_parent_ratio, (double)parent.q / p);
        if (parent.shift > largest_shift.shift) largest_shift = parent;
    }

    std::ofstream out(output);
    out << "{\n";
    out << "  \"status\": \"finite_conjecture_search_only\",\n";
    out << "  \"limit\": " << limit << ",\n";
    out << "  \"max_shift\": " << max_shift << ",\n";
    out << "  \"max_scale\": " << max_scale << ",\n";
    out << "  \"targets\": " << targets << ",\n";
    out << "  \"covered_by_strict_parent\": " << covered << ",\n";
    out << "  \"miss_count\": " << (targets - covered) << ",\n";
    out << "  \"largest_parent_ratio\": " << largest_parent_ratio << ",\n";
    out << "  \"largest_shift_record\": {\"p\": " << largest_shift.p
        << ", \"q\": " << largest_shift.q
        << ", \"scale\": " << largest_shift.scale
        << ", \"shift\": " << largest_shift.shift
        << ", \"parent_x\": " << largest_shift.x
        << ", \"divisor\": " << largest_shift.divisor
        << ", \"primitive_a\": " << largest_shift.primitive_a
        << ", \"primitive_b\": " << largest_shift.primitive_b
        << ", \"primitive_unused_factor\": " << largest_shift.primitive_unused
        << ", \"primitive_q\": " << largest_shift.primitive_q
        << ", \"total_scale\": " << largest_shift.total_scale << "},\n";

    auto write_histogram = [&out](const char* name, const std::map<int, i64>& histogram, bool comma) {
        out << "  \"" << name << "\": {";
        bool first = true;
        for (auto [key, count] : histogram) {
            if (!first) out << ',';
            out << "\n    \"" << key << "\": " << count;
            first = false;
        }
        if (!histogram.empty()) out << '\n';
        out << "  }" << (comma ? "," : "") << "\n";
    };
    write_histogram("scale_histogram", scale_histogram, true);
    write_histogram("shift_histogram", shift_histogram, true);
    write_histogram("parent_mod24_histogram", parent_mod24_histogram, true);
    out << "  \"first_misses\": [";
    for (std::size_t i = 0; i < misses.size(); ++i) {
        if (i) out << ", ";
        out << misses[i];
    }
    out << "]\n}\n";
    out.close();

    std::cerr << "targets=" << targets << " covered=" << covered
              << " misses=" << (targets - covered)
              << " max_shift=" << largest_shift.shift
              << " at p=" << largest_shift.p << '\n';
    return covered == targets ? 0 : 2;
}
