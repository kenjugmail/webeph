"""SWC operating contracts: exact outputs, declared finite domains, IID reliability.

Only the standard library is required. Probability calculations are rational.
Measurement validity and IID provenance are explicit external assumptions.
"""
from fractions import Fraction
from itertools import combinations
from math import comb, gcd
import hashlib
import json


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def integer(value,lo=0,hi=10000):
    require(type(value) is int and lo<=value<=hi,'bounded integer required')
    return value


def probability(value):
    require(type(value) is str and len(value)<=80,'rational probability string required')
    try:
        p=Fraction(value)
    except (ValueError,ZeroDivisionError):
        raise ValueError('invalid probability') from None
    require(0<p<1 and p.denominator.bit_length()<=32,'probability out of bounds')
    return p


def check_instance(relation,instance):
    if relation=='lonely_runner':
        require(isinstance(instance,list) and 2<=len(instance)<=16,'2..16 speeds required')
        for v in instance:integer(v,1,10000)
        require(instance==sorted(set(instance)),'speeds must be increasing and distinct')
    elif relation=='erdos_straus':
        integer(instance,2,10**9)
    else:
        raise ValueError('unsupported relation')


def exact_witness(relation,instance,witness):
    """Verify a mathematical relation only; no model or measurement claims."""
    check_instance(relation,instance)
    if relation=='lonely_runner':
        require(isinstance(witness,list) and len(witness)==2,'rational time pair required')
        m,q=witness
        integer(q,1,10**9);integer(m,0,q-1)
        return all((len(instance)+1)*min(m*v%q,q-m*v%q)>=q for v in instance)
    require(isinstance(witness,list) and len(witness)==3,'three denominators required')
    for x in witness:
        require(type(x) is int and x>0 and x.bit_length()<=4096,'positive exact denominator required')
    x,y,z=witness
    return 4*x*y*z==instance*(x*y+x*z+y*z)


def receipt(relation,instance,witness):
    require(exact_witness(relation,instance,witness),'witness rejected')
    body={'schema':'swc-exact-output-v1','relation':relation,'instance':instance,
          'witness':witness,'scope':'single_mathematical_instance'}
    return {'body':body,'sha256':digest(body)}


def verify_receipt(record):
    require(isinstance(record,dict) and isinstance(record.get('body'),dict),'receipt object required')
    body=record['body']
    require(set(body)=={'schema','relation','instance','witness','scope'},'unexpected receipt fields')
    require(body['schema']=='swc-exact-output-v1','receipt schema')
    require(body['scope']=='single_mathematical_instance','scope escalation')
    require(record.get('sha256')==digest(body),'receipt bytes changed')
    require(exact_witness(body['relation'],body['instance'],body['witness']),'invalid exact relation')
    return {'status':'verified','scope':'single_mathematical_instance'}


def domain_instances(manifest):
    require(isinstance(manifest,dict),'manifest required')
    require(set(manifest)=={'kind','relation','speed_count','min_speed','max_speed','primitive_only','open_only'},
            'unknown domain fields')
    require(manifest['kind']=='bounded_speed_combinations' and manifest['relation']=='lonely_runner','domain kind')
    n=integer(manifest['speed_count'],2,16)
    low=integer(manifest['min_speed'],1,10000);high=integer(manifest['max_speed'],low,10000)
    require(high-low+1>=n,'empty domain not allowed')
    require(type(manifest['primitive_only']) is bool and type(manifest['open_only']) is bool,'boolean filters')
    require(comb(high-low+1,n)<=200000,'finite domain enumeration budget exceeded')
    for values in combinations(range(low,high+1),n):
        if manifest['primitive_only'] and gcd(*values)>1:continue
        if manifest['open_only'] and not all(any(v%d==0 for v in values) for d in range(2,n+2)):continue
        yield list(values)


def verify_finite_domain(bundle):
    require(bundle.get('schema')=='swc-finite-coverage-v1','coverage schema')
    manifest=bundle.get('domain')
    require(bundle.get('domain_sha256')==digest(manifest),'domain fingerprint')
    expected=list(domain_instances(manifest))
    require(expected,'nonempty domain required')
    rows=bundle.get('rows')
    require(isinstance(rows,list) and len(rows)==len(expected),'missing or extra domain rows')
    for instance,row in zip(expected,rows):
        require(isinstance(row,dict) and row.get('instance')==instance,'domain order or membership mismatch')
        require(exact_witness(manifest['relation'],instance,row.get('witness')),'finite witness failed')
    require(bundle.get('rows_sha256')==digest(rows),'evidence fingerprint')
    return {'status':'complete_finite_coverage','domain':manifest,'domain_sha256':digest(manifest),
            'instances_verified':len(expected),'scope':'exactly_the_declared_finite_domain',
            'claim':'Every instance in this manifest has a verified mathematical witness.'}


def binomial_cdf_exact(n,failures,p):
    """P[Binomial(n,p)<=failures] using exact integer arithmetic."""
    integer(n,1,10000);integer(failures,0,n)
    require(isinstance(p,Fraction) and 0<=p<=1 and p.denominator.bit_length()<=32,'exact p required')
    if failures==n or p==0:return Fraction(1)
    if p==1:return Fraction(0)
    require(n*min(failures+1,n-failures)<=200000,'binomial computation budget exceeded')
    a,b=p.numerator,p.denominator
    def lower_terms(k,x,y):
        term=pow(y-x,n);total=term
        for j in range(k):
            numerator=term*(n-j)*x
            denominator=(j+1)*(y-x)
            term,remainder=divmod(numerator,denominator)
            require(remainder==0,'nonintegral binomial recurrence')
            total+=term
        return total
    denominator=pow(b,n)
    if failures<=n//2:numerator=lower_terms(failures,a,b)
    else:numerator=denominator-lower_terms(n-failures-1,b-a,b)
    return Fraction(numerator,denominator)


def upper_failure_bound(n,failures,alpha,grid_bits=20):
    """Conservative rational rounding of the one-sided Clopper-Pearson bound."""
    integer(n,1,10000);integer(failures,0,n);integer(grid_bits,4,24)
    require(isinstance(alpha,Fraction) and 0<alpha<1,'exact alpha required')
    if failures==n:return Fraction(1)
    scale=1<<grid_bits;left=0;right=scale
    while right-left>1:
        middle=(left+right)//2
        if binomial_cdf_exact(n,failures,Fraction(middle,scale))<=alpha:right=middle
        else:left=middle
    return Fraction(right,scale)


def reliability_report(plan,events):
    """A fixed-horizon statement conditional on the declared sampling design.

    The checker cannot certify that event provenance is honest or that physical
    observations are IID. It validates trial inclusion, exact outputs, and math.
    """
    require(plan.get('schema')=='swc-reliability-plan-v1','plan schema')
    require(plan.get('sampling_design')=='fresh_iid_fixed_horizon','adaptive or selected sample rejected')
    require(plan.get('selection')=='all_draws_including_failures','filtered sample rejected')
    n=integer(plan.get('sample_size'),1,10000)
    alpha=probability(plan.get('alpha'));target=probability(plan.get('target_failure_rate'))
    require(plan.get('failure_definition')=='anything_without_a_verified_receipt','failure semantics')
    require(type(plan.get('distribution')) is str and bool(plan['distribution'].strip()),'distribution missing')
    require(type(plan.get('configuration_sha256')) is str and len(plan['configuration_sha256'])==64,'configuration identity')
    require(type(plan.get('provenance')) is str and bool(plan['provenance'].strip()),'provenance missing')
    require(plan.get('relation') in ('lonely_runner','erdos_straus'),'relation')
    require(isinstance(events,list) and len(events)==n,'fixed horizon incomplete or exceeded')
    plan_hash=digest(plan);failures=0;previous=plan_hash;statuses={}
    for index,event in enumerate(events):
        require(isinstance(event,dict) and event.get('trial_id')==index,'duplicate, missing, or reordered trial')
        require(event.get('plan_sha256')==plan_hash,'different evaluation plan')
        require(event.get('configuration_sha256')==plan['configuration_sha256'],'configuration changed')
        require(event.get('previous_sha256')==previous,'event chain mismatch')
        body={k:v for k,v in event.items() if k!='sha256'}
        require(event.get('sha256')==digest(body),'event fingerprint')
        previous=event['sha256'];status=event.get('status')
        require(status in ('verified','unresolved','invalid','error','timeout'),'unknown outcome')
        check_instance(plan['relation'],event.get('instance'))
        if status=='verified':
            cert=event.get('receipt');verify_receipt(cert)
            require(cert['body']['instance']==event['instance'],'receipt is for a different input')
            require(cert['body']['relation']==plan['relation'],'receipt is for a different relation')
        else:failures+=1
        statuses[status]=statuses.get(status,0)+1
    upper=upper_failure_bound(n,failures,alpha)
    passes=binomial_cdf_exact(n,failures,target)<=alpha
    if passes:upper=min(upper,target)
    return {'schema':'swc-reliability-report-v1','trials':n,'failures':failures,'status_counts':statuses,
            'alpha':str(alpha),'confidence_level':str(1-alpha),'failure_rate_upper_bound':str(upper),
            'success_rate_lower_bound':str(1-upper),'target_failure_rate':str(target),
            'target_demonstrated':passes,'plan_sha256':plan_hash,'event_chain_final':previous,
            'scope':plan['distribution'],'configuration_sha256':plan['configuration_sha256'],
            'assumptions':['fresh independent identically distributed inputs from the declared distribution',
                           'fixed configuration and horizon chosen before inspecting outcomes',
                           'all trials reported truthfully, including errors and unresolved results'],
            'interpretation':'Frequentist confidence guarantee for this input distribution and configuration.',
            'physical_deployment_validated':False}


def zero_failure_sample_size(target,alpha,limit=10000):
    require(isinstance(target,Fraction) and 0<target<1,'target')
    require(isinstance(alpha,Fraction) and 0<alpha<1,'alpha')
    integer(limit,1,10000)
    if (1-target)**limit>alpha:return None
    low=0;high=limit
    while high-low>1:
        middle=(high+low)//2
        if (1-target)**middle<=alpha:high=middle
        else:low=middle
    return high
