# Six targeted infinite families and the uncovered set

2026-09-05. These are explicit instances of the classical Type-II family
identity, compiled into SWC using accepted point mass one. They are not a
new proof of the whole conjecture or a claim of novelty for these families.

The standard elementary congruence reductions leave primes with residues
1,121,169,289,361,529 modulo 840 as a sufficient domain for further work.
This does not mean every prime in that domain is individually unresolved.
See [López, introduction](https://arxiv.org/pdf/2404.01508).

For each row below set S=S0+Kt and Q=(A+B)/h. For every integer t>=0,

    n=4ABS-h, X=ABS, Y=nAQS, Z=nBQS.

All denominators are positive integers and

    1/X+1/Y+1/Z = [nQ+A+B]/(nABQS)
                = Q(n+h)/(nABQS) = 4/n.

| Hard residue mod 840 | Infinite subfamily n(t) | A | B | h | S0 | K |
|---:|---|---:|---:|---:|---:|---:|
| 1 | 2521+24360t | 2 | 29 | 31 | 11 | 105 |
| 121 | 1801+34440t | 41 | 1 | 3 | 11 | 210 |
| 169 | 1009+19320t | 23 | 1 | 3 | 11 | 210 |
| 289 | 1129+15960t | 19 | 3 | 11 | 5 | 70 |
| 361 | 1201+14280t | 17 | 6 | 23 | 3 | 35 |
| 529 | 3049+14280t | 85 | 3 | 11 | 3 | 14 |

Each row has h|(A+B); its step is a multiple of 840. Base and step are
coprime, so each progression contains infinitely many primes by
[Dirichlet's theorem](https://dlmf.nist.gov/27.11). The identity itself
applies to every positive integer in the progression, including composites.

## Induction and mass

The invariant at t retains S=S0+Kt, n=4ABS-h and the three denominator
formulas. At the successor replace S by S+K. The displayed algebra proves
the successor identity, with all divisions exact and denominators positive.
The base t=0 is directly certified. Thus induction proves the identity for
every t>=0 in each row.

Point mass on the explicitly constructed triple has accepted probability one
at every t. The successor map transports that mass to the next triple. This
uses SWC's deterministic-witness embedding; the probability language does
not supply the algebraic identity or add coverage beyond it.

For instance, with n=2521+24360t and S=11+105t,

    4/n = 1/(58S) + 1/(2Sn) + 1/(29Sn).

This is a fully proved infinite subset of the 1 mod840 class. It is not a
proof for every prime congruent to 1 mod840.

## What remains after these six rows

The exact residual set for this six-row registry is the set of primes p whose
residue modulo840 is one of the six hard residues and which belong to none
of the displayed progressions with t>=0.

Its first examples are 2689,3361,3529,3889,4201,4561,4729,5209,5569,5881,
6841,7561. They are uncovered by these six symbolic families, not claimed to
lack known individual solutions. Earlier finite certificate searches already
cover them.

The residual is infinite: put

    M=lcm(840,4A_iB_i)=7419788040.

Every prime p==1 modM is in the hard class but outside every row's underlying
family. Indeed, membership would imply 4A_iB_i divides 1+h_i, while
0<1+h_i<=1+A_i+B_i<4A_iB_i. Dirichlet's theorem supplies infinitely many
such primes. This is a concrete instance of the finite-family obstruction
in swc-family-induction-and-coverage.md.

A universal solution therefore still requires a proved parameter-varying
construction or another coverage theorem for the residual. Adding rows can
prove further infinite subfamilies but does not establish that they exhaust
all primes.

Reproduce parameter checks and residual examples:

    python3 -B research/swc_targeted_families.py --out research/evidence/swc-targeted-families.json
