"""Read the supplied text as data, independently verify it, test finite boxes."""
from pathlib import Path
from itertools import combinations
from fractions import Fraction
from math import gcd
from functools import lru_cache
import hashlib
import json
import re
import time
from swc_canonical_pair import is_open, canonical_witness, verify_witness, targets
from swc_lonely_runner import exact_grid_record, lonely
from verify_swc_canonical_obstruction import inspect

SOURCE=Path('/Users/kt/.codex/attachments/42e7d412-5c52-4f93-8913-b9b832c6d324/pasted-text.txt')
HEADER=re.compile(r'^(\[[\d, ]+\])\s+least witness t=(\d+/\d+)\s+max gap (\d+/\d+)$')
PAIR=re.compile(r'^pair \((\d+),(\d+)\) q=(\d+) m=(\d+)\s+t=(\d+/\d+)\s+pair position (\d+/\d+)$')


def exact_rows(values,unit=False):
    rows=[];N=len(values)+1
    for a,b in combinations(values,2):
        q=a+b
        for m in range(q):
            if unit and gcd(m,q)!=1:continue
            if all(N*min(m*v%q,q-m*v%q)>=q for v in values):
                rows.append((a,b,q,m))
    return rows


def parse():
    blocks=[]
    for line in SOURCE.read_text().splitlines():
        match=HEADER.match(line)
        if match:
            values=json.loads(match[1]);blocks.append({'speeds':values,
                'least_time':match[2],'max_gap':match[3],'rows':[]});continue
        match=PAIR.match(line)
        if match:
            if not blocks:raise ValueError('unbound pair row')
            a,b,q,m=map(int,match.groups()[:4])
            blocks[-1]['rows'].append((a,b,q,m,match[5],match[6]))
    if len(blocks)!=75:raise ValueError(f'expected 75 sets, got {len(blocks)}')
    return blocks


def historical_reproduction(blocks):
    @lru_cache(None)
    def candidates(a,b,ds):
        q=a+b
        if gcd(a,b)!=1:return ()
        inverse=pow(a,-1,q);out=set()
        for d in ds:
            for k in range(1,d):
                for c in (k*q//d,(k*q+d-1)//d):out.add((c*inverse%q,q))
        return tuple(out)
    counts={'primitive_open_sets':0,'rounded_half_coprime_pairs':0,
            'rounded_halves_thirds_quarters_coprime_pairs':0}
    misses=[]
    for vs in combinations(range(1,21),7):
        if gcd(*vs)>1 or not is_open(vs):continue
        counts['primitive_open_sets']+=1
        for ds,key in (((2,),'rounded_half_coprime_pairs'),
                       ((2,3,4),'rounded_halves_thirds_quarters_coprime_pairs')):
            works=any(all(8*min(m*v%q,q-m*v%q)>=q for v in vs)
                      for a,b in combinations(vs,2) for m,q in candidates(a,b,ds))
            counts[key]+=works
            if ds==(2,3,4) and not works:misses.append(list(vs))
    counts['residual_list_matches_exactly']=misses==[b['speeds'] for b in blocks]
    return counts


def main():
    start=time.monotonic();blocks=parse();audits=[]
    for block in blocks:
        vs=block['speeds'];invalid=[];oriented_mismatches=0;actual=set(exact_rows(vs));unit=set(exact_rows(vs,True))
        for a,b,q,m,t,position in block['rows']:
            if (a,b,q,m) not in actual or Fraction(t)!=Fraction(m,q):invalid.append([a,b,q,m,'witness'])
            folded=Fraction(min(a*m%q,q-a*m%q),q)
            if folded!=Fraction(position):invalid.append([a,b,q,m,'distance'])
            oriented_mismatches+=Fraction(a*m%q,q)!=Fraction(position)
        grid=exact_grid_record(vs)
        claimed=Fraction(block['least_time']);least_q=next(q for q in range(2,claimed.denominator+1)
                    if any(lonely(vs,m,q) for m in range(1,q)))
        witness=canonical_witness(vs)
        if witness:verify_witness(vs,witness)
        recorded={row[:4] for row in block['rows']}
        audits.append({'speeds':vs,'open':is_open(vs),'invalid_rows':invalid,
            'max_gap_matches':grid['maximum_loneliness']==block['max_gap'],
            'least_denominator_matches':least_q==claimed.denominator,
            'claimed_least_time_is_witness':lonely(vs,claimed.numerator,claimed.denominator),
            'row_count':len(recorded),'missing_all_multiplier_rows':len(actual-recorded),
            'missing_unit_multiplier_rows':len(unit-recorded),'oriented_label_mismatches':oriented_mismatches,
            'original_targets_unit_witness':witness})
    boxes=[]
    for n,bound in ((4,24),(5,22),(6,21),(7,20)):
        tested=opened=primitive=0;misses=[];folded_misses=[];nonunit_rescues=[]
        for vs in combinations(range(1,bound+1),n):
            tested+=1
            if not is_open(vs):continue
            opened+=1;primitive+=gcd(*vs)==1
            if canonical_witness(vs) is None:
                misses.append(list(vs))
                if canonical_witness(vs,unit=False):nonunit_rescues.append(list(vs))
            if canonical_witness(vs,'folded') is None:folded_misses.append(list(vs))
        boxes.append({'n':n,'max_speed':bound,'tuples_tested':tested,'open_sets':opened,
            'primitive_open_sets':primitive,'original_unit_failures':misses,
            'folded_unit_failures':folded_misses,'nonunit_rescues':nonunit_rescues})
        print(json.dumps({k:v for k,v in boxes[-1].items() if not isinstance(v,list)}),flush=True)
    base=(1,2,3,5,7,8,18);scaling=[]
    for g in range(1,31):
        vs=tuple(g*v for v in base)
        scaling.append({'scale':g,'original':canonical_witness(vs),
                        'folded':canonical_witness(vs,'folded'),
                        'without_unit':canonical_witness(vs,unit=False)})
    result={'schema':'swc-canonical-residual-audit-v1','source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
            'source_count':len(blocks),'audits':audits,'boxes':boxes,'scaling_base':list(base),
            'scaling':scaling,'historical_reproduction':historical_reproduction(blocks),
            'scope':'finite_audit_and_counterexample_search'}
    dest=Path(__file__).parent/'evidence/swc-canonical-residual-audit.json'
    dest.write_text(json.dumps(result,indent=2)+'\n')
    obstructions={'schema':'swc-canonical-obstructions-v1','obstructions':[
        inspect([44,60,104,205]),inspect([60,95,110,184]),inspect([31,240,450,540,930])],
        'interpretation':'The universal canonical restrictions fail; no counterexample to Lonely Runner is asserted.'}
    (dest.parent/'swc-canonical-obstructions.json').write_text(json.dumps(obstructions,indent=2)+'\n')
    print(json.dumps({'seconds':round(time.monotonic()-start,3),'invalid_rows':sum(len(x['invalid_rows']) for x in audits),
        'bad_maxima':sum(not x['max_gap_matches'] for x in audits),
        'bad_least_denominators':sum(not x['least_denominator_matches'] for x in audits),
        'residuals_without_canonical_witness':sum(x['original_targets_unit_witness'] is None for x in audits),
        'scaling_failures':[x['scale'] for x in scaling if x['original'] is None]}),flush=True)


if __name__=='__main__':main()
