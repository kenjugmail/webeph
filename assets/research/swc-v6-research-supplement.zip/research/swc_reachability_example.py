"""Small cyclic example with both success and failure terminals; 33 states."""
from fractions import Fraction
from pathlib import Path
import argparse
import copy
import json
from verify_swc_reachability import verify


def make_certificate():
    states=[]
    for i in range(33):
        terminal=i in (0,32)
        s=dict(id=str(i),kind='success' if i==0 else 'failure' if i==32 else 'search',
               success_potential=str(Fraction(32-i,32)),time_potential=str(i*(32-i)),
               transitions=[dict(to=str(i),probability='1')] if terminal else
               [dict(to=str(i-1),probability='1/2'),dict(to=str(i+1),probability='1/2')])
        if i==0:s['witness']=[22,110,4015]
        states.append(s)
    return dict(schema='swc-reachability-v1',target_n=73,start='3',horizon=192,
                drift='1',claimed_lower_bound='29/64',states=states)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path)
    args=parser.parse_args();c=make_certificate();verified=verify(c)
    counts=[0]*33;counts[3]=1
    for _ in range(192):
        new=[0]*33
        for i,v in enumerate(counts):
            if i in (0,32):new[i]+=2*v
            else:new[i-1]+=v;new[i+1]+=v
        counts=new
    probability=Fraction(counts[0],2**192)
    if probability<Fraction(29,64):raise AssertionError('exact path calculation violated certificate')
    mutations=[]
    bad=copy.deepcopy(c);bad['states'][0]['witness']=[1,1,1];mutations.append(bad)
    bad=copy.deepcopy(c);bad['states'][3]['success_potential']='1';mutations.append(bad)
    bad=copy.deepcopy(c);bad['states'][3]['transitions'][0]['probability']='-1/2';mutations.append(bad)
    bad=copy.deepcopy(c);bad['states'][3]['transitions'][0]['probability']='1';mutations.append(bad)
    bad=copy.deepcopy(c);bad['states'][3]['transitions']=[dict(to='3',probability='1')];mutations.append(bad)
    bad=copy.deepcopy(c);bad['states'][32]['success_potential']='1';mutations.append(bad)
    bad=copy.deepcopy(c);bad['claimed_lower_bound']='1';mutations.append(bad)
    for bad in mutations:
        try:verify(bad)
        except ValueError:pass
        else:raise AssertionError('invalid certificate accepted')
    if args.out:args.out.write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(**verified,actual_probability=str(probability),
                         actual_percentage=100*float(probability),mutations_rejected=len(mutations)),indent=2))


if __name__=='__main__':main()
