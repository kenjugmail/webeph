"""Compose exact residue-balanced probability with decreasing-rank recursion.

Returns exact success mass, possibly zero. Does not claim universal positivity.
The direct proposal includes rejection outcomes and is normalized before any
test of whether a seed is a witness.
"""
import argparse
from collections import Counter, defaultdict
from fractions import Fraction
from functools import lru_cache
import json
from pathlib import Path
from swc_recursive_anchor import divisors
from swc_residue_mass import factors


def square_divisors(x):
    values=[1]
    for r,e in factors(x):
        values=[v*r**j for v in values for j in range(2*e+1)]
    return sorted(values)


@lru_cache(None)
def direct(n,x):
    h=4*x-n
    assert n>=2 and x>=1 and h>0
    ds=square_divisors(x)
    multiplicity=Counter(d%h for d in ds)
    s=len(multiplicity)
    outcomes=[]
    for d in ds:
        weight=Fraction(1,s*multiplicity[d%h])
        other=x*x//d
        witness=None
        if (x+d)%h==0 and (x+other)%h==0:
            b,e=(x+d)//h,(x+other)//h
            assert 4*x*(n*b)*(n*e)==n*(x*n*b+x*n*e+n*b*n*e)
            witness=(b,e)
        outcomes.append((witness,weight))
    assert sum(w for _,w in outcomes)==1
    return tuple(outcomes)


def parents(n,x):
    h=4*x-n
    return [(L,4*(x//L)-h,x//L) for L in divisors(x)[1:]
            if 4*(x//L)-h>=2]


@lru_cache(None)
def mass(n,x):
    local=sum((w for v,w in direct(n,x) if v is not None),Fraction())
    branches=parents(n,x)
    if not branches:
        return local
    for _,q,y in branches:
        assert y<x and 2*q<n
    value=local/2+sum((mass(q,y) for _,q,y in branches),Fraction())/(2*len(branches))
    assert 0<=value<=1
    return value


@lru_cache(None)
def expand_outcomes(n,x):
    """Separate full-distribution check, including collisions and rejection."""
    branches=parents(n,x)
    local_weight=Fraction(1,2) if branches else Fraction(1)
    out=defaultdict(Fraction)
    for witness,weight in direct(n,x):
        out[witness]+=local_weight*weight
    for scale,q,y in branches:
        for witness,weight in expand_outcomes(q,y):
            mapped=None if witness is None else (scale*witness[0],scale*witness[1])
            out[mapped]+=weight/(2*len(branches))
    assert sum(out.values())==1
    for witness in out:
        if witness is not None:
            b,e=witness
            assert 4*x*(n*b)*(n*e)==n*(x*n*b+x*n*e+n*b*n*e)
    return tuple(out.items())


def record(n,x):
    local=sum((w for v,w in direct(n,x) if v is not None),Fraction())
    return dict(n=n,x=x,rank=x,direct_mass=str(local),combined_mass=str(mass(n,x)),
                branches=[dict(scale=L,n=q,x=y,mass=str(mass(q,y)))
                          for L,q,y in parents(n,x)])


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',type=Path)
    args=parser.parse_args()
    checked=0
    for n in range(5,100,4):
        for x in range(n//4+1,3*n//4+1):
            distribution=expand_outcomes(n,x)
            accepted=sum((w for v,w in distribution if v is not None),Fraction())
            assert mass(n,x)==accepted
            direct_positive=any(v is not None for v,_ in direct(n,x))
            assert (accepted>0)==direct_positive
            checked+=1
    roots=[(73,19),(73,20),(73,25),(241,63),(1249,315),
           (118801,29715),(8803369,2200869)]
    results=[record(n,x) for n,x in roots]
    seen=set()
    def visit(n,x):
        if (n,x) in seen:return
        seen.add((n,x))
        for _,q,y in parents(n,x):visit(q,y)
    for n,x in roots:visit(n,x)
    output=dict(status='exact_combined_masses_universal_positivity_open',
                expanded_distribution_checks=checked,roots=results,
                nodes=[record(n,x) for n,x in sorted(seen,key=lambda pair:pair[1])])
    if args.out:
        args.out.write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(checks=checked,roots=results),indent=2))


if __name__=='__main__':
    main()
