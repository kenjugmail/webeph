"""Exact SWC residue-mass experiments; no universal coverage assertion.

Compute a distribution on signed prime-factor exponents by convolution, then
test a target-independent collision bound. All acceptance arithmetic is exact.
"""
from collections import Counter
from fractions import Fraction
from math import gcd, isqrt, prod
from pathlib import Path
import argparse
import json


def factors(n):
    result = []
    r = 2
    while r * r <= n:
        e = 0
        while n % r == 0:
            e += 1
            n //= r
        if e:
            result.append((r, e))
        r = 3 if r == 2 else r + 2
    if n > 1:
        result.append((n, 1))
    return result


def distribution(x, h):
    assert x > 0 and h > 1 and gcd(x, h) == 1
    counts = Counter({1: 1})
    fs = factors(x)
    for r, e in fs:
        local = Counter(pow(r, j, h) for j in range(-e, e + 1))
        updated = Counter()
        for a, ca in counts.items():
            for b, cb in local.items():
                updated[a * b % h] += ca * cb
        counts = updated
    assert sum(counts.values()) == prod(2 * e + 1 for _, e in fs)
    return counts


def measure(x, h, targets, condition_on_generated_group=False):
    counts = distribution(x, h)
    units = {r for r in range(h) if gcd(r, h) == 1}
    if condition_on_generated_group:
        generated, frontier = {1}, [1]
        generators = [r % h for r, _ in factors(x)]
        while frontier:
            a = frontier.pop()
            for b in generators:
                r = a*b % h
                if r not in generated:
                    generated.add(r)
                    frontier.append(r)
        units = generated
    targets = set(targets) & units
    n = sum(counts.values())
    m, k = len(units), len(targets)
    collision = sum(c * c for c in counts.values())
    gap = n*n - (m-k)*collision
    lower = max(Fraction(0), Fraction(gap, 2*n*n)) if k else Fraction(0)
    exact = Fraction(sum(counts[t] for t in targets), n)
    assert lower <= exact
    return dict(anchor=x, shift=h, target_count=k,
                exponent_vectors=n, support_size=len(counts), group_size=m,
                collision_numerator=collision, gap=gap,
                exact_mass=str(exact), certified_lower_bound=str(lower))


def self_check():
    checked = 0
    for h in range(3, 48, 4):
        for x in range(1, 151):
            if gcd(x, h) != 1:
                continue
            direct = Counter()
            for d in range(1, isqrt(x*x) + 1):
                if x*x % d == 0:
                    direct[d * pow(x, -1, h) % h] += 1
                    other = x*x // d
                    if other != d:
                        direct[other * pow(x, -1, h) % h] += 1
            assert direct == distribution(x, h)
            measure(x, h, {-1 % h})
            measure(x, h, {-1 % h, -4 % h})
            measure(x, h, {-1 % h, -4 % h}, True)
            checked += 1
    return checked


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    checked = self_check()
    records = []
    for p in [73, 409, 118801, 496609, 532249, 806521, 2458369, 8803369, 22605361]:
        first_exact = first_bound = None
        for h in range(3, min(p, 180), 4):
            c = (p+h)//4
            record = measure(c, h, {-1 % h, -pow(p, -1, h) % h})
            if first_exact is None and Fraction(record['exact_mass']) > 0:
                first_exact = record
            if first_bound is None and Fraction(record['certified_lower_bound']) > 0:
                first_bound = record
        records.append(dict(p=p, first_exact=first_exact, first_collision_certificate=first_bound))
    adaptive = []
    for p in [806521,2458369,8803369,22605361]:
        hit = None
        for h in range(3,4096,4):
            r = measure((p+h)//4, h, {-1 % h, -pow(p,-1,h) % h, -p % h}, True)
            if Fraction(r['certified_lower_bound']) > 0:
                hit = r
                break
        adaptive.append(dict(p=p, max_shift=4095, subgroup_and_inverse_target=True,
                             first_certificate=hit))
    payload = json.dumps(dict(status='finite_experiment_universal_bound_open',
                              exact_crosschecks=checked, records=records,
                              adaptive=adaptive), indent=2)
    if args.out:
        args.out.write_text(payload+'\n', encoding='utf-8')
    print(payload)


if __name__ == '__main__':
    main()
