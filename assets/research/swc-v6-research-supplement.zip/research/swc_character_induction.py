"""Jacobi-conditioned SWC mass propagation with decreasing anchor rank.

Reference: uniform signed exponents and the same recursive branch weights.
The theorem bounds improvement conditional on positive reference mass.
"""
from fractions import Fraction
from functools import lru_cache
from math import gcd
from pathlib import Path
import argparse
import json
from swc_residue_mass import factors, distribution
from swc_recursive_anchor import divisors


def jacobi(a,n):
    if n<=1 or n%2==0:raise ValueError('positive odd modulus >1 required')
    a%=n;sign=1
    while a:
        while a%2==0:
            a//=2
            if n%8 in (3,5):sign=-sign
        a,n=n,a
        if a%4==n%4==3:sign=-sign
        a%=n
    return sign if n==1 else 0


def conditioning_mass(x,h):
    eta=Fraction(1)
    for r,e in factors(x):
        if jacobi(r,h)==-1:eta*=Fraction((-1)**e,2*e+1)
    return (1-eta)/2


@lru_cache(None)
def calculate(n,x):
    h=4*x-n
    if n<2 or h%4!=3 or h<3 or gcd(x,h)!=1:raise ValueError('outside theorem domain')
    counts=distribution(x,h);N=sum(counts.values())
    direct=Fraction(counts[-1%h],N)
    Z=conditioning_mass(x,h)
    if Z==0:
        if direct:raise ValueError('accepted seed outside necessary character class')
        conditioned=Fraction(0)
    else:
        if not Fraction(2,5)<=Z<=Fraction(2,3):raise ValueError('character-mass bound failed')
        conditioned=direct/Z
    parents=[]
    for L in divisors(x)[1:]:
        y=x//L;q=4*y-h
        if q>=2:
            assert y<x and 2*q<n
            parents.append(calculate(q,y))
    if parents:
        raw=direct/2+sum((Fraction(v['reference_mass']) for v in parents),Fraction())/(2*len(parents))
        improved=conditioned/2+sum((Fraction(v['conditioned_mass']) for v in parents),Fraction())/(2*len(parents))
    else:raw,improved=direct,conditioned
    assert 0<=raw<=1 and 0<=improved<=1
    assert Fraction(3,2)*raw<=improved<=Fraction(5,2)*raw
    return dict(n=n,x=x,h=h,direct_reference=str(direct),negative_character_mass=str(Z),
                direct_conditioned=str(conditioned),reference_mass=str(raw),
                conditioned_mass=str(improved),ratio=str(improved/raw) if raw else None,
                parents=[[v['n'],v['x']] for v in parents])


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path)
    args=parser.parse_args()
    roots=[(73,19),(73,20),(73,25),(241,63),(1249,315),(118801,29715),
           (2458369,614606),(8803369,2200869),(22605361,5651354)]
    records=[calculate(*s) for s in roots]
    nodes={}
    def visit(n,x):
        if (n,x) in nodes:return
        v=calculate(n,x);nodes[(n,x)]=v
        for q,y in v['parents']:visit(q,y)
    for s in roots:visit(*s)
    result=dict(status='conditional_gain_theorem_not_universal_existence',
                reference='uniform signed-exponent direct branch with equal direct/recursive mixture',
                roots=records,nodes=sorted(nodes.values(),key=lambda v:v['x']))
    if args.out:args.out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps([{k:v[k] for k in ['n','x','reference_mass','conditioned_mass','ratio']} for v in records],indent=2))


if __name__=='__main__':main()
