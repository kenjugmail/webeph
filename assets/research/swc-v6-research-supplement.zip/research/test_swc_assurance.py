from copy import deepcopy
from fractions import Fraction
from itertools import product
from math import comb
import unittest
from swc_assurance import (receipt,verify_receipt,digest,exact_witness,domain_instances,
    verify_finite_domain,binomial_cdf_exact,upper_failure_bound,reliability_report,
    zero_failure_sample_size)


def example_plan(n=5):
    return {'schema':'swc-reliability-plan-v1','sampling_design':'fresh_iid_fixed_horizon',
            'selection':'all_draws_including_failures','sample_size':n,'alpha':'1/20',
            'target_failure_rate':'1/2','failure_definition':'anything_without_a_verified_receipt',
            'distribution':'Synthetic unit-test distribution; not experimental evidence.',
            'relation':'lonely_runner','configuration_sha256':'a'*64,'provenance':'synthetic test fixture'}


def events_for(plan,statuses):
    rows=[];previous=digest(plan)
    for i,status in enumerate(statuses):
        row={'trial_id':i,'instance':[1,2],'status':status,'previous_sha256':previous,
             'plan_sha256':digest(plan),'configuration_sha256':plan['configuration_sha256']}
        if status=='verified':row['receipt']=receipt('lonely_runner',[1,2],[1,3])
        row['sha256']=digest(row);rows.append(row);previous=row['sha256']
    return rows


class AssuranceTests(unittest.TestCase):
    def test_exact_relations_and_rejection(self):
        self.assertEqual(verify_receipt(receipt('lonely_runner',[1,2],[1,3]))['status'],'verified')
        self.assertTrue(exact_witness('erdos_straus',5,[2,4,20]))
        with self.assertRaises(ValueError):receipt('lonely_runner',[1,2],[0,3])
        with self.assertRaises(ValueError):receipt('erdos_straus',5,[2,4,21])
        with self.assertRaises(ValueError):receipt('erdos_straus',5,[2.0,4,20])

    def test_receipt_scope_and_corruption(self):
        record=receipt('lonely_runner',[1,2],[1,3])
        record['body']['scope']='all_real_world_inputs';record['sha256']=digest(record['body'])
        with self.assertRaises(ValueError):verify_receipt(record)
        record=receipt('lonely_runner',[1,2],[1,3]);record['body']['witness']=[0,3]
        with self.assertRaises(ValueError):verify_receipt(record)

    def test_finite_coverage_is_reenumerated(self):
        domain={'kind':'bounded_speed_combinations','relation':'lonely_runner','speed_count':2,
                'min_speed':1,'max_speed':3,'primitive_only':False,'open_only':False}
        rows=[{'instance':[1,2],'witness':[1,3]},
              {'instance':[1,3],'witness':[1,2]},
              {'instance':[2,3],'witness':[1,5]}]
        # At 1/5 the last tuple's minimum is 2/5, satisfying 1/3.
        bundle={'schema':'swc-finite-coverage-v1','domain':domain,'domain_sha256':digest(domain),
                'rows':rows,'rows_sha256':digest(rows)}
        self.assertEqual(verify_finite_domain(bundle)['instances_verified'],3)
        for newrows in (rows[:-1],rows+[rows[0]],[rows[0],rows[0],rows[2]]):
            forged=deepcopy(bundle);forged['rows']=newrows;forged['rows_sha256']=digest(newrows)
            with self.assertRaises(ValueError):verify_finite_domain(forged)
        forged=deepcopy(bundle);forged['domain']['max_speed']=4
        forged['domain_sha256']=digest(forged['domain'])
        with self.assertRaises(ValueError):verify_finite_domain(forged)

    def test_binomial_matches_direct_expansion(self):
        for n in range(1,18):
            for x in range(n+1):
                for p in (Fraction(0),Fraction(1,7),Fraction(1,2),Fraction(5,6),Fraction(1)):
                    expected=sum((comb(n,j)*p**j*(1-p)**(n-j) for j in range(x+1)),Fraction())
                    self.assertEqual(binomial_cdf_exact(n,x,p),expected)

    def test_planned_sample_size_boundary(self):
        p=Fraction(1,1000);alpha=Fraction(1,100)
        self.assertEqual(zero_failure_sample_size(p,alpha),4603)
        self.assertGreater((1-p)**4602,alpha)
        self.assertLessEqual((1-p)**4603,alpha)
        self.assertIsNone(zero_failure_sample_size(Fraction(1,10**9),alpha))

    def test_confidence_coverage_enumerating_binomial_outcomes(self):
        # Full finite distribution of possible data: P[reported U<p]<=alpha.
        alpha=Fraction(1,10)
        for n in (1,3,10,25):
            bounds=[upper_failure_bound(n,x,alpha,grid_bits=8) for x in range(n+1)]
            self.assertEqual(bounds[-1],1)
            for p in (Fraction(1,20),Fraction(1,3),Fraction(1,2),Fraction(9,10)):
                error=sum((comb(n,x)*p**x*(1-p)**(n-x) for x,u in enumerate(bounds) if u<p),Fraction())
                self.assertLessEqual(error,alpha)

    def test_failures_are_not_filtered(self):
        plan=example_plan(5)
        events=events_for(plan,['verified','unresolved','invalid','error','timeout'])
        result=reliability_report(plan,events)
        self.assertEqual(result['trials'],5);self.assertEqual(result['failures'],4)
        self.assertFalse(result['target_demonstrated'])
        with self.assertRaises(ValueError):reliability_report(plan,events[:1])

    def test_all_failed_bound(self):
        plan=example_plan()
        result=reliability_report(plan,events_for(plan,['unresolved']*5))
        self.assertEqual(result['failure_rate_upper_bound'],'1')
        self.assertEqual(result['success_rate_lower_bound'],'0')

    def test_reliability_success_has_exact_bound(self):
        plan=example_plan()
        result=reliability_report(plan,events_for(plan,['verified']*5))
        self.assertTrue(result['target_demonstrated'])
        self.assertLessEqual(Fraction(result['failure_rate_upper_bound']),Fraction(1,2))
        self.assertFalse(result['physical_deployment_validated'])

    def test_chosen_residuals_and_adaptive_stopping_rejected(self):
        for design in ('curated_residuals','adaptive_stopping','exhaustive_finite_box'):
            plan=example_plan();plan['sampling_design']=design
            with self.assertRaises(ValueError):reliability_report(plan,events_for(plan,['verified']*5))
        plan=example_plan();plan['selection']='successful_trials_only'
        with self.assertRaises(ValueError):reliability_report(plan,events_for(plan,['verified']*5))

    def test_model_swap_duplicate_missing_and_mismatched_receipt(self):
        plan=example_plan();events=events_for(plan,['verified']*5)
        for field,value in (('configuration_sha256','b'*64),('trial_id',1),('previous_sha256','c'*64)):
            forged=deepcopy(events);forged[0][field]=value
            forged[0]['sha256']=digest({k:v for k,v in forged[0].items() if k!='sha256'})
            with self.assertRaises(ValueError):reliability_report(plan,forged)
        forged=deepcopy(events);forged[0]['receipt']=receipt('lonely_runner',[1,3],[1,2])
        forged[0]['sha256']=digest({k:v for k,v in forged[0].items() if k!='sha256'})
        with self.assertRaises(ValueError):reliability_report(plan,forged)

    def test_resource_bounds(self):
        with self.assertRaises(ValueError):binomial_cdf_exact(10000,5000,Fraction(1,2))
        with self.assertRaises(ValueError):binomial_cdf_exact(10,0,0.5)
        with self.assertRaises(ValueError):list(domain_instances({'kind':'bounded_speed_combinations',
            'relation':'lonely_runner','speed_count':7,'min_speed':1,'max_speed':10000,
            'primitive_only':False,'open_only':False}))


if __name__=='__main__':unittest.main()
