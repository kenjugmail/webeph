# Final literature pass and publication checkpoint

Date: 2026-09-05. No valid universal Erdős–Straus proof was obtained.
The pass used primary papers and lightweight symbolic/arithmetic checks;
it did not run another large-prime sweep.

The exact parametrizations in Elsholtz–Tao (arXiv:1107.1010),
Bello-Hernández–Benito–Fernández (arXiv:2606.10922), and Dahan
(arXiv:2608.24035) support the certificate interface. Their existence and
counting statements do not establish positive witness mass at every prime.
Dahan explicitly retains the conjecture as open and gives infinite
fixed-shift failure sets.

Elsholtz–Planitzer (arXiv:1805.02945) gives infinitely many richly represented
primes in each reduced progression, not all primes. Bright–Loughran
(arXiv:1908.02526) removes a particular Brauer–Manin obstruction without
establishing the required positive integral points. Kötzing–Krejca
(arXiv:1805.09415) supplies drift theorems conditional on valid local drift
inequalities; it does not construct those inequalities for this equation.

The final additional lead, Pomerance–Weingartner (arXiv:2511.16817v2,
January 2026), studies exceptions for generalized numerators and makes
dependence in exceptional-set bounds explicit. It neither disproves nor
proves the numerator-four Erdős–Straus conjecture. Its results cannot be
substituted for the missing pointwise positivity theorem.

Claimed closures were not adopted. Bradford's arXiv:2602.11774 leaves the
final covering assertion without a proof. The inspected Dyachenko version
arXiv:2511.07465 relies on a false rectangle-hitting lemma: the lattice
u+v=0 mod2 misses the sole integer point in [0,1) x [1,2), despite the
stated diagonal-period condition. No claim is made that future repairs
are impossible.

## Final retained results

The v5 research revision retains the corrected divisor hypotheses, exact
box equivalence, endpoint obstruction and derived complete shift bound
c<=p-6 for prime p=1 mod4, p>5; the conditional 1.5x–2.5x character-sampling
gain; sound recursive and failed-path reachability rules; symbolic polynomial
family checking; twelve-family case composition; and the exploratory
eight-prime proposal comparison. Detailed proofs and limits are in the
corresponding research notes. No priority claim is made for elementary
identities or their reformulations.

The original 82,887-prime finite result remains the manuscript's reported
experiment. The earlier 100-million-range exploration was not rerun or
promoted to a newly audited canonical result in this release. The original
v3 archive's six stale manifest entries and clean source recompilation remain
outstanding. Independent review and accepted-journal publication remain gated.

The website and v5 PDF must state that universal existence is still open in
this work. More induction layers, distributions, tests, or absence of known
obstructions do not replace a proof of that missing premise.

## Primary sources

- https://arxiv.org/abs/1107.1010
- https://arxiv.org/abs/2606.10922
- https://arxiv.org/abs/2608.24035
- https://arxiv.org/abs/1805.02945
- https://arxiv.org/abs/1908.02526
- https://arxiv.org/abs/1805.09415
- https://arxiv.org/abs/2511.16817
- https://arxiv.org/abs/2602.11774
- https://arxiv.org/abs/2511.07465
