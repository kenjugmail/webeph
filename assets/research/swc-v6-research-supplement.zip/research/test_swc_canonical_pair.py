from fractions import Fraction
from math import gcd
import unittest
from swc_canonical_pair import (targets,canonical_witness,verify_witness,is_open,complete_witness_search)
from swc_lonely_runner import congruence_roots,lonely
from verify_swc_canonical_obstruction import inspect


class CanonicalTests(unittest.TestCase):
    def test_unit_solvability_lemma(self):
        for q in range(2,50):
            for v in range(1,q):
                g=gcd(v,q)
                for c in range(q):
                    predicted=c%g==0 and gcd(c//g,q//g)==1
                    actual=any(gcd(m,q)==1 for m in congruence_roots(v,q,c))
                    self.assertEqual(predicted,actual)

    def test_original_and_folded_are_different_rules(self):
        # For nonintegral q/N the folded note adds ceil(q/N)+1.
        q,N=117,8
        self.assertNotIn(16,targets(q,N,'original'))
        self.assertIn(16,targets(q,N,'folded'))

    def test_supplied_witness(self):
        speeds=(1,2,4,6,7,8,10)
        record={'pair':[4,10],'q':14,'m':11,'oriented_target':2,
                'distance':'1/7','time':'11/14'}
        self.assertTrue(verify_witness(speeds,record))

    def test_primitive_counterexample_even_without_unit_requirement(self):
        v=(44,60,104,205)
        self.assertEqual(gcd(*v),1);self.assertTrue(is_open(v))
        for rule in ('original','folded'):
            for unit in (True,False):self.assertIsNone(canonical_witness(v,rule,unit))
        independent=inspect(list(v))
        self.assertTrue(independent['original_disproved'])
        self.assertTrue(independent['folded_disproved'])
        self.assertTrue(lonely(v,9,148))
        self.assertEqual(independent['maximum_loneliness'],'12/37')

    def test_unit_only_obstruction(self):
        v=(60,95,110,184)
        self.assertIsNone(canonical_witness(v))
        self.assertIsNotNone(canonical_witness(v,unit=False))

    def test_safe_complete_fallback(self):
        v=(44,60,104,205)
        record=complete_witness_search(v)
        self.assertEqual(record['route'],'complete_pair_grid')
        self.assertEqual(record['time'],'9/148')
        self.assertEqual(record['scope'],'single_speed_tuple')

    def test_scaling_transport(self):
        base=(1,2,3,5,7,8,18)
        for g in (9,16,120):
            v=tuple(g*x for x in base);record=complete_witness_search(v)
            t=Fraction(record['time'])
            self.assertTrue(lonely(v,t.numerator,t.denominator))
            self.assertEqual(record['normalization_gcd'],g)

    def test_small_modulus(self):
        record=complete_witness_search((1,3,5))
        self.assertEqual(record['route'],'small_modulus')
        self.assertEqual(record['time'],'1/2')


if __name__=='__main__':unittest.main()
