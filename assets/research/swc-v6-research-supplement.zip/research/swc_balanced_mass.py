"""Exact change-of-measure certificates for residue-balanced SWC proposals."""
import argparse
from fractions import Fraction
import json
from math import gcd
from pathlib import Path
from swc_residue_mass import distribution
from audit_collision_universality import direct_support


def certify(p, h):
    c = (p+h)//4
    counts = distribution(c, h)
    assert set(counts) == direct_support(c, h)
    s = len(counts)
    m = sum(gcd(r,h)==1 for r in range(h))
    targets = {-1 % h, -pow(p,-1,h) % h, -p % h}
    # Every seed yielding residue r receives weight 1/(s*n_r).
    assert sum(n*Fraction(1,s*n) for n in counts.values()) == 1
    lower = max(Fraction(0), Fraction(s-m+len(targets),s))
    actual = Fraction(len(targets & set(counts)),s)
    assert 0 < lower <= actual
    # Independently reconstruct a conventional exact witness.
    witness = None
    for d in range(1,c+1):
        if c*c % d:
            continue
        for divisor in {d,c*c//d}:
            if (divisor+c) % h == 0:
                e = p*divisor
            elif (4*divisor+1) % h == 0:
                e = p*p*divisor
            else:
                continue
            M=p*c
            other=M*M//e
            assert M*M % e == 0 and (M+e)%h == (M+other)%h == 0
            x,y,z=c,(M+e)//h,(M+other)//h
            assert min(x,y,z)>0 and 4*x*y*z==p*(x*y+x*z+y*z)
            witness=[x,y,z]
            break
        if witness:
            break
    assert witness
    return dict(p=p,shift=h,anchor=c,support_size=s,group_size=m,
                targets=len(targets),lower_bound=str(lower),exact_mass=str(actual),
                witness=witness)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',type=Path)
    args=parser.parse_args()
    result=dict(status='three_exact_instances_universal_support_theorem_open',
                records=[certify(p,h) for p,h in [(806521,95),(2458369,55),(8803369,151)]])
    payload=json.dumps(result,indent=2)
    if args.out:
        args.out.write_text(payload+'\n',encoding='utf-8')
    print(payload)


if __name__=='__main__':
    main()
