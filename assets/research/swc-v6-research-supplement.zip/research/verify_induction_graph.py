#!/usr/bin/env python3
"""Independent fail-closed verifier for the SWC induction proof graph."""

import argparse
import json
from collections import defaultdict, deque


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("graph")
    args = parser.parse_args()
    graph = json.load(open(args.graph, encoding="utf-8"))
    nodes = {node["id"]: node for node in graph["nodes"]}
    if len(nodes) != len(graph["nodes"]):
        raise SystemExit("duplicate node identifier")
    for node in nodes.values():
        for field in ["type", "status", "claim", "source", "confidence"]:
            if not node.get(field):
                raise SystemExit(f"{node['id']} lacks {field}")

    adjacency = defaultdict(list)
    indegree = {identifier: 0 for identifier in nodes}
    for edge in graph["edges"]:
        if edge["from"] not in nodes or edge["to"] not in nodes:
            raise SystemExit(f"edge has missing endpoint: {edge}")
        adjacency[edge["from"]].append(edge["to"])
        indegree[edge["to"]] += 1
    queue = deque(identifier for identifier, degree in indegree.items() if degree == 0)
    visited = 0
    while queue:
        current = queue.popleft()
        visited += 1
        for target in adjacency[current]:
            indegree[target] -= 1
            if indegree[target] == 0:
                queue.append(target)
    if visited != len(nodes):
        raise SystemExit("proof-obligation graph contains a cycle")

    obligation = nodes["O-PRIME-DESCENT"]
    interior_obligation = nodes["O-INTERIOR-TYPEII-HIT"]
    transformer = nodes["T-TYPEII-SCALING"]
    goal = nodes["G-UNIVERSAL"]
    if transformer["status"] != "proved":
        raise SystemExit("the Type-II scaling transformer must be checked separately")
    if interior_obligation["status"] != "open":
        raise SystemExit("finite parent coverage cannot close the universal interior-hit theorem")
    if obligation["status"] != "open":
        raise SystemExit("prime descent may close only with a separately verified total theorem")
    if goal["status"] != "blocked":
        raise SystemExit("universal goal must remain blocked while prime descent is open")
    if graph["inductionAudit"]["descentColumns"]:
        raise SystemExit("unexpected descent data requires a new provenance audit")
    if graph["inductionAudit"]["universalClaimStatus"] != "blocked":
        raise SystemExit("universal claim escaped the fail-closed gate")

    prohibited = {"finite_empirical", "unproved"}
    for node in nodes.values():
        if node["type"] == "Goal" and node["status"] == "proved" and node["confidence"] in prohibited:
            raise SystemExit("an empirical or unproved node was promoted to theorem")
    print(f"proof graph verifier: PASS · {len(nodes)} nodes · {len(graph['edges'])} edges · universal goal BLOCKED")


if __name__ == "__main__":
    main()
