"""Independent arithmetic verifier; imports no research producer modules."""
from fractions import Fraction
from math import gcd,isqrt,prod
from pathlib import Path
import argparse
import json
import copy


def factor(n):
    out=[];p=2
    while p*p<=n:
        e=0
        while n%p==0:n//=p;e+=1
        if e:out.append((p,e))
        p+=1
    if n>1:out.append((n,1))
    return out


def char(a,modulus):
    value=1
    for p,e in factor(modulus):
        if a%p==0:return 0
        legendre=pow(a,(p-1)//2,p)
        value*=(-1 if legendre==p-1 else 1)**e
    return value


def all_divisors(fs):
    ds=[1]
    for p,e in fs:
        ds=[d*p**j for d in ds for j in range(e+1)]
    return ds


def verify(data):
    assert data['status']=='conditional_gain_theorem_not_universal_existence'
    table={(v['n'],v['x']):v for v in data['nodes']}
    assert len(table)==len(data['nodes'])
    for key,v in table.items():
        n,x=key;h=4*x-n
        assert n>=2 and h>=3 and h%4==3 and v['h']==h and gcd(x,h)==1
        ds=all_divisors([(p,2*e) for p,e in factor(x)])
        negative=accepted=0
        for d in ds:
            residue=d*pow(x,-1,h)%h
            negative+=char(residue,h)==-1
            complement=x*x//d
            if (x+d)%h==0 and (x+complement)%h==0:
                accepted+=1
                assert char(residue,h)==-1
                b,e=(x+d)//h,(x+complement)//h
                assert min(b,e)>0 and 4*x*(n*b)*(n*e)==n*(x*n*b+x*n*e+n*b*n*e)
        Z=Fraction(negative,len(ds));D=Fraction(accepted,len(ds))
        C=D/Z if Z else Fraction(0)
        assert Fraction(v['negative_character_mass'])==Z
        assert Fraction(v['direct_reference'])==D and Fraction(v['direct_conditioned'])==C
        expected_parents={(4*(x//L)-h,x//L) for L in all_divisors(factor(x)) if L>=2 and 4*(x//L)-h>=2}
        assert set(map(tuple,v['parents']))==expected_parents and len(v['parents'])==len(expected_parents)
        raw,improved=D,C
        if expected_parents:
            assert all(q<n and y<x and 2*q<n for q,y in expected_parents)
            raw=D/2+sum((Fraction(table[s]['reference_mass']) for s in expected_parents),Fraction())/(2*len(expected_parents))
            improved=C/2+sum((Fraction(table[s]['conditioned_mass']) for s in expected_parents),Fraction())/(2*len(expected_parents))
        assert Fraction(v['reference_mass'])==raw and Fraction(v['conditioned_mass'])==improved
        assert 0<=improved<=1 and Fraction(3,2)*raw<=improved<=Fraction(5,2)*raw
        assert v['ratio']==(str(improved/raw) if raw else None)
    for root in data['roots']:assert root==table[(root['n'],root['x'])]
    return len(table)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('certificate',type=Path)
    args=parser.parse_args();data=json.loads(args.certificate.read_text())
    count=verify(data)
    mutated=copy.deepcopy(data);mutated['nodes'][-1]['conditioned_mass']='1'
    try:verify(mutated)
    except AssertionError:pass
    else:raise AssertionError('forged mass accepted')
    print(f'PASS: {count} states independently checked; forged mass rejected. Universal existence not certified.')


if __name__=='__main__':main()
