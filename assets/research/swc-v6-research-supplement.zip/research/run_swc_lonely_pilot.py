"""Bounded, reproducible fresh pilot; does not reproduce the missing user dataset."""
from fractions import Fraction
from itertools import combinations
from math import gcd
from pathlib import Path
import hashlib
import json
import random
import time
from swc_lonely_runner import (canonical_times, lonely, exact_grid_record,
    pair_bonferroni, continuous_good_set, residue_family)
from verify_swc_lonely_runner import verify


def main():
    start=time.monotonic()
    rng=random.Random(20260905)
    corpora={
        'exhaustive_four_speeds_1_to_14':list(combinations(range(1,15),4)),
        'seeded_seven_speeds_1_to_160':[tuple(sorted(rng.sample(range(1,161),7))) for _ in range(1000)],
        'seeded_eleven_speeds_1_to_160':[tuple(sorted(rng.sample(range(1,161),11))) for _ in range(1000)],
        'seeded_thirteen_speeds_1_to_160':[tuple(sorted(rng.sample(range(1,161),13))) for _ in range(300)],
    }
    result={'schema':'swc-lonely-pilot-v1','original_user_dataset':'not located; percentages unverified',
            'seed':20260905,'canonical_rounding':'floor and ceil on reduced reachable grid; all gcd lifts',
            'scope':'finite independent pilot, not a universal result','corpora':{}}
    residuals=[]
    for name,corpus in corpora.items():
        counts={'tested':0,'half_turn_success':0,'denominators_2_3_4_success':0,
                'full_pair_grid_success':0,'first_order_positive':0,'third_order_positive':0,
                'interval_grid_agreements':0}
        for index,values in enumerate(corpus):
            if time.monotonic()-start>55:
                counts['stopped_at_wall_limit']=True;break
            half=canonical_times(values,(2,))
            canon=canonical_times(values)
            passes=lambda times:any(lonely(values,t.numerator,t.denominator) for t in times)
            half_ok=passes(half); canonical_ok=passes(canon)
            record=exact_grid_record(values)
            full_ok=Fraction(record['accepted_mass'])>0
            counts['tested']+=1
            counts['half_turn_success']+=half_ok
            counts['denominators_2_3_4_success']+=canonical_ok
            counts['full_pair_grid_success']+=full_ok
            # Evaluate two overlap certificates only on a bounded diagnostic subset.
            if index<40:
                bounds=[pair_bonferroni(values,i,j) for i,j in combinations(range(len(values)),2)]
                counts['first_order_positive']+=any(b['first_order_lower_count']>0 for b in bounds)
                counts['third_order_positive']+=any(b['third_order_lower_count']>0 for b in bounds)
                interval=continuous_good_set(values)
                if bool(interval['components'])!=full_ok:
                    raise AssertionError('interval/grid disagreement')
                counts['interval_grid_agreements']+=1
            if not canonical_ok:
                verify(record)
                t=Fraction(record['maximizing_time'])
                residuals.append({'corpus':name,'record':record,
                    'continuous_good_set':continuous_good_set(values),
                    'residue_family':residue_family(values,t.numerator,t.denominator)})
        counts['overlap_diagnostic_denominator']=min(40,counts['tested'])
        counts['corpus_sha256']=hashlib.sha256(json.dumps(corpus,separators=(',',':')).encode()).hexdigest()
        result['corpora'][name]=counts
    result['residuals']=residuals
    result['tight_examples']=[]
    for n in (2,3,7):
        values=tuple(range(1,n+1));record=exact_grid_record(values);verify(record)
        result['tight_examples'].append({'record':record,'continuous_good_set':continuous_good_set(values)})
    output=Path(__file__).parent/'evidence/swc-lonely-pilot.json'
    output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'corpora':result['corpora'],'residual_count':len(residuals),
                     'seconds':round(time.monotonic()-start,3),'output':str(output)},indent=2))


if __name__=='__main__':main()
