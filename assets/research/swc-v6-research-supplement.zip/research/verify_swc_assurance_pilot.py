"""Independent checker for generated assurance evidence. No producer imports.

It checks finite completeness, each emitted rational witness, full trial
inclusion, and the fixed-horizon binomial threshold. It cannot verify IID
provenance or measurements from hashes.
"""
from fractions import Fraction
from itertools import combinations
from math import comb,gcd
from pathlib import Path
import hashlib
import json
import sys


def check(ok,message):
    if not ok:raise ValueError(message)


def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def exact(instance,witness):
    check(type(instance) is list and 2<=len(instance)<=16,'speed tuple')
    check(all(type(v) is int and 1<=v<=10000 for v in instance),'integer speeds')
    check(instance==sorted(set(instance)),'distinct increasing speeds')
    check(type(witness) is list and len(witness)==2 and all(type(x) is int for x in witness),'time pair')
    a,b=witness;check(1<=b<=10**9 and 0<=a<b,'time range')
    t=Fraction(a,b)
    for v in instance:
        part=t*v;part-=part.__floor__()
        check(min(part,1-part)>=Fraction(1,len(instance)+1),'invalid mathematical witness')


def verify(directory):
    root=Path(directory)
    files=json.loads((root/'SHA256.json').read_text())
    for name,expected in files.items():
        check(Path(name).name==name,'unsafe path')
        check(hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,'file fingerprint')
    domain=json.loads((root/'domain.json').read_text())
    bundle=json.loads((root/'finite-coverage.json').read_text())
    check(bundle['schema']=='swc-finite-coverage-v1','bundle schema')
    check(domain==bundle['domain'] and digest(domain)==bundle['domain_sha256'],'domain mismatch')
    check(domain['kind']=='bounded_speed_combinations' and domain['relation']=='lonely_runner','domain kind')
    n,low,high=(domain[x] for x in ('speed_count','min_speed','max_speed'))
    check(all(type(x) is int for x in (n,low,high)) and 2<=n<=16 and 1<=low<=high<=10000,'domain bounds')
    check(high-low+1>=n and comb(high-low+1,n)<=200000,'enumeration budget')
    check(all(type(domain[x]) is bool for x in ('primitive_only','open_only')),'domain flags')
    index=0;rows=bundle['rows']
    for values in combinations(range(low,high+1),n):
        if domain['primitive_only'] and gcd(*values)>1:continue
        if domain['open_only'] and not all(any(v%d==0 for v in values) for d in range(2,n+2)):continue
        check(index<len(rows),'missing domain case')
        row=rows[index];check(row['instance']==list(values),'domain mismatch or duplicate')
        exact(row['instance'],row['witness']);index+=1
    check(index>0 and len(rows)==index,'extra or empty domain')
    check(digest(rows)==bundle['rows_sha256'],'row hash')
    plan=json.loads((root/'plan.json').read_text());report=json.loads((root/'reliability.json').read_text())
    check(plan['schema']=='swc-reliability-plan-v1' and plan['relation']=='lonely_runner','plan schema')
    check(plan['sampling_design']=='fresh_iid_fixed_horizon','fixed horizon required')
    check(plan['selection']=='all_draws_including_failures','selection mismatch')
    check(plan['failure_definition']=='anything_without_a_verified_receipt','failure definition')
    trials=plan['sample_size'];check(type(trials) is int and 1<=trials<=10000,'sample size')
    plan_hash=digest(plan);previous=plan_hash;failures=0;statuses={};trial_count=0
    for line in (root/'trials.jsonl').read_text().splitlines():
        event=json.loads(line);check(event['trial_id']==trial_count,'trial sequence')
        check(event['plan_sha256']==plan_hash,'plan binding')
        check(event['configuration_sha256']==plan['configuration_sha256'],'configuration binding')
        check(event['previous_sha256']==previous,'trial chain')
        body={k:v for k,v in event.items() if k!='sha256'}
        check(event['sha256']==digest(body),'trial hash');previous=event['sha256']
        values=event['instance']
        check(len(values)==7 and values==sorted(set(values)) and all(type(v) is int and 1<=v<=60 for v in values),
              'lab sampling support mismatch')
        status=event['status'];check(status in ('verified','unresolved','invalid','error','timeout'),'status')
        statuses[status]=statuses.get(status,0)+1
        if status=='verified':
            cert=event['receipt'];b=cert['body']
            check(b['schema']=='swc-exact-output-v1' and b['scope']=='single_mathematical_instance','receipt scope')
            check(b['relation']=='lonely_runner' and b['instance']==values,'receipt identity')
            check(cert['sha256']==digest(b),'receipt hash');exact(values,b['witness'])
        else:failures+=1
        trial_count+=1
    check(trial_count==trials,'incomplete or extended horizon')
    alpha=Fraction(plan['alpha']);target=Fraction(plan['target_failure_rate'])
    check(0<alpha<1 and 0<target<1,'probability parameters')
    # Independent direct binomial sum, bounded for this pilot verifier.
    check(failures<=100,'independent binomial sum budget exceeded')
    def cdf(p):
        return sum((comb(trials,k)*p**k*(1-p)**(trials-k) for k in range(failures+1)),Fraction())
    upper=Fraction(report['failure_rate_upper_bound'])
    check(0<upper<=1,'upper bound')
    check(upper==1 if failures==trials else cdf(upper)<=alpha,'upper failure bound is not conservative')
    check(report['target_demonstrated']==(cdf(target)<=alpha),'threshold decision')
    check(report['trials']==trials and report['failures']==failures and report['status_counts']==statuses,'counts')
    check(report['alpha']==str(alpha) and report['confidence_level']==str(1-alpha),'confidence parameters')
    check(report['success_rate_lower_bound']==str(1-upper),'success lower bound')
    check(report['plan_sha256']==plan_hash and report['event_chain_final']==previous,'report binding')
    check(report['scope']==plan['distribution'],'report scope')
    check(report['physical_deployment_validated'] is False,'unsupported deployment claim')
    return {'finite_cases_checked':index,'holdout_trials_checked':trials,'holdout_failures':failures,
            'fixed_horizon_bound_verified':str(upper),'scope':'declared mathematical input domains',
            'IID_and_provenance_are_assumptions':True}


if __name__=='__main__':print(json.dumps(verify(sys.argv[1]),indent=2))
