"""Exact audit of user-specified canonical pair positions; no floating point."""
from functools import lru_cache
from itertools import combinations
from math import gcd
from fractions import Fraction
from swc_lonely_runner import speeds_checked, congruence_roots


def is_open(values):
    return all(any(v%r==0 for v in values) for r in range(2,len(values)+2))


@lru_cache(maxsize=16384)
def targets(q,N,variant='original'):
    if variant=='original':
        result={q//N,(q+N-1)//N,q//N+1,q//2,(q+1)//2}
        for d in range(2,7):
            for k in range(1,d):
                result.update((k*q//d,(k*q+d-1)//d))
    elif variant=='folded':
        result={(q+N-1)//N,(q+N-1)//N+1,q//2}
        for d in range(2,7):
            for k in range(1,d//2+1):
                result.update((k*q//d,(k*q+d-1)//d))
        result={c for c in result if (q+N-1)//N<=c<=q//2}
    else:raise ValueError('unknown target variant')
    return tuple(sorted(result))


@lru_cache(maxsize=32768)
def pair_candidates(a,b,N,variant='original',unit=True):
    q=a+b;g=gcd(a,b);out=[]
    for c in targets(q,N,variant):
        if c%g or (unit and gcd(c//g,q//g)!=1):continue
        for m in congruence_roots(a,q,c):
            if unit and gcd(m,q)!=1:continue
            if N*min(c%q,q-c%q)<q:continue
            out.append((m,q,c))
    return tuple(out)


def canonical_witness(values,variant='original',unit=True):
    values=speeds_checked(values);N=len(values)+1
    for a,b in combinations(values,2):
        for m,q,c in pair_candidates(a,b,N,variant,unit):
            if all(N*min(m*v%q,q-m*v%q)>=q for v in values):
                return {'pair':[a,b],'q':q,'m':m,'oriented_target':c,
                        'distance':str(Fraction(min(m*a%q,q-m*a%q),q)),
                        'time':str(Fraction(m,q))}
    return None


def verify_witness(values,record,variant='original',unit=True):
    """Check the proposed tuple using independent Fraction distances."""
    values=speeds_checked(values)
    if not isinstance(record,dict):raise ValueError('record required')
    a,b=record['pair'];m=record['m'];q=record['q'];c=record['oriented_target']
    if any(type(x) is not int for x in (a,b,m,q,c)):raise ValueError('integers required')
    if a not in values or b not in values or a>=b or q!=a+b or not 0<=m<q:
        raise ValueError('pair or time mismatch')
    if unit and gcd(m,q)!=1:raise ValueError('nonunit multiplier')
    if c not in targets(q,len(values)+1,variant) or a*m%q!=c:
        raise ValueError('target mismatch')
    t=Fraction(m,q);distances=[]
    for v in values:
        x=t*v;x-=x.__floor__();distances.append(min(x,1-x))
    if min(distances)<Fraction(1,len(values)+1):raise ValueError('unsafe runner')
    if record['time']!=str(t):raise ValueError('time record')
    if record['distance']!=str(distances[values.index(a)]):raise ValueError('distance record')
    return True


def complete_witness_search(values):
    """Canonical targets are a fast proposal, never a completeness assumption."""
    from swc_lonely_runner import exact_grid_record, lonely, MAX_WORK
    original=speeds_checked(values);g=gcd(*original)
    normalized=tuple(v//g for v in original);N=len(original)+1
    chosen=None;route=None
    for q in range(2,N+1):
        if all(v%q for v in normalized):
            chosen=Fraction(1,q);route='small_modulus';break
    if chosen is None:
        for require_unit in (True,False):
            candidate=canonical_witness(normalized,unit=require_unit)
            if candidate:
                chosen=Fraction(candidate['time'])
                route='canonical_unit' if require_unit else 'canonical_nonunit'
                break
    if chosen is None:
        moduli={a+b for a,b in combinations(normalized,2)}
        if sum(moduli)*len(normalized)>MAX_WORK:
            return {'status':'budget_exceeded','scope':'single_speed_tuple',
                    'canonical_failure_is_nonexistence':False}
        record=exact_grid_record(normalized)
        if Fraction(record['accepted_mass'])==0:
            return {'status':'no_lonely_time','scope':'single_speed_tuple','grid_record':record,
                    'completeness_dependency':'pair-sum local-maximum theorem'}
        chosen=Fraction(record['maximizing_time']);route='complete_pair_grid'
    actual=chosen/g
    if not lonely(original,actual.numerator,actual.denominator):
        raise AssertionError('normalization transport failed')
    return {'status':'witness','speeds':list(original),'normalized_speeds':list(normalized),
            'normalization_gcd':g,'time':str(actual),'threshold':str(Fraction(1,N)),
            'route':route,'scope':'single_speed_tuple'}
