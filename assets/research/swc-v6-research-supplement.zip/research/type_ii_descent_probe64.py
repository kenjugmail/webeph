#!/usr/bin/env python3
"""Deterministic 64-bit stress probe for bounded Type-II parent corridors.

Unlike the dense sieve search, this tool samples exact primes at large heights
and factors only the candidate parent anchors.  It is intended to falsify
finite shift/scale ceilings, not to support a universal claim.
"""

from __future__ import annotations

import argparse
import json
import math
from collections import Counter
from pathlib import Path


MR_BASES_64 = (2, 325, 9375, 28178, 450775, 9780504, 1795265022)
MORDELL_HARD_RESIDUES = {1, 121, 169, 289, 361, 529}


def is_prime(n: int) -> bool:
    if n < 2:
        return False
    for prime in (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37):
        if n % prime == 0:
            return n == prime
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    for base in MR_BASES_64:
        if base % n == 0:
            continue
        value = pow(base, d, n)
        if value in (1, n - 1):
            continue
        for _ in range(s - 1):
            value = value * value % n
            if value == n - 1:
                break
        else:
            return False
    return True


def pollard_rho(n: int) -> int:
    if n % 2 == 0:
        return 2
    if n % 3 == 0:
        return 3
    constant = 1
    while True:
        x = y = 2
        divisor = 1
        while divisor == 1:
            x = (x * x + constant) % n
            y = (y * y + constant) % n
            y = (y * y + constant) % n
            divisor = math.gcd(abs(x - y), n)
        if divisor != n:
            return divisor
        constant += 1


def factor(n: int, output: list[int]) -> None:
    if n == 1:
        return
    if is_prime(n):
        output.append(n)
        return
    divisor = pollard_rho(n)
    factor(divisor, output)
    factor(n // divisor, output)


def square_divisors(n: int) -> list[int]:
    raw: list[int] = []
    factor(n, raw)
    counts = Counter(raw)
    divisors = [1]
    for prime, exponent in sorted(counts.items()):
        powers = [1]
        for _ in range(2 * exponent):
            powers.append(powers[-1] * prime)
        divisors = [divisor * power for divisor in divisors for power in powers]
    return sorted(divisors)


def verifies(n: int, x: int, y: int, z: int) -> bool:
    return min(n, x, y, z) > 0 and 4 * x * y * z == n * (x * y + x * z + y * z)


def find_parent(p: int, max_shift: int, max_scale: int) -> dict[str, int] | None:
    for shift in range(3, min(max_shift, p - 1) + 1, 4):
        for scale in range(2, max_scale + 1):
            if (p + shift) % (4 * scale):
                continue
            x = (p + shift) // (4 * scale)
            q = 4 * x - shift
            if q < 2:
                continue
            for divisor in square_divisors(x):
                if (x + divisor) % shift == 0:
                    complement = x * x // divisor
                    if (x + complement) % shift:
                        raise AssertionError("complementary divisor lost the congruence")
                    b = (x + divisor) // shift
                    e = (x + complement) // shift
                    if not verifies(q, x, q * b, q * e):
                        raise AssertionError("invalid high-probe parent witness")
                    if not verifies(
                        p,
                        scale * x,
                        scale * p * b,
                        scale * p * e,
                    ):
                        raise AssertionError("invalid high-probe transported witness")
                    return {
                        "p": p,
                        "q": q,
                        "scale": scale,
                        "shift": shift,
                        "parent_x": x,
                        "divisor": divisor,
                    }
    return None


def hard_primes(start: int, count: int, mordell_hard_only: bool):
    candidate = start + ((1 - start) % 24)
    emitted = 0
    while emitted < count:
        if is_prime(candidate) and (
            not mordell_hard_only or candidate % 840 in MORDELL_HARD_RESIDUES
        ):
            yield candidate
            emitted += 1
        candidate += 24


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--start", type=int, default=1_000_000_000_000)
    parser.add_argument("--count", type=int, default=1_000)
    parser.add_argument("--max-c", type=int, default=179)
    parser.add_argument("--max-scale", type=int, default=13)
    parser.add_argument("--mordell-hard", action="store_true")
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()

    records: list[dict[str, int]] = []
    misses: list[int] = []
    for prime in hard_primes(args.start, args.count, args.mordell_hard):
        record = find_parent(prime, args.max_c, args.max_scale)
        if record is None:
            misses.append(prime)
        else:
            records.append(record)

    result = {
        "status": "deterministic_falsification_probe_only",
        "start": args.start,
        "target_count": args.count,
        "max_shift": args.max_c,
        "max_scale": args.max_scale,
        "mordell_hard_only": args.mordell_hard,
        "covered": len(records),
        "miss_count": len(misses),
        "first_misses": misses[:100],
        "shift_histogram": dict(sorted(Counter(r["shift"] for r in records).items())),
        "scale_histogram": dict(sorted(Counter(r["scale"] for r in records).items())),
    }
    payload = json.dumps(result, indent=2, sort_keys=True)
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(payload + "\n", encoding="utf-8")
    print(payload)


if __name__ == "__main__":
    main()
