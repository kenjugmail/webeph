# Universal SWC attempt: changing the probability measure

Date: 2026-09-04. Outcome: three difficult instances certified by a new
proposal distribution; universal support coverage remains open. These are
new certificates in this investigation, not newly solved Erdős–Straus instances
or claims of original probability theory.

## An exhaustive obstruction to the previous uniform proposal

For p=806521, there are 403260 shifts h congruent to 3 modulo 4 in (0,2p].
At every such shift the uniform signed-exponent distribution fails the
previous sufficient collision inequality (m-k)P_col<1, even allowing all three
safe targets -1, -p^{-1}, and -p. Repeated residues are counted only once.

The audit uses the following exact pruning lemma: with N equally weighted
seeds, sum n_r^2 >= N. Thus if N<=m-k, the collision inequality is impossible.
This excludes 403239 shifts. For the other 21, residue convolution and a
separate integer-divisor enumeration agree, and exact arithmetic checks that
the collision inequality fails. This falsifies the candidate claim that this
particular distribution always supplies a certificate at a canonical shift.
It does not exclude other shifts outside this range or other distributions.

## A repair through SWC change of measure

For each fixed p,h, let Omega be the signed-exponent vectors from the
factorization C=(p+h)/4. Write n_r for the number producing residue r, and
s for the number of reachable residues. Assign each individual vector omega
the probability

    mu(omega) = 1 / (s n_{R(omega)}).

Normalization is exact:

    sum_omega mu(omega) = sum_{r reachable} n_r/(s n_r) = 1.

Every original vector retains positive probability; the distribution on the
reachable residues is uniform. This proposal is generally correlated across
prime factors. It must not be described as independent exponent sampling.

Let G be the ambient finite group, m=|G|, and T its k distinct valid targets.
Since at most m-k reachable residues can be outside T,

    mu(R in T) >= max(0,(s-m+k)/s).

This is a symbolic sufficient SWC certificate. In particular, full support
s=m gives exact success probability k/m. Targets -1 and -p^{-1} decode
directly to the manuscript's two divisor tests. A seed at -p is inverted
first, which sends it to -p^{-1}; inversion negates all exponents and stays
within their original bounds.

For executable sampling, first select a reachable residue uniformly, then
select one of its n_r preimages uniformly. Computing the preimages can require
the same residue counting as the original search; no speedup is claimed.

## Exact certificates obtained

| p | h | Reachable residues s | Group size m | Distinct targets k | Accepted mass |
|---:|---:|---:|---:|---:|---:|
| 806521 | 95 | 72 | 72 | 3 | 1/24 |
| 2458369 | 55 | 40 | 40 | 2 | 1/20 |
| 8803369 | 151 | 150 | 150 | 3 | 1/50 |

Independent integer-divisor enumeration verifies the full residue support.
The checker also reconstructs positive denominators and verifies
4xyz=p(xy+xz+yz) with arbitrary-precision integers for each row. These exact
positive probabilities prove existence for the three stated primes under
SWC's rule. They are probabilities of drawing a witness, not probabilities
that the mathematical identity is true.

## The universal statement still needed

To finish this particular approach, it suffices to prove

    For every prime p == 1 mod 24, some admissible h satisfies
    |support(R_{p,h})| > |G_{p,h}| - |T_{p,h}|.

Here T is intersected with G if using the generated subgroup, and must be
nonempty. A symbolic proof of this assertion would provide a positive
lower bound for each p and yield a universal SWC proof. The lower bound
may depend on p; no single universal probability constant is required.

This support assertion is stronger than mere existence and is unproved here.
Choosing weights cannot create a previously absent valid residue. Consequently
the change of measure repairs the overly coarse collision estimate for these
instances, but cannot by itself prove universal support coverage.

## Remaining possible analytic attack

For each fixed h, character orthogonality expresses residue counts as products
of finite prime-power sums. The nontrivial work is showing that for at least
one shifted factorization C=(p+h)/4 these sums cannot collectively exclude
all valid targets. Averages over different p and unconstrained repeated random
walks do not establish this per-prime statement. No such target-sensitive
estimate was established in this attempt.

Reproduction:

    python3 -B research/audit_collision_universality.py --out research/evidence/collision-universality-obstruction.json
    python3 -B research/swc_balanced_mass.py --out research/evidence/swc-balanced-mass.json

Related local derivation: swc-probabilistic-closure-attempt.md.
