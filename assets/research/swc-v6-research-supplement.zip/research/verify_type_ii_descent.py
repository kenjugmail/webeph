#!/usr/bin/env python3
"""Fail-closed checks for the Type-II scaling lemma and finite evidence record."""

from __future__ import annotations

import argparse
import json
import math
from fractions import Fraction
from pathlib import Path


EXPECTED_TARGETS_BELOW_100M = 719_781


def verify_record(record: dict[str, int]) -> None:
    p = int(record["p"])
    q = int(record["q"])
    scale = int(record["scale"])
    shift = int(record["shift"])
    x = int(record["parent_x"])
    divisor = int(record["divisor"])

    if scale < 2 or shift % 4 != 3 or q < 2:
        raise SystemExit("invalid descent parameters")
    if p != 4 * scale * x - shift or q != 4 * x - shift:
        raise SystemExit("parent/child rank equations fail")
    if not q < p / 2:
        raise SystemExit("descent is not strict")
    if x * x % divisor:
        raise SystemExit("claimed divisor does not divide x^2")
    complement = x * x // divisor
    if (x + divisor) % shift or (x + complement) % shift:
        raise SystemExit("divisor pair fails the Type-II congruences")
    b = (x + divisor) // shift
    e = (x + complement) // shift

    common = math.gcd(x, divisor)
    a0 = x // common
    b0 = divisor // common
    if common * common % divisor:
        raise SystemExit("primitive unused factor is not integral")
    unused = common * common // divisor
    if x != a0 * b0 * unused or divisor != b0 * b0 * unused:
        raise SystemExit("primitive normalization identities fail")
    if (a0 + b0) % shift:
        raise SystemExit("primitive modulator is not integral")
    quotient = (a0 + b0) // shift
    primitive = 4 * a0 * b0 - shift
    total_scale = scale * unused
    if primitive < 2 or p != primitive + 4 * (total_scale - 1) * a0 * b0:
        raise SystemExit("primitive descent path fails")
    declared = {
        "primitive_a": a0,
        "primitive_b": b0,
        "primitive_unused_factor": unused,
        "primitive_q": primitive,
        "total_scale": total_scale,
    }
    for key, value in declared.items():
        if key in record and int(record[key]) != value:
            raise SystemExit(f"declared {key} does not match normalization")

    parent = Fraction(1, x) + Fraction(1, q * b) + Fraction(1, q * e)
    child = (
        Fraction(1, scale * x)
        + Fraction(1, scale * p * b)
        + Fraction(1, scale * p * e)
    )
    if parent != Fraction(4, q) or child != Fraction(4, p):
        raise SystemExit("exact rational witness check failed")
    primitive_witness = (
        Fraction(1, a0 * b0)
        + Fraction(1, primitive * b0 * quotient)
        + Fraction(1, primitive * a0 * quotient)
    )
    if primitive_witness != Fraction(4, primitive):
        raise SystemExit("primitive parent witness failed")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "evidence",
        type=Path,
        nargs="?",
        default=Path(__file__).resolve().parent / "evidence" / "type-ii-descent-100m.json",
    )
    args = parser.parse_args()
    evidence = json.loads(args.evidence.read_text(encoding="utf-8"))

    if evidence.get("status") != "finite_conjecture_search_only":
        raise SystemExit("finite evidence was promoted beyond its scope")
    if evidence.get("targets") != EXPECTED_TARGETS_BELOW_100M:
        raise SystemExit("unexpected hard-prime target count")
    if evidence.get("covered_by_strict_parent") != evidence["targets"]:
        raise SystemExit("finite target is not fully covered")
    if evidence.get("miss_count") != 0 or evidence.get("first_misses"):
        raise SystemExit("finite search contains misses")
    if evidence.get("max_shift") != 179 or evidence.get("max_scale") != 13:
        raise SystemExit("unexpected finite search boundary")
    if sum(map(int, evidence["scale_histogram"].values())) != evidence["targets"]:
        raise SystemExit("scale histogram does not conserve target count")
    if sum(map(int, evidence["shift_histogram"].values())) != evidence["targets"]:
        raise SystemExit("shift histogram does not conserve target count")

    verify_record(evidence["largest_shift_record"])

    high_probe_expectations = {
        "type-ii-descent-probe-mordell-1e15.json": (10**15, 100_000),
        "type-ii-descent-probe-mordell-9e17.json": (9 * 10**17, 5_000),
    }
    for filename, (expected_start, expected_count) in high_probe_expectations.items():
        probe = json.loads((args.evidence.parent / filename).read_text(encoding="utf-8"))
        if probe.get("status") != "deterministic_falsification_probe_only":
            raise SystemExit(f"{filename} escaped its finite-evidence boundary")
        if not probe.get("mordell_hard_only"):
            raise SystemExit(f"{filename} is not restricted to the declared hard residues")
        if probe.get("start") != expected_start or probe.get("target_count") != expected_count:
            raise SystemExit(f"{filename} has an unexpected sample boundary")
        if probe.get("covered") != expected_count or probe.get("miss_count") != 0:
            raise SystemExit(f"{filename} contains an unresolved sampled target")
        if probe.get("first_misses"):
            raise SystemExit(f"{filename} reports a sampled miss")
        if sum(map(int, probe["shift_histogram"].values())) != expected_count:
            raise SystemExit(f"{filename} shift histogram does not conserve count")
        if sum(map(int, probe["scale_histogram"].values())) != expected_count:
            raise SystemExit(f"{filename} scale histogram does not conserve count")

    # Independent exact regressions spanning different scales and shifts.
    for record in [
        {"p": 73, "q": 33, "scale": 2, "shift": 7, "parent_x": 10, "divisor": 25},
        {"p": 241, "q": 73, "scale": 3, "shift": 11, "parent_x": 21, "divisor": 1},
        {"p": 1009, "q": 89, "scale": 11, "shift": 3, "parent_x": 23, "divisor": 1},
        {"p": 118801, "q": 39561, "scale": 3, "shift": 59, "parent_x": 9905, "divisor": 7},
    ]:
        verify_record(record)

    # The denominator-aligned transformer also works for a non-Type-II input
    # once L clears q from the other two denominators.
    q, x, y, z, scale = 5, 2, 4, 20, 5
    p = q + 4 * (scale - 1) * x
    if Fraction(1, x) + Fraction(1, y) + Fraction(1, z) != Fraction(4, q):
        raise SystemExit("general-transform parent regression is invalid")
    transformed = (
        Fraction(1, scale * x)
        + Fraction(q, scale * p * y)
        + Fraction(q, scale * p * z)
    )
    if p != 37 or transformed != Fraction(4, p):
        raise SystemExit("general denominator-aligned transformer failed")

    # Type-II scales compose multiplicatively.
    q, x, b, e = 33, 10, 2, 5
    direct_scale = 6
    direct_p = q + 4 * (direct_scale - 1) * x
    first_p = q + 4 * (2 - 1) * x
    composed_p = first_p + 4 * (3 - 1) * (2 * x)
    if direct_p != composed_p:
        raise SystemExit("Type-II scale composition failed")

    print(
        "Type-II descent verifier: PASS · exact transformer · "
        f"{evidence['targets']} finite targets · universal coverage OPEN"
    )


if __name__ == "__main__":
    main()
