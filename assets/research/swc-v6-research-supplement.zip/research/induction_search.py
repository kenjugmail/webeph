#!/usr/bin/env python3
"""Build a provenance-tracked proof-obligation graph from the SWC v3 artifact."""

import argparse
import csv
import hashlib
import io
import json
import zipfile
from collections import Counter
from pathlib import Path
from pathlib import PurePosixPath

EXPECTED_ARCHIVE_SHA256 = "e22bc0f376244744e6b506b9562465ffc5174239f0fb9f0f7e8e1368f7121899"
EXPECTED_ROWS = 82_887


def digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_members(archive):
    for info in archive.infolist():
        path = PurePosixPath(info.filename)
        if path.is_absolute() or ".." in path.parts:
            raise ValueError(f"unsafe archive member: {info.filename}")
        yield info


def node(identifier, kind, status, claim, source, confidence="exact"):
    return {
        "id": identifier,
        "type": kind,
        "status": status,
        "claim": claim,
        "source": source,
        "confidence": confidence,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("artifact")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    archive_hash = digest(args.artifact)
    if archive_hash != EXPECTED_ARCHIVE_SHA256:
        raise SystemExit(f"artifact hash mismatch: {archive_hash}")

    with zipfile.ZipFile(args.artifact) as archive:
        list(safe_members(archive))
        csv_bytes = archive.read("results/erdos_results.csv")
        summary = json.loads(archive.read("results/erdos_summary.json"))
        source = archive.read("paper/main.tex").decode("utf-8")

    rows = list(csv.DictReader(io.StringIO(csv_bytes.decode("utf-8"))))
    if len(rows) != EXPECTED_ROWS:
        raise SystemExit(f"unexpected certificate row count: {len(rows)}")
    exact_columns = ["p", "least_c", "first_d", "branch", "successful_shifts"]
    if any(not all(row.get(key) for key in exact_columns) for row in rows):
        raise SystemExit("an exact certificate column is missing")
    if not summary.get("all_first_witnesses_verified") or summary.get("covered") != EXPECTED_ROWS:
        raise SystemExit("artifact does not attest complete finite witness verification")

    least_histogram = Counter(int(row["least_c"]) for row in rows)
    max_c = max(least_histogram)
    hard_rows = [row for row in rows if int(row["least_c"]) == max_c]
    extended_path = Path(__file__).resolve().parent / "evidence" / "erdos-100m-summary.json"
    extended = json.loads(extended_path.read_text()) if extended_path.is_file() else None
    type_ii_path = Path(__file__).resolve().parent / "evidence" / "type-ii-descent-100m.json"
    type_ii = json.loads(type_ii_path.read_text()) if type_ii_path.is_file() else None
    high_probe_paths = [
        Path(__file__).resolve().parent / "evidence" / "type-ii-descent-probe-mordell-1e15.json",
        Path(__file__).resolve().parent / "evidence" / "type-ii-descent-probe-mordell-9e17.json",
    ]
    high_probes = [json.loads(path.read_text()) for path in high_probe_paths if path.is_file()]

    generic_rule_present = all(fragment in source for fragment in [
        "Well-founded reduction rule",
        "r(i)\\prec i",
        "R(r(i),w)\\Rightarrow R(i,T_i(w))",
    ])
    descent_columns = [
        key for key in rows[0]
        if key.lower() in {"q", "parent", "rank", "reduction", "transformer"}
        or "desc" in key.lower()
    ]

    nodes = [
        node("T-SWC-REDUCTION", "Theorem", "proved_on_paper" if generic_rule_present else "missing", "A well-founded reduction plus a sound witness transformer proves the whole instance family.", "paper/main.tex: Proposition Well-founded reduction rule"),
        node("T-COMPOSITE-LIFT", "Theorem", "proved", "A solution for d lifts to every multiple n=kd by scaling all three denominators by k.", "elementary exact identity"),
        node("T-TYPEII-SCALING", "Theorem", "proved", "A Type-II witness for q with first denominator x transforms exactly into a witness for p=q+4(L-1)x; for L>=2 the parent satisfies q<p/2.", "research/type-ii-scaling-descent.md", "exact_symbolic"),
        node("E-FINITE-10M", "Evidence", "verified", "Every declared hard-class prime below 10^7 has an exact reconstructed witness.", "results/erdos_results.csv", "exact_finite"),
        node("E-SHIFT-127", "Evidence", "observed", f"The finite sample has maximum least successful shift c={max_c}.", "results/erdos_results.csv", "finite_empirical"),
        node("E-FINITE-100M", "Evidence", "verified_noncanonical" if extended else "missing", f"An independent extension verifies {extended['covered'] if extended else 0} hard-class primes below 10^8 with maximum least shift {extended['max_least_shift'] if extended else 'unknown'}.", "research/evidence/erdos-100m-summary.json", "exact_finite" if extended else "missing"),
        node("E-TYPEII-DESCENT-100M", "Evidence", "verified_noncanonical" if type_ii and type_ii.get("miss_count") == 0 else "missing", f"An exact finite search gives strict Type-II parents for {type_ii['covered_by_strict_parent'] if type_ii else 0} hard-class primes below 10^8 using shifts through {type_ii['max_shift'] if type_ii else 'unknown'} and scales through {type_ii['max_scale'] if type_ii else 'unknown'}.", "research/evidence/type-ii-descent-100m.json", "exact_finite" if type_ii else "missing"),
        node("E-TYPEII-HIGH-PROBES", "Evidence", "observed" if high_probes and all(probe.get("miss_count") == 0 for probe in high_probes) else "missing", f"Deterministic sparse high-height probes tested {sum(probe.get('target_count', 0) for probe in high_probes)} Mordell-hard primes with no observed miss; these are not exhaustive intervals.", "research/evidence/type-ii-descent-probe-mordell-*.json", "finite_empirical" if high_probes else "missing"),
        node("C-QUOTIENT", "CandidateReduction", "rejected", "q=floor(p/c) is a search-tracking quotient, not an Erdős–Straus instance whose witness is transformed into one for p.", "paper/main.tex and Dahan Theorem 2.12"),
        node("C-ANCHOR", "CandidateReduction", "rejected", "a=(p+c)/4 is an anchor used by a direct divisor certificate; the artifact supplies no map from a witness for a to a witness for p.", "experiments/exp_erdos.cpp"),
        node("C-BOUNDED-SHIFT", "CandidateReduction", "open", "The observed shifts through 127 cover the tested domain, but no symbolic proof establishes total coverage for all hard-class primes.", "results/erdos_results.csv", "finite_empirical"),
        node("C-GEOMETRIC-TAIL", "CandidateReduction", "rejected_as_finite_closure", "A full-support geometric prior gives an exact tail bound 2^-N after N verified primes, but no finite N makes the unresolved mass zero.", "research/geometric-tail-analysis.md", "exact_negative_result"),
        node("C-MASS-GAP", "CandidateReduction", "open_requires_amplification", "No full-support probability on infinitely many primes has a uniform positive singleton mass; a usable gap requires a new theorem amplifying any counterexample into a positive-mass family.", "research/mass-gap-analysis.md", "exact_negative_result"),
        node("E-FIXED-DEPTH-SIEVE", "Evidence", "nonclosing_theorem", "Known fixed-depth and growing-depth sieve bounds make exceptional sets sparse but do not prove they are empty; a fixed shift can retain an infinite blind family.", "Dahan 2026, Sections 4.1-4.3", "published_theorem"),
        node("C-FAB-TRANSLATION", "CandidateReduction", "proved_but_nonclosing", "The fab translation and fixed-divisor offset transport preserve a certificate along a known progression, but do not supply a progression covering every target prime.", "Bello-Hernandez--Benito--Fernandez 2026 Proposition 20; Lean offset formalization", "published_and_formalized"),
        node("O-INTERIOR-TYPEII-HIT", "ProofObligation", "open", "Every hard prime must have an interior Type-II signed-divisor hit, equivalently a certified parent q<p/2 to which the exact scaling transformer applies.", "research/type-ii-scaling-descent.md", "unproved"),
        node("O-PRIME-DESCENT", "ProofObligation", "open", "For every prime p congruent to 1 modulo 24, construct a direct certificate or a strict lower-rank reduction with a checked witness transformer.", "required by T-SWC-REDUCTION", "unproved"),
        node("G-UNIVERSAL", "Goal", "blocked", "Every integer n>=2 has a three-unit-fraction decomposition of 4/n.", "Erdős–Straus conjecture", "unproved"),
    ]
    edges = [
        {"from": "T-COMPOSITE-LIFT", "relation": "REDUCES_DOMAIN_TO", "to": "O-PRIME-DESCENT"},
        {"from": "E-FINITE-10M", "relation": "SUPPORTS_BASE_CASES_OF", "to": "O-PRIME-DESCENT"},
        {"from": "T-TYPEII-SCALING", "relation": "SUPPLIES_TRANSFORMER_FOR", "to": "O-INTERIOR-TYPEII-HIT"},
        {"from": "E-TYPEII-DESCENT-100M", "relation": "SUPPORTS_BUT_DOES_NOT_PROVE", "to": "O-INTERIOR-TYPEII-HIT"},
        {"from": "E-TYPEII-HIGH-PROBES", "relation": "FALSIFICATION_TESTS_BUT_DOES_NOT_PROVE", "to": "O-INTERIOR-TYPEII-HIT"},
        {"from": "C-FAB-TRANSLATION", "relation": "INFORMS_BUT_DOES_NOT_CLOSE", "to": "O-INTERIOR-TYPEII-HIT"},
        {"from": "O-INTERIOR-TYPEII-HIT", "relation": "WOULD_CLOSE", "to": "O-PRIME-DESCENT"},
        {"from": "E-SHIFT-127", "relation": "SUPPORTS_BUT_DOES_NOT_PROVE", "to": "C-BOUNDED-SHIFT"},
        {"from": "E-FINITE-100M", "relation": "SUPPORTS_BUT_DOES_NOT_PROVE", "to": "C-BOUNDED-SHIFT"},
        {"from": "C-QUOTIENT", "relation": "FAILS_AS", "to": "O-PRIME-DESCENT"},
        {"from": "C-ANCHOR", "relation": "FAILS_AS", "to": "O-PRIME-DESCENT"},
        {"from": "C-GEOMETRIC-TAIL", "relation": "DOES_NOT_CLOSE", "to": "O-PRIME-DESCENT"},
        {"from": "C-MASS-GAP", "relation": "REQUIRES_NEW_AMPLIFICATION_THEOREM", "to": "O-PRIME-DESCENT"},
        {"from": "E-FIXED-DEPTH-SIEVE", "relation": "CONSTRAINS", "to": "C-BOUNDED-SHIFT"},
        {"from": "O-PRIME-DESCENT", "relation": "REQUIRED_BY", "to": "T-SWC-REDUCTION"},
        {"from": "T-SWC-REDUCTION", "relation": "WOULD_PROVE_IF_OBLIGATION_CLOSED", "to": "G-UNIVERSAL"},
    ]
    result = {
        "schemaVersion": 1,
        "artifact": {"sha256": archive_hash, "certificateRows": len(rows)},
        "finiteEvidence": {
            "covered": summary["covered"],
            "maxLeastShift": max_c,
            "maxLeastShiftRows": [
                {key: row[key] for key in exact_columns} for row in hard_rows
            ],
            "leastShiftHistogram": dict(sorted(least_histogram.items())),
        },
        "inductionAudit": {
            "genericRulePresent": generic_rule_present,
            "descentColumns": descent_columns,
            "primeDescentStatus": "open",
            "universalClaimStatus": "blocked",
        },
        "nodes": nodes,
        "edges": edges,
        "stopReason": "A strict Type-II witness transformer is now proved, but total interior-hit coverage for every remaining prime is unproved.",
    }
    with open(args.output, "w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write("\n")
    print(json.dumps(result["inductionAudit"], sort_keys=True))


if __name__ == "__main__":
    main()
