# What the proposed universal parameter rule asserts

2026-09-05. This note proves a normalization equivalence and finite search
bounds. It does not prove universal parameter existence.

For an odd prime p, the proposed rule asks for positive integers A,B,S,h with

    p=4ABS-h, h|(A+B).

This is equivalent to existence of a Type-II Erdős–Straus witness. It is not
merely an auxiliary consequence of induction.

## Forward implication

Given the parameters, set Q=(A+B)/h. The positive denominators

    x=ABS, y=pAQS, z=pBQS

satisfy the equation by direct substitution. For p prime, x cannot be
divisible by p: otherwise all three denominators are positive multiples of
p and the reciprocal sum is at most 3/p, contradicting 4/p. Thus this is
a Type-II solution.

## Reverse implication

Suppose

    4/p=1/x+1/(pb)+1/(pe)

with positive integers x,b,e. Multiplying by p gives

    4=p/x+1/b+1/e,

so p/4<x<=p/2. In particular p does not divide x. Put

    g=gcd(b,e), b=gA, e=gB, gcd(A,B)=1, h=4x-p>0.

The equation becomes

    hgAB=x(A+B).

Since gcd(AB,A+B)=1, AB divides x. Write x=ABS. Cancel AB to obtain

    hg=S(A+B).

Now gcd(h,S)=gcd(4ABS-p,S)=gcd(p,S)=1 because S<=x<p. Hence h divides
A+B. Setting Q=(A+B)/h gives g=SQ, exactly the original family
parametrization (up to swapping the last denominators).

For p==1 mod4, h=4x-p is automatically 3 mod4.

## Bounds for a complete finite search of these parameters

Swap A,B if necessary so A<=B. Since h<=A+B and S>=1,

    p>=4AB-A-B=(4A-1)B-A>=4A^2-2A.

Consequently

    A <= floor((1+sqrt(1+4p))/4),
    A <= B <= floor((p+A)/(4A-1)).

For each pair A,B it suffices to consider positive divisors h of A+B with
h==3 mod4 and 4AB|(p+h). Then S=(p+h)/(4AB). Conversely every allowed
parameter tuple occurs in this finite search. No statement here establishes
that the search set is nonempty for every p.

## Consequence for the current proof attempt

The proposed all-prime parameter rule is exactly an all-prime Type-II
existence assertion. Replacing it by SWC positive mass is valid when the mass
is independently proved positive, but does not discharge this assertion.
The normalization removes an ambiguity in the proof goal; it does not close
that goal.

The Type-I/Type-II framework and related parametrizations are classical:
[Elsholtz and Tao, Section 2](https://arxiv.org/pdf/1107.1010).
