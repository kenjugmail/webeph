"""Standalone exact checker for finite-state SWC success lower bounds.

Supports cycles and explicit failure terminals. Imports no producer modules.
Certifies one specified integer instance, never universal prime coverage.
"""
from fractions import Fraction
import argparse
import json
from pathlib import Path


def require(condition,message):
    if not condition:raise ValueError(message)


def verify(c):
    require(c.get('schema')=='swc-reachability-v1','unsupported schema')
    n=c['target_n'];states=c['states'];start=c['start'];horizon=c['horizon']
    require(type(n) is int and n>=2,'invalid target')
    require(type(horizon) is int and horizon>0,'invalid horizon')
    require(0<len(states)<=128,'checker supports at most 128 states')
    table={s['id']:s for s in states}
    require(len(table)==len(states) and start in table,'invalid state identifiers')
    epsilon=Fraction(c['drift']);require(epsilon>0,'nonpositive drift')
    lower={i:Fraction(s['success_potential']) for i,s in table.items()}
    rank={i:Fraction(s['time_potential']) for i,s in table.items()}
    for i,s in table.items():
        require(0<=lower[i]<=1 and rank[i]>=0,'invalid potential')
        transitions=s['transitions']
        require(0<len(transitions)<=16,'invalid transition count')
        weights=[Fraction(e['probability']) for e in transitions]
        require(all(w>=0 for w in weights) and sum(weights)==1,'unnormalized transition')
        require(all(e['to'] in table for e in transitions),'missing successor')
        kind=s['kind'];require(kind in ('search','success','failure'),'unknown state kind')
        if kind!='search':
            require(rank[i]==0 and all(e['to']==i for e in transitions),'terminal must be absorbing with zero time potential')
            require(lower[i]==(1 if kind=='success' else 0),'incorrect terminal success potential')
            if kind=='success':
                witness=s['witness']
                require(len(witness)==3 and all(type(v) is int and v>0 for v in witness),'invalid witness')
                x,y,z=witness
                require(4*x*y*z==n*(x*y+x*z+y*z),'terminal witness is false')
        else:
            expected_lower=sum((w*lower[e['to']] for w,e in zip(weights,transitions)),Fraction())
            expected_rank=sum((w*rank[e['to']] for w,e in zip(weights,transitions)),Fraction())
            require(lower[i]<=expected_lower,'success submartingale inequality failed')
            require(rank[i]>=expected_rank+epsilon,'termination drift inequality failed')
    bound=lower[start]-rank[start]/(epsilon*horizon)
    require(bound>0,'finite-horizon bound is not positive')
    require(Fraction(c['claimed_lower_bound'])==bound,'claimed bound mismatch')
    return dict(target_n=n,horizon=horizon,certified_success_lower_bound=str(bound),
                scope='single_integer_instance',universal_coverage=False,states=len(states))


def main():
    parser=argparse.ArgumentParser();parser.add_argument('certificate',type=Path)
    args=parser.parse_args()
    print(json.dumps(verify(json.loads(args.certificate.read_text())),indent=2))


if __name__=='__main__':main()
