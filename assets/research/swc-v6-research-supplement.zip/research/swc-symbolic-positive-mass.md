# Symbolic positive witness mass from arithmetic factors

2026-09-05. These are sufficient family theorems for primes p congruent to 1
modulo 24. They do not establish positivity for every such prime. The
underlying small-shift constructions are elementary; no novelty is claimed.
The derivation uses no large-prime computation.

## A positive-mass theorem at shift 7

Put C=(p+7)/4. Since p=24m+1, C=6m+2 is even and is coprime to 7.
Suppose C has a prime divisor r whose residue modulo 7 is in {3,5,6},
the quadratic nonresidues.

Choose J uniformly from {-1,0,1}. Use signed residue

    R=r*2^J mod7

and divisor d=C*r*2^J. All three choices are actual divisors of C^2:
C contains a factor 2 and a factor r, and r is not 2. Each choice adds one
to the exponent of r and changes the exponent of 2 by at most one.
The exponent bounds remain within those of C^2.

The three residues {2^-1,1,2}={4,1,2} form the quadratic-residue subgroup
of the units modulo 7. Multiplying by the nonresidue r gives exactly the
three nonresidues {3,5,6}. Exactly one is -1=6.

The sampler accepts only R=-1. Hence its success probability is exactly 1/3.
At success, d=-C mod7 and d|C^2. Its complementary divisor is also -C mod7.
Set

    b=(C+d)/7, e=(C+C^2/d)/7.

These are positive integers and

    4/p=1/C+1/(pb)+1/(pe).

Thus this arithmetic condition proves positive SWC witness mass for every p
that meets it, with a numerical lower bound independent of p.
The congruence also identifies which J works, so the result could equivalently
be presented as a deterministic construction; probability adds no extra
coverage beyond the factor condition.

If no such factor r exists, every divisor ratio of C is a quadratic residue
modulo 7, so the Type-II target -1 is absent. This is an actual fixed-shift
obstruction rather than a failure to tune probabilities.

## A positive-mass theorem at shift 3

Put A=(p+3)/4. If A has a prime divisor r congruent to 2 modulo 3, choose
the signed ratio R=r and divisor d=Ar. Then d|A^2 and R=-1 mod3.
The same rectangle reconstruction yields a valid witness, with point mass one.
If no such factor exists, all factors of A are 1 mod3 and this target is absent.

## A symbolic mass function defined for arbitrary p

Let alpha(p) be one if the shift-3 factor condition holds, zero otherwise.
Let beta(p) be one if the shift-7 factor condition holds, zero otherwise.

Choose either branch with probability one half. A branch with no qualifying
factor returns rejection. The first branch uses its constructed witness; the
second uses the three-point sampler with the Type-II acceptance test only.
For every prime p congruent to 1 modulo 24, the exact accepted mass is

    delta(p)=alpha(p)/2 + beta(p)/6.

This is a proved arithmetic expression, not an extrapolation from sampled
primes. It is strictly positive on the union of these two families. It is
not strictly positive everywhere.

For p=2521, (p+3)/4=631 is prime and 1 mod3, while
(p+7)/4=632=2^3*79 has only quadratic-residue prime factors modulo7.
Thus alpha(2521)=beta(2521)=0. This says nothing against Erdős–Straus:
2521 has known witnesses at other shifts, including 23.

## Relation to the universal goal

The missing additional branch must prove positive mass for every prime with
alpha(p)=beta(p)=0. The previous recursion and general divisor criteria can
search this residual, but their success on every member has not been proved.
No such universal residual bound was established in this attempt.

This illustrates exactly the distinction between:

* proving a lower mass bound under an independently checkable arithmetic
  hypothesis; and
* proving that some successful hypothesis holds for every target prime.

Both are necessary to turn this family result into a universal SWC proof.

For context, [Dahan](https://arxiv.org/abs/2608.24035) proves that the shift-7
criterion has infinitely many prime failures. Therefore a universal
argument cannot stop with that one shift. The current theorem does not
contradict or supersede that result.

## Lightweight verification

The three possible nonresidue classes 3,5,6 were checked against J=-1,0,1.
Each has exactly one hit at -1. The p=73 construction was reconstructed and
checked by exact integer cross multiplication. The universal statements rest
on the algebra and subgroup argument above, not on those finite regressions.
