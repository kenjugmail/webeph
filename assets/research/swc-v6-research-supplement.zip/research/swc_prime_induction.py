"""Finite prime-prefix application of SWC with explicitly checked positivity.

Increasing the bound checks more primes; it does not prove the universal step.
For odd primes, the direct part uses the complete rectangle criterion. Where
the existing nested Type-II generator applies, its mass is mixed in as well.
"""
import argparse
from fractions import Fraction
import json
from pathlib import Path
from swc_mass_recursion import square_divisors, mass


def primes_up_to(limit):
    known=[]
    for n in range(2,limit+1):
        if all(n%q for q in known if q*q<=n):
            known.append(n)
            yield n


def direct_mass(p,x):
    h=4*x-p;product=p*x
    candidates=square_divisors(product)
    accepted=0;witness=None
    for d in candidates:
        other=product*product//d
        if (product+d)%h or (product+other)%h:
            continue
        y,z=(product+d)//h,(product+other)//h
        if min(x,y,z)<=0 or 4*x*y*z!=p*(x*y+x*z+y*z):
            raise ValueError('unsound direct candidate')
        accepted+=1
        witness=[x,y,z]
    return Fraction(accepted,len(candidates)),witness


def certify_prime(p):
    if p==2:
        return dict(p=2,method='base',witness=[1,2,2],accepted_mass='1')
    anchor_count=(3*p)//4-p//4
    for x in range(p//4+1,(3*p)//4+1):
        delta,witness=direct_mass(p,x)
        if delta==0:
            continue
        nested=mass(p,x)
        # Root chooses every canonical anchor uniformly, then chooses direct
        # or recursive generation with equal probability. This is the exact
        # contribution of this one anchor, hence a lower bound at the root.
        lower=(delta+nested)/(2*anchor_count)
        if not lower>0:
            raise ValueError('missing positive-mass certificate')
        return dict(p=p,method='direct_and_nested_mixture',anchor=x,
                    anchor_count=anchor_count,direct_mass=str(delta),
                    nested_mass=str(nested),root_mass_lower_bound=str(lower),
                    witness=witness)
    return dict(p=p,method='no_certificate',universal_step='unproved')


def verify_record(record):
    p=record['p']
    if record['method']=='no_certificate':return False
    if record['method']=='base':
        if p!=2 or record['witness']!=[1,2,2] or record['accepted_mass']!='1':
            raise ValueError('invalid base')
        return True
    if record['method']!='direct_and_nested_mixture':
        raise ValueError('unknown certificate method')
    x=record['anchor']
    if not p//4<x<=(3*p)//4:raise ValueError('anchor outside complete range')
    delta,_=direct_mass(p,x)
    nested=mass(p,x)
    count=(3*p)//4-p//4
    expected=(delta+nested)/(2*count)
    if record['anchor_count']!=count or Fraction(record['direct_mass'])!=delta or Fraction(record['nested_mass'])!=nested:
        raise ValueError('mass provenance mismatch')
    if Fraction(record['root_mass_lower_bound'])!=expected or expected<=0:
        raise ValueError('unverified positive mass')
    a,b,c=record['witness']
    if a!=x or min(a,b,c)<=0 or 4*a*b*c!=p*(a*b+a*c+b*c):
        raise ValueError('invalid output witness')
    return True


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--limit',type=int,default=300)
    parser.add_argument('--out',type=Path)
    args=parser.parse_args()
    records=[]
    for p in primes_up_to(args.limit):
        record=certify_prime(p)
        if not verify_record(record):
            raise RuntimeError(f'prime {p} lacks a certificate; induction does not advance')
        records.append(record)
    # Detect a forged positivity claim independently of successful witnesses.
    forged=dict(next(r for r in records if r['method']=='direct_and_nested_mixture'))
    forged['root_mass_lower_bound']='1'
    try:verify_record(forged)
    except ValueError:pass
    else:raise AssertionError('forged mass was accepted')
    result=dict(scope='finite_prime_prefix',limit=args.limit,verified_primes=len(records),
                universal_positive_mass_step='unproved',records=records)
    if args.out:args.out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(f'Verified {len(records)} primes <= {args.limit}; forged positivity rejected; universal step remains unproved.')


if __name__=='__main__':
    main()
