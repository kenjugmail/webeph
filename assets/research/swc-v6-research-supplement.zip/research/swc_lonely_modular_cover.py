"""Small modular-cover producer following arXiv:2604.23906v2 Definition 2.1.

This implements the authors' criterion, not a new theorem. Repeated residues
are retained. Sorting quotients only permutation symmetry, not missing cases.
"""
from itertools import combinations_with_replacement
from math import gcd, comb, prod
from pathlib import Path
import json


def produce(k,p,l):
    if any(type(x) is not int for x in (k,p,l)) or not 3<=k<=13 or not 2<=p<=101 or not 1<=l<=24:
        raise ValueError('parameter budget')
    if any(p%d==0 for d in range(2,int(p**0.5)+1)):
        raise ValueError('prime required')
    q=p*l
    residues=[r for r in range(q) if r%p]
    if comb(len(residues)+k-1,k)*q*k>5000000:
        raise ValueError('cover work budget')
    rows=[]; failures=[]
    for speeds in combinations_with_replacement(residues,k):
        action=None
        for i in range(k):
            if gcd(l,*speeds[:i],*speeds[i+1:])>1:
                action=-(i+1);break
        if action is None:
            for m in range(q):
                if all((k+1)*min(m*v%q,q-m*v%q)>=q for v in speeds):
                    action=m;break
        if action is None:failures.append(list(speeds))
        rows.append(action)
    return {'schema':'swc-lonely-modular-cover-v1','k':k,'prime':p,'lift':l,
            'order':'lexicographic combinations with replacement of residues not divisible by p',
            'actions':rows,'uncovered':failures,
            'scope':'all_residue_tuples_modulo_p_times_l',
            'induction_dependency':f'LRC({k-1})',
            'reference':'https://arxiv.org/html/2604.23906v2#S2'}


if __name__=='__main__':
    covers=[produce(3,p,l) for p,l in ((2,4),(3,4),(5,8),(7,4),(11,4))]
    # The failed smaller lift is evidence of why one modular grid is insufficient.
    failed=produce(3,5,4)
    record={'schema':'swc-lonely-modular-pilot-v1','k':3,'covers':covers,
            'failed_grid':failed,'prime_product':prod(c['prime'] for c in covers),
            'product_bound':'1728','status':'known_four_runner_case_reconstruction',
            'source':'https://arxiv.org/html/2604.23906v2'}
    output=Path(__file__).parent/'evidence/swc-lonely-modular-pilot.json'
    output.write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({'covered_orbit_counts':[len(c['actions']) for c in covers],
                      'failed_grid_uncovered_orbits':len(failed['uncovered']),
                      'prime_product':record['prime_product'],'bound':record['product_bound']},indent=2))
