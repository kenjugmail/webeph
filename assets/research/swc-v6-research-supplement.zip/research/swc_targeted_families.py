"""Instantiate the proved family theorem inside all six Mordell-hard classes.

Each row is a parameter instance of the symbolic family identity. It covers
one infinite subprogression, not the entire residue class modulo 840.
"""
import argparse
import json
from math import gcd,lcm
from pathlib import Path
from type_ii_descent_search import sieve


FAMILIES=[
    # hard residue, A, B, h, S0, S step
    (1,2,29,31,11,105),
    (121,41,1,3,11,210),
    (169,23,1,3,11,210),
    (289,19,3,11,5,70),
    (361,17,6,23,3,35),
    (529,85,3,11,3,14),
]


def witness(a,b,h,S):
    Q=(a+b)//h
    n=4*a*b*S-h
    x,y,z=a*b*S,n*a*Q*S,n*b*Q*S
    assert min(n,x,y,z)>0 and 4*x*y*z==n*(x*y+x*z+y*z)
    return n,[x,y,z]


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',type=Path)
    args=parser.parse_args()
    records=[]
    for residue,a,b,h,S0,K in FAMILIES:
        assert (a+b)%h==0 and h%4==3 and min(S0,K)>0
        base,base_witness=witness(a,b,h,S0)
        step=4*a*b*K
        assert base%840==residue and step%840==0 and gcd(base,step)==1
        for t in [0,1,2,13,1000,10**30]:
            n,_=witness(a,b,h,S0+K*t)
            assert n==base+step*t and n%840==residue
        records.append(dict(residue_mod840=residue,base=base,step=step,
                            A=a,B=b,h=h,Q=(a+b)//h,S0=S0,K=K,
                            base_witness=base_witness,accepted_point_mass='1',
                            theorem='swc-family-induction-and-coverage.md'))
    primes,_=sieve(50000)
    uncovered=[]
    for p in primes:
        if p%840 not in {f[0] for f in FAMILIES}:continue
        if not any(p>=r['base'] and (p-r['base'])%r['step']==0 for r in records):
            uncovered.append(p)
    result=dict(status='six_proved_infinite_subfamilies_not_universal_cover',
                families=records,uncovered_examples=uncovered[:12],
                example_census_limit=50000,
                finite_family_exclusion_modulus=lcm(840,*(4*a*b for _,a,b,_,_,_ in FAMILIES)))
    if args.out:args.out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
