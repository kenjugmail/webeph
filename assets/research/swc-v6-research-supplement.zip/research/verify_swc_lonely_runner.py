"""Independent verifier: direct Fraction distances, no producer imports."""
from fractions import Fraction
from itertools import combinations
import json
from pathlib import Path
import sys


def require(ok,message):
    if not ok: raise ValueError(message)


def verify(record):
    require(isinstance(record,dict),'record required')
    require(record.get('schema')=='swc-lonely-grid-v1','unsupported schema')
    speeds=record.get('speeds')
    require(isinstance(speeds,list) and 2<=len(speeds)<=16,'speed list')
    require(all(type(v) is int and 1<=v<=10000 for v in speeds),'integer speeds')
    require(len(set(speeds))==len(speeds),'distinct speeds')
    moduli=sorted({a+b for a,b in combinations(speeds,2)})
    require(sum(moduli)*len(speeds)<=2000000,'work budget')
    require(record.get('scope')=='single_speed_tuple','scope escalation rejected')
    require(record.get('generator')=='uniform_distinct_pair_sum_then_uniform_multiplier','generator mismatch')
    threshold=Fraction(1,len(speeds)+1)
    require(record.get('threshold')==str(threshold),'threshold mismatch')
    expected=[]; total=Fraction(); optimum=Fraction()
    def score(t):
        parts=[t*v-(t*v).__floor__() for v in speeds]
        return min(min(x,1-x) for x in parts)
    for q in moduli:
        scores=[score(Fraction(m,q)) for m in range(q)]
        count=sum(x>=threshold for x in scores)
        optimum=max(optimum,max(scores))
        expected.append({'q':q,'accepted':count})
        total+=Fraction(count,q)
    require(record.get('grids')==expected,'grid count mismatch')
    require(record.get('accepted_mass')==str(total/len(moduli)),'mass mismatch')
    require(record.get('maximum_loneliness')==str(optimum),'optimum mismatch')
    raw=record.get('maximizing_time')
    require(type(raw) is str and len(raw)<100,'time encoding')
    t=Fraction(raw)
    require(0<=t<1 and score(t)==optimum,'maximizer mismatch')
    return {'accepted':total>0,'scope':'single_speed_tuple','mass':str(total/len(moduli))}


if __name__=='__main__':
    print(json.dumps(verify(json.loads(Path(sys.argv[1]).read_text())),indent=2))
