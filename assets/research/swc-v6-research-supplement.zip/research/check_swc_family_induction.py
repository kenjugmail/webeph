"""Exact regressions for the proved family formula and finite-family exclusion.

The symbolic proofs are in swc-family-induction-and-coverage.md. These finite
checks audit arithmetic and examples, and are not proofs of universal coverage.
"""
from math import lcm


def witness(a,b,h,s):
    assert min(a,b,h,s)>0 and (a+b)%h==0
    q=(a+b)//h
    n=4*a*b*s-h
    x,y,z=a*b*s,n*a*q*s,n*b*q*s
    assert n>=2 and min(x,y,z)>0
    assert 4*x*y*z==n*(x*y+x*z+y*z)
    return n,(x,y,z)


def main():
    cases=0
    for a in range(1,31):
        for b in range(1,31):
            for h in range(1,a+b+1):
                if (a+b)%h:
                    continue
                assert 0<1+h<4*a*b
                for s in (1,2,3,13,101,10**12):
                    n,_=witness(a,b,h,s)
                    nn,_=witness(a,b,h,s+1)
                    assert nn-n==4*a*b
                    cases+=1
    for t in (0,1,2,100,10**30):
        n,_=witness(5,1,3,5+6*t)
        assert n==97+120*t and n%24==1
    families=[(5,1,3),(5,2,7),(13,1,7),(23,1,3)]
    modulus=lcm(24,*(4*a*b for a,b,_ in families))
    for j in (0,1,10,10**20):
        n=1+j*modulus
        for a,b,h in families:
            assert (n+h)%(4*a*b)!=0
    print(f'PASS: {cases} exact successor regressions; infinite-family example; finite-family exclusion regressions. Universal prime coverage OPEN.')


if __name__=='__main__':
    main()
