"""Build a union of twelve verified families and two exact instances.
No search or universal cover claim.
"""
import argparse
import json
from pathlib import Path
from swc_certificate_kernel import check,mul,mul2,polynomial2


def rows(poly):
    return [[poly.get((i,j),0) for j in range(max(j for _,j in poly)+1)]
            for i in range(max(i for i,_ in poly)+1)]


def arithmetic_families():
    S=polynomial2([[1,1]])
    for r0 in (3,5,6):
        r=polynomial2([[r0],[7]])
        n=polynomial2([[8*r0-7,8*r0],[56,56]])
        x=mul2({(0,0):2},r,S)
        Q=polynomial2([[1],[2 if r0==3 else 1]])
        if r0==3:b,e=mul2(x,Q),mul2(S,Q)
        elif r0==5:b,e=mul2(r,S,Q),mul2({(0,0):2},S,Q)
        else:b,e=mul2(x,Q),mul2({(0,0):2},S,Q)
        yield dict(id=f'shift7-class-{r0}',op='polynomial_family_2d',n=rows(n),x=rows(x),
                   y=rows(mul2(n,b)),z=rows(mul2(n,e)))
    n=polynomial2([[5,12],[8,16]]);x=polynomial2([[2,3],[3,4]])
    k=polynomial2([[2,4]]);y=mul2(x,k)
    yield dict(id='p-plus-one',op='polynomial_family_2d',n=rows(n),x=rows(x),
               y=rows(y),z=rows(mul2(n,y)))
    n=polynomial2([[5,12],[12,16]]);x=polynomial2([[2,3],[4,4]])
    y=mul2(n,S)
    yield dict(id='p-plus-four',op='polynomial_family_2d',n=rows(n),x=rows(x),
               y=rows(y),z=rows(mul2(x,y)))


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path)
    args=parser.parse_args();base=Path(__file__).parent/'evidence'
    families=json.loads((base/'swc-targeted-families.json').read_text())['families']
    nodes=[];cases=[]
    for i,f in enumerate(families):
        a,b,h=f['A'],f['B'],f['h'];S=[f['S0'],f['K']]
        if (a+b)%h:raise ValueError('nonintegral family parameter')
        Q=(a+b)//h;n=[4*a*b*S[0]-h,4*a*b*S[1]]
        identifier=f'progression-{i}'
        nodes.append(dict(id=identifier,op='polynomial_family',n=n,x=mul([a*b],S),
                          y=mul(n,[a*Q],S),z=mul(n,[b*Q],S)))
        cases.append(identifier)
    double=json.loads((base/'swc-kernel-double-family.json').read_text())['nodes'][0]
    nodes.append(double);cases.append(double['id'])
    for f in arithmetic_families():nodes.append(f);cases.append(f['id'])
    for p,w in [(73,[20,292,730]),(8803369,[2200869,181085300330,3293760527702370])]:
        identifier=f'instance-{p}'
        nodes.append(dict(id=identifier,op='finite_mass',n=p,outcomes=[dict(weight='1',candidate=w)]))
        cases.append(identifier)
    nodes.append(dict(id='combined-cases',op='case_union',cases=cases))
    certificate=dict(schema='swc-kernel-v1',root='combined-cases',nodes=nodes)
    result=check(certificate)
    if args.out:args.out.write_text(json.dumps(certificate,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
