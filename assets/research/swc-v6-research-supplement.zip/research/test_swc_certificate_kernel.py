"""Small adversarial tests for the SWC compositional kernel."""
import copy
import json
from pathlib import Path
import unittest
from swc_certificate_kernel import check


def instance(n=33):
    return dict(schema='swc-kernel-v1',root='seed',nodes=[
        dict(id='seed',op='finite_mass',n=n,outcomes=[
            dict(weight='1/2',candidate=[10,66,165]),dict(weight='1/2',candidate=None)])])


def family():
    return dict(schema='swc-kernel-v1',root='family',nodes=[
        dict(id='family',op='polynomial_family',n=[97,120],x=[25,30],
             y=[970,2364,1440],z=[4850,11820,7200])])


def composed():
    c=instance();c['nodes'] += [
        dict(id='lift',op='transport',parent='seed',anchor=10,scale=2),
        dict(id='other',op='finite_mass',n=73,outcomes=[dict(weight='1',candidate=[21,146,3066])]),
        dict(id='mix',op='mixture',components=[dict(node='lift',weight='1/4'),dict(node='other',weight='3/4')])]
    c['root']='mix';return c


class KernelTests(unittest.TestCase):
    def test_combined_saved_certificate(self):
        c=json.loads((Path(__file__).parent/'evidence'/'swc-combined-cases.json').read_text())
        r=check(c)
        self.assertEqual(len(r['covered_domains']),14)
        self.assertEqual(r['scope'],'union_of_verified_domains')
        self.assertEqual(r['universal_prime_coverage'],'not_established')
    def test_case_union_keeps_actual_domains(self):
        c=family();c['nodes']+=instance()['nodes']
        c['nodes'].append(dict(id='cases',op='case_union',cases=['family','seed']));c['root']='cases'
        r=check(c);self.assertEqual(r['scope'],'union_of_verified_domains')
        self.assertEqual(len(r['covered_domains']),2)
        self.assertEqual(r['universal_prime_coverage'],'not_established')
    def test_case_union_rejects_zero_mass_case(self):
        c=instance(73);c['nodes'].append(dict(id='cases',op='case_union',cases=['seed']));c['root']='cases'
        with self.assertRaises(ValueError):check(c)
    def test_case_union_rejects_forged_cover(self):
        c=family();c['nodes'].append(dict(id='cases',op='case_union',cases=['family'],covers='all primes'));c['root']='cases'
        with self.assertRaises(ValueError):check(c)
    def double_family(self):
        return json.loads((Path(__file__).parent/'evidence'/'swc-kernel-double-family.json').read_text())
    def test_double_family_symbolic_identity(self):
        r=check(self.double_family())
        self.assertEqual(r['scope'],'bivariate_polynomial_family')
        self.assertEqual(r['parameters'],['u','v'])
    def test_double_family_specialization(self):
        for u,v in [(0,0),(1,4),(17,23),(10**12,10**12)]:
            c=self.double_family()
            c['nodes'].append(dict(id='at',op='instantiate_2d',family='double-family',u=u,v=v));c['root']='at'
            r=check(c);self.assertEqual(r['n'],12*u*v+12*u+8*v+5)
            self.assertEqual(r['accepted_mass'],'1')
    def test_double_family_mixed_term_tampering(self):
        c=self.double_family();c['nodes'][0]['n'][1][1]+=1
        with self.assertRaises(ValueError):check(c)
    def test_double_family_negative_parameter(self):
        c=self.double_family();c['nodes'].append(dict(id='at',op='instantiate_2d',family='double-family',u=-1,v=0));c['root']='at'
        with self.assertRaises(ValueError):check(c)
    def test_double_family_scope_cannot_be_promoted(self):
        c=self.double_family();c['nodes'][0]['covers_all_primes']=True
        with self.assertRaises(ValueError):check(c)
    def test_mass_and_transport(self):
        c=composed();result=check(c)
        self.assertEqual((result['n'],result['accepted_mass']),(73,'7/8'))
        self.assertTrue(result['existence_proved'])
    def test_failed_candidates_remain_zero(self):
        c=instance(73);r=check(c)
        self.assertEqual(r['accepted_mass'],'0');self.assertFalse(r['existence_proved'])
    def test_family_identity_is_symbolic(self):
        r=check(family());self.assertEqual(r['scope'],'polynomial_family')
        self.assertEqual(r['n_coefficients'],[97,120])
    def test_family_instantiation(self):
        c=family();c['nodes'].append(dict(id='at',op='instantiate',family='family',t=10**20));c['root']='at'
        r=check(c);self.assertEqual(r['n'],97+120*10**20);self.assertEqual(r['accepted_mass'],'1')
    def test_false_symbolic_identity_rejected(self):
        c=family();c['nodes'][0]['z'][1]+=1
        with self.assertRaises(ValueError):check(c)
    def test_unproved_polynomial_positivity_rejected(self):
        c=family();c['nodes'][0]['x'][1]=-30
        with self.assertRaises(ValueError):check(c)
    def test_forged_universal_scope_rejected(self):
        c=family();c['claim']='all primes'
        with self.assertRaises(ValueError):check(c)
    def test_target_mismatch_rejected(self):
        c=composed();c['nodes'][2]['n']=97
        with self.assertRaises(ValueError):check(c)
    def test_wrong_anchor_rejected(self):
        c=composed();c['nodes'][1]['anchor']=11
        with self.assertRaises(ValueError):check(c)
    def test_nonintegral_lift_rejected(self):
        c=instance();c['nodes'][0]['n']=5;c['nodes'][0]['outcomes']=[dict(weight='1',candidate=[2,4,20])]
        c['nodes'].append(dict(id='lift',op='transport',parent='seed',anchor=2,scale=2));c['root']='lift'
        with self.assertRaises(ValueError):check(c)
    def test_cyclic_proof_rejected(self):
        c=composed();c['nodes'][1]['parent']='mix'
        with self.assertRaises(ValueError):check(c)
    def test_bad_probabilities_rejected(self):
        for weight in ['-1/2','0.5','2/3',0.5]:
            c=instance();c['nodes'][0]['outcomes'][0]['weight']=weight
            with self.subTest(weight=weight),self.assertRaises(ValueError):check(c)
    def test_duplicate_ids_rejected(self):
        c=instance();c['nodes'].append(copy.deepcopy(c['nodes'][0]))
        with self.assertRaises(ValueError):check(c)
    def test_scope_mismatch_rejected(self):
        c=family();c['nodes'].append(dict(id='mix',op='mixture',components=[dict(node='family',weight='1')]))
        c['root']='mix'
        with self.assertRaises(ValueError):check(c)
    def test_proof_hash_binds_weights(self):
        a=instance();b=copy.deepcopy(a)
        b['nodes'][0]['outcomes'][0]['weight']='1/3';b['nodes'][0]['outcomes'][1]['weight']='2/3'
        self.assertNotEqual(check(a)['proof_sha256'],check(b)['proof_sha256'])


if __name__=='__main__':unittest.main()
