#!/usr/bin/env python3
"""Exact finite search for witness-preserving Type-II parent transformations.

This is a conjecture-discovery tool, not a proof of universal coverage.  For a
target prime ``p`` it searches for integers ``L >= 2`` and ``c == 3 (mod 4)``
such that

    x = (p + c) / (4L),        q = 4x - c < p,

and a divisor ``d | x^2`` satisfies ``d == -x (mod c)``.  The divisor gives a
Type-II witness for q, and the scaling lemma transports it to p:

    4/q = 1/x + 1/(q b) + 1/(q e)
      =>
    4/p = 1/(Lx) + 1/(Lp b) + 1/(Lp e),

where p = q + 4(L-1)x.
"""

from __future__ import annotations

import argparse
import json
import math
from collections import Counter
from pathlib import Path


def sieve(limit: int) -> tuple[list[int], list[int]]:
    spf = list(range(limit + 1))
    if limit >= 1:
        spf[1] = 1
    for n in range(2, int(limit**0.5) + 1):
        if spf[n] == n:
            for multiple in range(n * n, limit + 1, n):
                if spf[multiple] == multiple:
                    spf[multiple] = n
    primes = [n for n in range(2, limit + 1) if spf[n] == n]
    return primes, spf


def square_divisors(n: int, spf: list[int]) -> list[int]:
    factors: list[tuple[int, int]] = []
    value = n
    while value > 1:
        prime = spf[value]
        exponent = 0
        while value % prime == 0:
            value //= prime
            exponent += 1
        factors.append((prime, 2 * exponent))

    divisors = [1]
    for prime, exponent in factors:
        powers = [1]
        for _ in range(exponent):
            powers.append(powers[-1] * prime)
        divisors = [d * power for d in divisors for power in powers]
    return sorted(divisors)


def verifies(n: int, x: int, y: int, z: int) -> bool:
    return min(n, x, y, z) > 0 and 4 * x * y * z == n * (x * y + x * z + y * z)


def find_parent(
    p: int,
    spf: list[int],
    max_c: int,
    max_scale: int,
) -> dict[str, int] | None:
    for c in range(3, min(max_c, p - 1) + 1, 4):
        for scale in range(2, max_scale + 1):
            numerator = p + c
            if numerator % (4 * scale):
                continue
            x = numerator // (4 * scale)
            q = 4 * x - c
            if q < 2 or q >= p:
                continue
            for d in square_divisors(x, spf):
                if (d + x) % c:
                    continue
                complement = x * x // d
                if (complement + x) % c:
                    raise AssertionError("complementary divisor lost the congruence")
                b = (x + d) // c
                e = (x + complement) // c
                parent_y, parent_z = q * b, q * e
                child_x = scale * x
                child_y, child_z = scale * p * b, scale * p * e
                if not verifies(q, x, parent_y, parent_z):
                    raise AssertionError("invalid parent witness")
                if not verifies(p, child_x, child_y, child_z):
                    raise AssertionError("invalid transported witness")
                common = math.gcd(x, d)
                primitive_a = x // common
                primitive_b = d // common
                unused = common * common // d
                primitive_q = 4 * primitive_a * primitive_b - c
                return {
                    "p": p,
                    "q": q,
                    "scale": scale,
                    "shift": c,
                    "parent_x": x,
                    "divisor": d,
                    "parent_b": b,
                    "parent_e": e,
                    "child_x": child_x,
                    "child_y": child_y,
                    "child_z": child_z,
                    "primitive_a": primitive_a,
                    "primitive_b": primitive_b,
                    "primitive_unused_factor": unused,
                    "primitive_q": primitive_q,
                    "total_scale": scale * unused,
                }
    return None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit", type=int, default=1_000_000)
    parser.add_argument("--max-c", type=int, default=511)
    parser.add_argument("--max-scale", type=int, default=16)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()

    primes, spf = sieve(args.limit + args.max_c)
    targets = [p for p in primes if p <= args.limit and p % 24 == 1]
    records: list[dict[str, int]] = []
    misses: list[int] = []
    for p in targets:
        record = find_parent(p, spf, args.max_c, args.max_scale)
        if record is None:
            misses.append(p)
        else:
            records.append(record)

    result = {
        "status": "finite_conjecture_search_only",
        "limit": args.limit,
        "max_shift": args.max_c,
        "max_scale": args.max_scale,
        "targets": len(targets),
        "covered_by_strict_parent": len(records),
        "miss_count": len(misses),
        "first_misses": misses[:100],
        "scale_histogram": dict(sorted(Counter(r["scale"] for r in records).items())),
        "shift_histogram": dict(sorted(Counter(r["shift"] for r in records).items())),
        "largest_parent_ratio": max((r["q"] / r["p"] for r in records), default=None),
        "sample_records": records[:25],
    }
    payload = json.dumps(result, indent=2, sort_keys=True)
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(payload + "\n", encoding="utf-8")
    print(payload)


if __name__ == "__main__":
    main()
