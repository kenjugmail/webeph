# More exact SWC witness masses

Date: 2026-09-05. Scope: exploratory comparison on eight previously studied
primes. All reported masses are computed exactly; decimal percentages are for
readability. No universal positivity or out-of-sample performance is claimed.

## Common witness space and decoder

For each prime p, choose h in {3,7,...,179}, put C=(p+h)/4, and factor
C=product r_i^e_i. Each exponent z_i lies in [-e_i,e_i]. The candidate is
the residue R=product r_i^z_i modulo h, and the exact divisor is
d=product r_i^(e_i+z_i), so d|C^2.

Every method uses exactly the same two targets: R=-1 or R=-p^{-1} modulo h.
The comparison does not grant an additional inverse target to only one method.
An accepted seed is reconstructed through the rectangle identity and checked
using 4xyz=p(xy+xz+yz) in arbitrary-precision integers.

## Distributions

Each local exponent weight is divided by its sum over -e,...,e.

| Name | Local exponent weight or selection rule |
|---|---|
| Uniform baseline | Every exponent has weight 1; shifts uniform |
| Central triangular | e+1-abs(z) |
| Edge weighted | 1+abs(z) |
| Binomial | binomial(2e,e+z) |
| Residue balanced | Choose a reachable residue uniformly, then a seed in its preimage uniformly |
| Half uniform, half balanced | Equal mixture of the preceding baseline and balanced distributions |
| Inverse shift | Shift weight 1/h; exponents uniform |
| Half baseline, half inverse balanced | Equal mixture of baseline and inverse-shift balanced sampling |
| Linear shift | Shift weight h; exponents uniform |
| Half baseline, half linear shift | Equal mixture of baseline and linear-shift sampling |

The first four are independent product distributions over exponents.
Residue balancing is a correlated distribution; its normalization accounts
for the number of seeds mapping to each residue. Changing weights leaves
all candidate exponents within their actual prime-power budgets.

All local weights are strictly positive. In particular, for a half-baseline
mixture and any event E,

    mu_mix(E) >= mu_baseline(E)/2.

This is a proved support-preservation floor, not a guarantee of improvement.
None of these proposals creates a solution in a witness space with no solution.

## Results

The panel is p=1009,118801,496609,532249,806521,2458369,8803369,22605361.
All eight have 45 shifts in the common range. The rules are exploratory;
linear-shift weighting was added after inspecting the initial comparison.
This is a retrospective difficult-case panel, not a held-out benchmark.

| Proposal | Better / equal / worse than baseline on eight primes |
|---|---|
| Central triangular | 1 / 0 / 7 |
| Edge weighted | 3 / 0 / 5 |
| Binomial | 1 / 0 / 7 |
| Residue balanced | 1 / 0 / 7 |
| Half uniform, half balanced | 1 / 0 / 7 |
| Inverse shift | 1 / 0 / 7 |
| Half baseline, half inverse balanced | 1 / 0 / 7 |
| Linear shift | 5 / 0 / 3 |
| Half baseline, half linear shift | 5 / 0 / 3 |

No proposal dominates. Central weighting often suppresses the exponent
combinations needed by this panel. Emphasizing late shifts can help some
difficult cases while hurting ones with effective early shifts.

For p=8803369:

| Proposal | Exact accepted mass per draw | Percentage |
|---|---|---:|
| Uniform baseline | 1469/820125 | 0.179119% |
| Edge weighted | 3208/1134375 | 0.282799% |
| Linear shift | 209723/74631375 | 0.281012% |
| Half baseline, half linear shift | 171701/74631375 | 0.230065% |

Edge weighting improves this instance by approximately 1.579 times. These
are probabilities of drawing valid witnesses over the full 45-shift mixture,
not probabilities that the conjecture is true or masses at a single shift.

## Verification and computational limits

For each of 8 primes, 45 shifts and 4 product modes, residue convolution is
compared with a separate enumeration of exponent vectors: 1440 comparisons.
All 848 accepted seed/mode occurrences are reconstructed and checked exactly.
Every local normalization and the half-baseline support floors are checked.
All rational results and ratios are retained in the JSON artifact.

Exact mass evaluation in this prototype uses factorization and enumeration.
Higher per-draw success does not establish a lower end-to-end computation cost,
and residue balancing can cost more to prepare than a simple product sampler.

Reproduce:

    python3 -B research/swc_proposal_comparison.py --out research/evidence/swc-proposal-comparison.json

This adds nine alternatives to the uniform baseline. It supplies more exact
finite SWC masses while preserving the universal existence question as open.
