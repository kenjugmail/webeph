# Probabilistic descent: verified small model and universal obligation

2026-09-05. Outcome: exact drift certificate for p=73. The universal
Erdős–Straus assertion is not established. Computation used 36 states, without
a large prime sweep.

## Distinguishing the proof goal from the search position

The goal is E(p): a positive integer witness for 4/p exists. A state records
a current anchor x, but does not assert that the solution must use this x.
Changing the anchor preserves E(p), although it does not preserve the stronger
claim E(p,x). This avoids the false step of transforming a failed fixed-anchor
claim directly into a true one at another anchor.

At any accepted terminal anchor we retain an exact witness for E(p). No
witness transport is needed between search positions because the target p
does not change. If auxiliary-number transitions are added later, those still
need the earlier verified witness transformers.

## Finite chain

Use the canonical anchor range floor(p/4)+1 through floor(3p/4), indexing
positions 0,...,N-1. At each nonterminal position move left or right with
equal probability. At the endpoints, a move out of the interval stays put.
At a terminal position stay there and retain its witness.

Every terminal is certified by positive integers satisfying
4xyz=p(xy+xz+yz). A search position is not declared terminal merely because
its potential is small.

For p=73 the interval has N=36 positions. Certified accepting anchors are
20,21,22. In particular, anchor 25 fails its direct test but can move to
a successful anchor while retaining the original existential goal.

## Drift certificate

Let G be a nonempty set of indices with verified terminal witnesses. Define
V=0 on G. Between neighboring terminals a<b, put

    V(i)=(i-a)(b-i).

Before the first terminal g, put

    V(i)=g(g+1)-i(i+1).

After the last terminal g, put L=N-1-g and j=N-1-i, and define

    V(i)=L(L+1)-j(j+1).

These nonnegative integer formulas satisfy

    V(i) - E[V(next position) | i] = 1

at every nonterminal position, including the reflecting endpoints.
This follows by substitution into the two neighbor values. Individual
steps may increase V; only its conditional expected change is constrained.

Let T be the first terminal hitting time, and let V remain zero afterward.
Taking expectations in the drift inequality and summing to time t gives

    sum_{k=0}^{t-1} Pr(T>k) <= V(start)-E[V(position_t)] <= V(start).

By monotone convergence, E[T]<=V(start). No prior assumption E[T]<infinity
is used in that derivation. Markov's inequality then gives

    Pr(T <= 2V(start)) >= 1/2

for a nonterminal start. Uniform random choices for that finite number of
moves form an SWC seed distribution. Every accepted path emits the stored
terminal witness, so its accepted mass is rigorously at least 1/2.

This is an elementary finite-state application of additive drift; see
[Kötzing–Krejca](https://arxiv.org/abs/1805.09415) for general drift theorems.

## Concrete arithmetic verification

At p=73 and start anchor 25, V(start)=186. The proof gives a success
lower bound 1/2 within 372 moves. An exact integer path-count calculation
gives success probability approximately 0.8773002486994482.
The JSON artifact retains the full exact rational probability.

The checker verifies each terminal witness, every drift inequality, probability
normalization, and the finite-horizon success bound. It rejects an empty
terminal set. This is an arithmetic implementation, not a formal
proof-assistant development.

## Why this does not yet imply universal positivity

The potential above depends on a nonempty verified terminal set G.
Constructing G for a fixed prime by direct search is valid. Assuming G is
nonempty for every prime would assume the missing universal claim.

For this finite-state approach, the gap is unavoidable at the formulation
level: if there were no terminal states, choose a state where a putative
potential V is minimal. Every successor has V at least that minimum, so

    V(i)-E[V(next)|i] <= 0.

This contradicts a strictly positive drift requirement. More generally, a
closed communicating class containing only uncertified states prevents such
a drift certificate.

Therefore the probabilistic-descent route needs arithmetic input excluding
all such failed classes for arbitrary p, or an explicit potential and sound
transition system whose inequalities can be proved without using an
unproved nonempty-target assumption. The small model establishes neither.

This attempt verifies that average descent can recover from failed search
positions. It does not prove that every prime has a reachable successful
position. No universal proof is claimed.

Reproduce the small calculation:

    python3 -B research/swc_drift_probe.py --out research/evidence/swc-drift-probe.json
