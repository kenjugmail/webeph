# Recursive induction with the required first denominator

2026-09-05. Status: terminating recursive certificate builder and soundness
argument; successful certificates for the recorded examples. Universal success
for every prime remains unproved.

## The induction predicate

Use P(n,x), not merely P(n):

    P(n,x): there exist positive integers b,e with
            4/n = 1/x + 1/(nb) + 1/(ne).

The first denominator x must be part of the state. A proof that n has some
other witness need not supply a witness compatible with the next transform.
For example, P(73,20) and P(73,21) hold, whereas P(73,25) fails.

## Recursive step

Given n,x with h=4x-n>0, choose a divisor L>=2 of x and set

    x' = x/L,
    q = 4x'-h = n-4(x-x').

If q>=2 and P(q,x') returns b',e', then

    b=L b', e=L e'

prove P(n,x). This is the previously derived exact scaling identity. It
preserves h. Both x'<x and q<n, and in fact q<n/2. Nested calls therefore
terminate under integer rank x. The number of divisions is at most
floor(log_2 x).

At a direct leaf, search for d|x^2 satisfying

    h | x+d, and h | x+x^2/d.

Set b=(x+d)/h and e=(x+x^2/d)/h, then check the integer identity. If no
such d and no successful recursive branch exist, return no certificate for
this fixed state. A termination theorem guarantees that the algorithm returns;
it does not guarantee that it returns a successful certificate.

## Concrete nested path for the hardest earlier prime

The recursive certificate produced is

    (n,x) = (8803369,2200869)
         -> (800209,200079)       L=11
         -> (72649,18189)         L=11
         -> direct exact leaf.

Every state has h=107. At the leaf,

    b=170, e=3092130.

Lifting twice multiplies b and e by 121, giving

    x=2200869,
    y=181085300330,
    z=3293760527702370

for n=8803369. Exact cross multiplication verifies the leaf, intermediate,
and final identities. The other recorded paths include

    (1249,315) -> (409,105) -> (73,21),
    (118801,29715) -> (39561,9905) -> (5601,1415).

These paths demonstrate why retaining x matters: calling an arbitrary solver
for 73 might return first denominator 20, whereas the 1249 path needs 21.

## SWC interpretation and soundness

Place a point mass on each directly checked leaf witness. Its accepted mass
is 1. Each recursive edge pushes this measure through the displayed sound
transform, so the accepted mass remains 1 at the parent. Well-founded induction
on x establishes soundness of every returned certificate tree. Direct-leaf
identities are the base cases; no unchecked leaf is treated as proved.

The implementation checks every returned tree separately by the original
integer equation, and compares successful/failed results with direct fixed-state
divisor tests for small n. This is an executable arithmetic checker, not a
Lean or other proof-assistant formalization.

## What still prevents a universal conclusion

To prove the original conjecture we need to establish that every prime p has
at least one initial x whose recursion returns a certificate. The usual
least-denominator bound supplies a finite complete range for the full
Erdős–Straus search, but this implementation restricts to Type-II witnesses.
Proving it succeeds for all primes would establish the stronger all-prime
Type-II assertion. General Type-I leaves or other sound transforms could be
added without weakening the checker, but their universal coverage would still
need a proof.

Thus the recursive loop and its rank are concrete and checked. The assertion
that some initial state always succeeds remains the missing theorem. The
loop does not assume it.

Reproduce:

    python3 -B research/swc_recursive_anchor.py --out research/evidence/swc-recursive-anchor.json

## Further attempt: descend a hypothetical failure

For every eligible parent (q,x/L), soundness gives

    not P(n,x) implies not P(q,x/L).

This contrapositive is valid. It does not guarantee that any eligible parent
exists. At (n,x)=(73,19), h=3, the only nontrivial divisor L of x is 19,
giving q=1, outside the domain. The state fails its direct test and has no
recursive parent. Nevertheless, 73 is solved at x=20.

A more instructive chain is

    (193,49) -> (25,7), with h=3 and L=7.

Both states fail the direct test, and the latter has no eligible parent.
The number 25 has the ordinary solution (10,25,50). That solution has the
wrong first denominator for this edge.

There is an additional induction-domain issue. In this implementation,
P(n,x) denotes the displayed n-multiple denominator shape. For composites
it does not automatically impose the standard Type-II condition gcd(n,x)=1.
Any ancestor of a prime child under the scaling rule must satisfy gcd(q,x)=1:
a common divisor would divide the child q+4(L-1)x. Thus strengthening the
induction premise to primitive witnesses for every smaller integer is false.

The number 25 is a finite counterexample to that strengthened premise.
Any solution of the displayed shape satisfies

    4 = 25/x + 1/b + 1/e,

so 25/4 < x <= 25/2. The possible integral anchors are 7,...,12. The
primitive anchors are 7,8,9,11,12. For each, the target -x modulo h=4x-25
is absent among divisors of x^2:

| x | h | Required divisor residue |
|--:|--:|--:|
| 7 | 3 | 2 |
| 8 | 7 | 6 |
| 9 | 11 | 2 |
| 11 | 19 | 8 |
| 12 | 23 | 11 |

The anchor 10 does work, but gcd(25,10)=5, so its scaling descendants are
all divisible by 5. It cannot supply a prime child. These assertions were
checked by exact divisor enumeration and rational identities.

This rules out two proposed closures of the present loop: every failed state
has a smaller failed parent; and every smaller integer supplies a primitive
parent witness. Neither refutes Erdős–Straus. A successful universal argument
still needs an additional rule to move between anchors or witness types, with
proved coverage and a decreasing rank. Such a rule has not been established.
