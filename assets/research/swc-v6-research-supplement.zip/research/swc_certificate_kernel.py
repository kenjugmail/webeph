"""Small exact SWC certificate kernel for instances, mixtures, transport and
polynomial families. Uses only the Python standard library; no search or eval.

The scope of the conclusion is computed by the checker, never supplied as a
trusted 'proved' flag. This prototype is not a proof-assistant formalization.
"""
from fractions import Fraction
import hashlib
import json
import re


def require(test,message):
    if not test:raise ValueError(message)


def integer(value,minimum=0):
    require(type(value) is int and value>=minimum and value.bit_length()<=4096,'invalid or oversized integer')
    return value


def rational(value):
    require(type(value) is str and len(value)<=1024 and re.fullmatch(r'-?\d+(?:/[1-9]\d*)?',value),'exact rational string required')
    return Fraction(value)


def witness(n,w):
    if w is None:return False
    require(type(w) in (list,tuple) and len(w)==3,'three denominators required')
    for d in w:integer(d,1)
    x,y,z=w
    return 4*x*y*z==n*(x*y+x*z+y*z)


def trim(poly):
    p=list(poly)
    while len(p)>1 and p[-1]==0:p.pop()
    return p


def add(*polys):
    out=[0]*max(map(len,polys))
    for p in polys:
        for i,c in enumerate(p):out[i]+=c
    return trim(out)


def mul(*polys):
    out=[1]
    for p in polys:
        nxt=[0]*(len(out)+len(p)-1)
        for i,a in enumerate(out):
            for j,b in enumerate(p):nxt[i+j]+=a*b
        out=trim(nxt)
    return out


def polynomial(value,constant_minimum=1):
    require(type(value) is list and 1<=len(value)<=9,'polynomial needs 1..9 coefficients')
    for c in value:integer(c)
    require(value[0]>=constant_minimum,'positivity not established for all t>=0')
    return trim(value)


def evaluate(poly,t):
    out=0
    for coefficient in reversed(poly):out=out*t+coefficient
    return out


def polynomial2(rows,constant_minimum=1):
    require(type(rows) is list and 1<=len(rows)<=9,'two-variable degree budget exceeded')
    out={}
    for i,row in enumerate(rows):
        require(type(row) is list and 1<=len(row)<=9,'invalid coefficient row')
        for j,c in enumerate(row):
            integer(c)
            if c:out[i,j]=c
    require(out.get((0,0),0)>=constant_minimum,'family positivity not proved')
    return out


def add2(*polys):
    out={}
    for p in polys:
        for ij,c in p.items():out[ij]=out.get(ij,0)+c
    return {ij:c for ij,c in out.items() if c}


def mul2(*polys):
    out={(0,0):1}
    for p in polys:
        nxt={}
        for (i,j),a in out.items():
            for (k,l),b in p.items():nxt[i+k,j+l]=nxt.get((i+k,j+l),0)+a*b
        out={ij:c for ij,c in nxt.items() if c}
    return out


def evaluate2(poly,u,v):return sum(c*u**i*v**j for (i,j),c in poly.items())


def check(certificate):
    require(set(certificate)=={'schema','nodes','root'},'unexpected top-level claim or field')
    require(certificate['schema']=='swc-kernel-v1','unsupported schema')
    nodes=certificate['nodes']
    require(type(nodes) is list and 1<=len(nodes)<=128,'node budget exceeded')
    table={node['id']:node for node in nodes}
    require(len(table)==len(nodes),'duplicate node')
    memo={};active=set()

    def visit(identifier,depth=0):
        require(identifier in table,'missing proof dependency')
        require(depth<=32 and identifier not in active,'cycle or depth budget exceeded')
        if identifier in memo:return memo[identifier]
        active.add(identifier);node=table[identifier];op=node['op']
        if op=='finite_mass':
            require(set(node)=={'id','op','n','outcomes'},'unexpected finite-mass fields')
            n=integer(node['n'],2);cases=node['outcomes']
            require(type(cases) is list and 1<=len(cases)<=256,'outcome budget exceeded')
            outputs=[]
            for case in cases:
                require(set(case)=={'weight','candidate'},'unexpected outcome fields')
                w=rational(case['weight']);require(w>=0,'negative probability')
                valid=witness(n,case['candidate'])
                outputs.append((tuple(case['candidate']) if valid else None,w))
            require(sum(w for _,w in outputs)==1,'distribution not normalized')
            result=dict(kind='instance',n=n,outputs=outputs)
        elif op=='mixture':
            require(set(node)=={'id','op','components'},'unexpected mixture fields')
            parts=node['components'];require(type(parts) is list and 1<=len(parts)<=128,'component budget exceeded')
            outputs=[];total=Fraction();n=None
            for part in parts:
                require(set(part)=={'node','weight'},'unexpected component fields')
                weight=rational(part['weight']);require(weight>=0,'negative mixture probability')
                child=visit(part['node'],depth+1)
                require(child['kind']=='instance','instantiate a family before mixing it')
                if n is None:n=child['n']
                require(child['n']==n,'cannot mix evidence for different targets')
                total+=weight;outputs.extend((w,p*weight) for w,p in child['outputs'])
            require(total==1,'mixture not normalized')
            result=dict(kind='instance',n=n,outputs=outputs)
        elif op=='transport':
            require(set(node)=={'id','op','parent','anchor','scale'},'unexpected transport fields')
            parent=visit(node['parent'],depth+1)
            require(parent['kind']=='instance','transport requires an instance')
            q=parent['n'];a=integer(node['anchor'],1);L=integer(node['scale'],2)
            n=integer(q+4*(L-1)*a,2);outputs=[]
            for w,p in parent['outputs']:
                if w is None or p==0:outputs.append((None,p));continue
                x,y,z=w
                require(x==a,'parent first denominator incompatible with target')
                require((L*n*y)%q==0 and (L*n*z)%q==0,'transport denominators not integral')
                mapped=(L*x,L*n*y//q,L*n*z//q)
                require(witness(n,mapped) and 2*q<n,'invalid witness transport or rank')
                outputs.append((mapped,p))
            result=dict(kind='instance',n=n,outputs=outputs)
        elif op=='polynomial_family':
            require(set(node)=={'id','op','n','x','y','z'},'unexpected family claim or fields')
            n=polynomial(node['n'],2)
            x,y,z=(polynomial(node[k]) for k in ('x','y','z'))
            require(len(n)>1,'family target must be nonconstant')
            require(mul([4],x,y,z)==mul(n,add(mul(x,y),mul(x,z),mul(y,z))),'polynomial identity does not hold')
            result=dict(kind='family',n=n,x=x,y=y,z=z)
        elif op=='polynomial_family_2d':
            require(set(node)=={'id','op','n','x','y','z'},'unexpected two-variable claim')
            n=polynomial2(node['n'],2)
            x,y,z=(polynomial2(node[k]) for k in ('x','y','z'))
            require(any(i or j for i,j in n),'family target must vary')
            require(mul2({(0,0):4},x,y,z)==mul2(n,add2(mul2(x,y),mul2(x,z),mul2(y,z))),'two-variable identity failed')
            result=dict(kind='family2',n=n,x=x,y=y,z=z)
        elif op=='instantiate_2d':
            require(set(node)=={'id','op','family','u','v'},'unexpected two-variable instantiation fields')
            family=visit(node['family'],depth+1);u=integer(node['u']);v=integer(node['v'])
            require(u.bit_length()<=256 and v.bit_length()<=256,'instantiation budget exceeded')
            require(family['kind']=='family2','not a two-variable family')
            n=evaluate2(family['n'],u,v);w=tuple(evaluate2(family[k],u,v) for k in ('x','y','z'))
            require(witness(n,w),'two-variable instantiation failed')
            result=dict(kind='instance',n=n,outputs=[(w,Fraction(1))])
        elif op=='instantiate':
            require(set(node)=={'id','op','family','t'},'unexpected instantiation fields')
            family=visit(node['family'],depth+1);t=integer(node['t'])
            require(t.bit_length()<=256,'instantiation budget exceeded')
            require(family['kind']=='family','not a family certificate')
            n=evaluate(family['n'],t);w=tuple(evaluate(family[k],t) for k in ('x','y','z'))
            require(witness(n,w),'family instantiation failed')
            result=dict(kind='instance',n=n,outputs=[(w,Fraction(1))])
        elif op=='case_union':
            require(set(node)=={'id','op','cases'},'unexpected coverage assertion')
            cases=node['cases'];require(type(cases) is list and 1<=len(cases)<=128,'case budget exceeded')
            domains=[]
            for case_id in cases:
                child=visit(case_id,depth+1)
                if child['kind']=='instance':
                    m=sum((p for w,p in child['outputs'] if w is not None),Fraction())
                    require(m>0,'zero-mass case proves no existence')
                    domains.append(dict(kind='single_integer',n=child['n'],accepted_mass=str(m)))
                elif child['kind']=='family':
                    domains.append(dict(kind='polynomial_family',n_coefficients=child['n'],domain='integers t>=0'))
                elif child['kind']=='family2':
                    domains.append(dict(kind='bivariate_polynomial_family',domain='integers u,v>=0',
                                        n_terms=[dict(u_power=i,v_power=j,coefficient=c) for (i,j),c in sorted(child['n'].items())]))
                else:domains.extend(child['domains'])
                require(len(domains)<=128,'combined coverage budget exceeded')
            result=dict(kind='union',domains=domains)
        else:raise ValueError('unknown proof rule')
        if result['kind']=='instance':
            # Merge coincident outcomes to keep compositional DAGs compact.
            merged={}
            for w,p in result['outputs']:merged[w]=merged.get(w,Fraction())+p
            require(len(merged)<=256,'composed outcome budget exceeded')
            result['outputs']=list(merged.items())
        memo[identifier]=result;active.remove(identifier)
        return result

    result=visit(certificate['root'])
    digest=hashlib.sha256(json.dumps(certificate,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    if result['kind']=='instance':
        mass=sum((p for w,p in result['outputs'] if w is not None),Fraction())
        return dict(scope='single_integer',n=result['n'],accepted_mass=str(mass),
                    existence_proved=mass>0,proof_sha256=digest,verified_nodes=len(memo))
    if result['kind']=='union':
        return dict(scope='union_of_verified_domains',covered_domains=result['domains'],
                    conclusion='existence for every integer in the displayed union',
                    universal_prime_coverage='not_established',
                    proof_sha256=digest,verified_nodes=len(memo))
    if result['kind']=='family2':
        return dict(scope='bivariate_polynomial_family',parameters=['u','v'],
                    domain='integers u,v>=0',accepted_mass='1',
                    n_terms=[dict(u_power=i,v_power=j,coefficient=c) for (i,j),c in sorted(result['n'].items())],
                    conclusion='existence for every n(u,v) in the displayed family',
                    proof_sha256=digest,verified_nodes=len(memo))
    return dict(scope='polynomial_family',parameter='t',domain='integers t>=0',
                n_coefficients=result['n'],accepted_mass='1',
                conclusion='existence for every n(t) in the displayed family',
                proof_sha256=digest,verified_nodes=len(memo))


if __name__=='__main__':
    import argparse
    from pathlib import Path
    parser=argparse.ArgumentParser()
    parser.add_argument('certificate',type=Path)
    args=parser.parse_args()
    print(json.dumps(check(json.loads(args.certificate.read_text())),indent=2))
