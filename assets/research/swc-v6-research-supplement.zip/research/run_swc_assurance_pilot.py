"""Generate a finite certificate and a fresh, fixed-horizon lab evaluation.

Inputs are mathematical speed tuples, not physical measurements. This program
freezes the plan before drawing from SystemRandom. It is a single evaluation;
existing evidence is not overwritten. No outcome-dependent sample selection.
"""
from datetime import datetime,timezone
from fractions import Fraction
from pathlib import Path
from random import SystemRandom
import argparse
import hashlib
import json
import time

from swc_canonical_pair import complete_witness_search
from swc_assurance import (receipt,verify_receipt,digest,domain_instances,
    verify_finite_domain,reliability_report,zero_failure_sample_size)

ROOT=Path(__file__).resolve().parent


def persist(path,value):
    with path.open('x') as stream:
        json.dump(value,stream,indent=2);stream.write('\n')


def execute(instance):
    try:
        result=complete_witness_search(instance)
        if result['status']!='witness':return 'unresolved',None
        t=Fraction(result['time'])
        try:
            cert=receipt('lonely_runner',instance,[t.numerator,t.denominator])
            verify_receipt(cert)
        except (ValueError,KeyError,TypeError,ZeroDivisionError):
            return 'invalid',None
        return 'verified',cert
    except Exception:
        return 'error',None


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();out=args.output.resolve()
    if out.exists():raise SystemExit('Evidence directory already exists; previous evaluation will not be overwritten.')
    out.mkdir(parents=True)
    clock=time.monotonic()
    manifest={'kind':'bounded_speed_combinations','relation':'lonely_runner','speed_count':7,
              'min_speed':1,'max_speed':20,'primitive_only':True,'open_only':True}
    configuration={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in
                   ('swc_assurance.py','swc_canonical_pair.py','swc_lonely_runner.py','run_swc_assurance_pilot.py')}
    configuration_hash=digest(configuration)
    n=zero_failure_sample_size(Fraction(1,1000),Fraction(1,100))
    plan={'schema':'swc-reliability-plan-v1','sampling_design':'fresh_iid_fixed_horizon',
          'selection':'all_draws_including_failures','sample_size':n,'alpha':'1/100',
          'target_failure_rate':'1/1000','failure_definition':'anything_without_a_verified_receipt',
          'relation':'lonely_runner','configuration_sha256':configuration_hash,
          'distribution':'Uniform seven-element subsets of integers 1..60; independent draws with replacement between trials.',
          'sampler':'Python SystemRandom.sample(range(1,61),7), sorted; no rejection filtering.',
          'provenance':'Fresh computer-generated mathematical inputs from OS randomness; IID is a stated modeling assumption.',
          'evidence_kind':'mathematical_input_laboratory_evaluation',
          'planned_at_utc':datetime.now(timezone.utc).isoformat(),
          'physical_measurements':False,'configuration_files':configuration}
    # Record and freeze design before either evaluation begins.
    persist(out/'plan.json',plan);persist(out/'domain.json',manifest)
    rows=[]
    for instance in domain_instances(manifest):
        status,cert=execute(instance)
        if status!='verified':
            persist(out/'finite-incomplete.json',{'status':status,'first_unresolved_instance':instance,
                    'verified_prefix_count':len(rows),'domain':manifest})
            raise SystemExit('Finite domain coverage is incomplete; no complete claim issued.')
        rows.append({'instance':instance,'witness':cert['body']['witness']})
    bundle={'schema':'swc-finite-coverage-v1','domain':manifest,'domain_sha256':digest(manifest),
            'rows':rows,'rows_sha256':digest(rows)}
    finite=verify_finite_domain(bundle)
    persist(out/'finite-coverage.json',bundle)
    print(f"Finite domain: {finite['instances_verified']} exact witnesses checked",flush=True)
    source=SystemRandom();events=[];previous=digest(plan)
    # A durable line log retains outcomes even if the process is interrupted.
    with (out/'trials.jsonl').open('x') as log:
        for i in range(n):
            instance=sorted(source.sample(range(1,61),7))
            status,cert=execute(instance)
            event={'trial_id':i,'instance':instance,'status':status,'plan_sha256':digest(plan),
                   'configuration_sha256':configuration_hash,'previous_sha256':previous}
            if cert is not None:event['receipt']=cert
            event['sha256']=digest(event);previous=event['sha256'];events.append(event)
            log.write(json.dumps(event,sort_keys=True,separators=(',',':'))+'\n');log.flush()
    # Refuse a model/configuration change during the run.
    for name,expected in configuration.items():
        if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=expected:
            raise SystemExit('Configuration changed; no fixed-configuration reliability report issued.')
    report=reliability_report(plan,events)
    persist(out/'reliability.json',report)
    summary={'schema':'swc-assurance-pilot-v1','finite':finite,'reliability':report,
             'new_mathematical_theorem_scope':'declared finite domain only',
             'elapsed_seconds':round(time.monotonic()-clock,3),
             'completed_at_utc':datetime.now(timezone.utc).isoformat()}
    persist(out/'summary.json',summary)
    manifest_files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir()) if p.is_file()}
    persist(out/'SHA256.json',manifest_files)
    print(json.dumps({'finite_instances':len(rows),'holdout_trials':report['trials'],
                     'failures':report['failures'],'upper_failure_bound':report['failure_rate_upper_bound'],
                     'target_demonstrated':report['target_demonstrated'],
                     'elapsed_seconds':summary['elapsed_seconds'],'output':str(out)},indent=2))


if __name__=='__main__':main()
