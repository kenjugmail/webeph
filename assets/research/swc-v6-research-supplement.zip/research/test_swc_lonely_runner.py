from copy import deepcopy
from fractions import Fraction
from itertools import combinations
import unittest
from swc_lonely_runner import (lonely, congruence_roots, canonical_times,
    exact_grid_record, pair_bonferroni, continuous_good_set, residue_family)
from verify_swc_lonely_runner import verify
from swc_lonely_modular_cover import produce
from verify_swc_lonely_cover import verify_cover, verify_bundle


class LonelyRunnerTests(unittest.TestCase):
    def test_congruences_against_bruteforce(self):
        for q in range(2,35):
            for v in range(1,q):
                for target in range(q):
                    self.assertEqual(set(congruence_roots(v,q,target)),
                                     {m for m in range(q) if v*m%q==target})

    def test_all_lifts_matter(self):
        self.assertEqual(congruence_roots(6,16,8),(4,12))
        self.assertEqual(congruence_roots(6,16,7),())
        self.assertTrue(lonely((6,10,15),4,16))

    def test_zero_continuous_mass_positive_atomic_mass(self):
        for n in range(2,8):
            values=tuple(range(1,n+1))
            result=exact_grid_record(values)
            self.assertEqual(Fraction(result['maximum_loneliness']),Fraction(1,n+1))
            self.assertGreater(Fraction(result['accepted_mass']),0)
            intervals=continuous_good_set(values)
            self.assertEqual(intervals['measure'],'0')
            self.assertTrue(intervals['components'])

    def test_grid_positivity_against_independent_interval_intersections(self):
        for values in combinations(range(1,12),4):
            record=exact_grid_record(values)
            self.assertEqual(Fraction(record['accepted_mass'])>0,
                             bool(continuous_good_set(values)['components']))

    def test_every_pair_bound(self):
        for values in ((1,2,3,4),(6,10,15),(11,17,26,39,52,65,91)):
            for i,j in combinations(range(len(values)),2):
                result=pair_bonferroni(values,i,j)
                self.assertLessEqual(result['first_order_lower_count'],result['third_order_lower_count'])
                self.assertLessEqual(result['third_order_lower_count'],result['exact_count'])

    def test_independent_verifier_rejects_corruptions(self):
        record=exact_grid_record((6,10,15))
        self.assertTrue(verify(record)['accepted'])
        for key,value in [('accepted_mass','1'),('scope','all_speed_tuples'),
                          ('threshold','0'),('maximum_loneliness','1/2'),
                          ('maximizing_time','0'),('generator','learned')]:
            forged=deepcopy(record);forged[key]=value
            with self.assertRaises(ValueError):verify(forged)
        forged=deepcopy(record);forged['grids'][0]['accepted']+=1
        with self.assertRaises(ValueError):verify(forged)
        forged=deepcopy(record);forged['grids'].pop()
        with self.assertRaises(ValueError):verify(forged)

    def test_residue_family(self):
        result=residue_family((6,10,15),1,4)
        self.assertEqual(result['scope'],'specified_residue_family')
        for k in range(30):
            self.assertTrue(lonely((6+4*k,10+8*k,15+12*k),1,4))
        with self.assertRaises(ValueError):residue_family((1,2,3),0,4)

    def test_canonical_symmetry_and_no_coprime_pair(self):
        values=(6,10,15)
        candidates=canonical_times(values)
        self.assertTrue(any(lonely(values,t.numerator,t.denominator) for t in candidates))
        self.assertEqual(set(candidates),{(-t)%1 for t in candidates})

    def test_resource_and_encoding_boundaries(self):
        for values in ((1,True),(1,1),(0,2),(1,10001)):
            with self.assertRaises(ValueError):exact_grid_record(values)
        with self.assertRaises(ValueError):exact_grid_record(tuple(range(9989,10001)))

    def test_modular_cover_keeps_repeated_residues(self):
        record=produce(3,3,4)
        report=verify_cover(record)
        self.assertEqual(report['orbits'],120)
        self.assertEqual(report['ordered_tuples'],512)
        self.assertEqual(report['gcd_reductions'],60)
        forged=deepcopy(record);forged['actions'].pop()
        with self.assertRaises(ValueError):verify_cover(forged)
        forged=deepcopy(record);forged['actions'][0]=0
        with self.assertRaises(ValueError):verify_cover(forged)
        forged=deepcopy(record);forged['actions'][0]=-1
        with self.assertRaises(ValueError):verify_cover(forged)

    def test_failed_modular_cover_cannot_be_certified(self):
        failed=produce(3,5,4)
        self.assertEqual(len(failed['uncovered']),32)
        with self.assertRaises(ValueError):verify_cover(failed)
        failed['uncovered']=[]
        with self.assertRaises(ValueError):verify_cover(failed)

    def test_prime_budget_and_dimension_gate(self):
        base={'schema':'swc-lonely-modular-pilot-v1','k':3,
              'covers':[produce(3,2,4),produce(3,3,4)],
              'prime_product':6,'product_bound':'1728'}
        with self.assertRaises(ValueError):verify_bundle(base)
        base['covers']=[produce(3,2,4)]*12
        base['prime_product']=4096
        with self.assertRaises(ValueError):verify_bundle(base)

    def test_modular_cover_budget_stops_frontier_bruteforce(self):
        with self.assertRaises(ValueError):produce(13,11,14)


if __name__=='__main__':unittest.main()
