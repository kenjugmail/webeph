"""Recursive SWC certificate builder preserving the required first denominator.

The recursion is total for each fixed (n,x), but can return None. That means
no witness was found in this fixed-anchor Type-II class, not that ES fails.
"""
from functools import lru_cache
from math import isqrt
import argparse
import json
from pathlib import Path


def divisors(n):
    small, large = [], []
    for d in range(1,isqrt(n)+1):
        if n%d==0:
            small.append(d)
            if d*d!=n:
                large.append(n//d)
    return small+large[::-1]


@lru_cache(None)
def prove(n,x):
    h=4*x-n
    if n<2 or x<1 or h<=0:
        return None
    # Preserve h and the specified first denominator. A smaller n alone
    # does not identify the correct induction premise.
    for scale in divisors(x)[1:]:
        parent_x=x//scale
        parent_n=4*parent_x-h
        if parent_n<2:
            continue
        assert parent_x<x and parent_n<n
        parent=prove(parent_n,parent_x)
        if parent is not None:
            return dict(kind='transport',n=n,x=x,h=h,scale=scale,
                        b=scale*parent['b'],e=scale*parent['e'],parent=parent)
    # Direct leaves must be checked. There is no assumption that they exist.
    for d in divisors(x*x):
        complement=x*x//d
        if (x+d)%h==0 and (x+complement)%h==0:
            return dict(kind='direct',n=n,x=x,h=h,d=d,
                        b=(x+d)//h,e=(x+complement)//h)
    return None


def verify(tree):
    n,x,h,b,e=(tree[k] for k in ('n','x','h','b','e'))
    assert min(n,x,h,b,e)>0 and 4*x==n+h
    y,z=n*b,n*e
    assert 4*x*y*z==n*(x*y+x*z+y*z)
    if tree['kind']=='direct':
        d=tree['d']
        assert d>0 and x*x%d==0
        assert h*b==x+d and h*e==x+x*x//d
        return 1
    assert tree['kind']=='transport'
    parent=tree['parent'];scale=tree['scale']
    assert scale>=2 and parent['h']==h
    assert x==scale*parent['x'] and b==scale*parent['b'] and e==scale*parent['e']
    assert n==parent['n']+4*(scale-1)*parent['x'] and 2*parent['n']<n
    return 1+verify(parent)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',type=Path)
    args=parser.parse_args()
    records=[]
    for p,h in [(73,7),(241,11),(1249,11),(118801,59),(8803369,107)]:
        tree=prove(p,(p+h)//4)
        assert tree is not None
        records.append(dict(p=p,depth=verify(tree),proof=tree))
    # 73 has a solution with first denominator 20, but not every supplied
    # first denominator works. This distinguishes the induction predicates.
    assert prove(73,25) is None
    for n in range(5,150,4):
        for x in range(n//4+1,3*n//4+1):
            tree=prove(n,x)
            direct=any((x+d)%(4*x-n)==0 and (x+x*x//d)%(4*x-n)==0
                       for d in divisors(x*x))
            assert (tree is not None)==direct
            if tree: verify(tree)
    result=dict(status='verified_recursive_certificates_universal_success_open',
                negative_fixed_anchor=dict(n=73,x=25),records=records)
    payload=json.dumps(result,indent=2)
    if args.out: args.out.write_text(payload+'\n',encoding='utf-8')
    print(json.dumps([dict(p=r['p'],depth=r['depth']) for r in records]))


if __name__=='__main__':
    main()
